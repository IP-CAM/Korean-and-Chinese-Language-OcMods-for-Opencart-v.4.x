<?php
// 제목
$_['heading_title'] = '제품 카테고리';