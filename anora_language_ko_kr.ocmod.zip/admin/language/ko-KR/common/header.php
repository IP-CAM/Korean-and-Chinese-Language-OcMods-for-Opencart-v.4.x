<?php
// 제목
$_['heading_title'] = '오픈카트';

//텍스트
$_['text_notification'] = '메시지 알림';
$_['text_notification_all'] = '모두 표시';
$_['text_notification_none'] = '현재 메시지 알림이 없습니다';
$_['text_profile'] = '계정 데이터';
$_['text_store'] = '웹사이트';
$_['text_help'] = '도움말';
$_['text_homepage'] = '홈페이지';
$_['text_support'] = '지원 포럼';
$_['text_documentation'] = '문서화';
$_['text_logout'] = '로그아웃';