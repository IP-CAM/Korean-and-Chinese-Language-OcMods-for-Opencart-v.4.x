<?php
// Heading
$_['heading_title']				= '下载文档';

// Text
$_['text_success']				= '成功: 下载文档设置已更新！';
$_['text_list']					= '下载文档清单';
$_['text_add']					= '添加下载文档';
$_['text_edit']					= '编辑下载文档';
$_['text_upload']				= '文档已经成功上传！';
$_['text_report']       		= '统计报表';

// Column
$_['column_name']				= '文档名称';
$_['column_ip']         		= 'IP';
$_['column_account']    		= '帐号';
$_['column_store']      		= '商店';
$_['column_country']    		= '国别';
$_['column_date_added'] 		= '添加日期';
$_['column_action']				= '管理';

// Entry
$_['entry_name']				= '下载文档名称';
$_['entry_filename']			= '文档名称';
$_['entry_mask']				= '遮罩';

// Help
$_['help_filename']				= '您可以透过上传按钮上传或使用FTP上传。';
$_['help_mask']					= '建议将文档名称和遮罩设为不同，以阻止网友试图直接链接到您的下载。';

// Error
$_['error_warning']				= '警告: 请确实检查表单字段填写的内容!';
$_['error_permission']			= '警告: 您没有权限更改下载文档！';
$_['error_name']				= '文档名称必须是 3 到 64 个字！';
$_['error_filename']			= '文档名称必须是 3 到 128 个字！';
$_['error_filename_character'] 	= '文档名称只能使用 a-z, 0-9, - and _! 等字符';
$_['error_directory']   		= '下载文档必须在 storage/download 目录中!';
$_['error_exists']				= '文档不存在！';
$_['error_mask']				= '遮罩必须是 3 到 128 个字！';
$_['error_mask_character']		= '遮罩只能使用 a-z, 0-9, - and _ 等字符!';
$_['error_file_type']			= '无效的文档类型！';
$_['error_product']				= '警告: 此下载不能删除, 因为已有 %s 项商品使用了！';
