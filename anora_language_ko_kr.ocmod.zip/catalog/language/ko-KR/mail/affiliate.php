<?php
//텍스트
$_['text_subject'] = '%s - 추천 프로그램';
$_['text_welcome'] = '%s 추천 프로그램에 참여해주셔서 감사합니다! ';
$_['text_login'] = '귀하의 추천 계정이 생성되었습니다. 당사 웹사이트나 다음 URL을 탐색하여 귀하의 이메일 주소와 비밀번호를 사용하여 로그인할 수 있습니다:';
$_['text_approval'] = '추천 계정이 검토 중입니다. 검토를 통과한 후 다음 URL을 통해 이메일 주소와 비밀번호를 사용하여 로그인할 수 있습니다:';
$_['text_service'] = '로그인한 후 링크 코드를 생성하여 계정의 보너스와 메시지를 추적할 수 있습니다. ';
$_['text_thanks'] = '감사합니다! ';
$_['text_new_affiliate'] = '새 추천 계정';
$_['text_signup'] = '새 추천 계정이 로그인되었습니다:';
$_['text_website'] = '웹사이트:';
$_['text_customer_group'] = '회원등급:';
$_['text_firstname'] = '이름:';
$_['text_lastname'] = '성:';
$_['text_company'] = '회사:';
$_['text_email'] = '이메일:';
$_['text_telephone'] = '전화번호:';

// 버튼
$_['button_login'] = '로그인';