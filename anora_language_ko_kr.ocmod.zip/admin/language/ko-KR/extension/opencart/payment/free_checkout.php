<?php
// 제목
$_['heading_title'] = '무료 결제';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 무료 결제 모듈 설정이 업데이트되었습니다!';
$_['text_edit'] = '무료 체크아웃 모듈 편집';

// 항목
$_['entry_order_status'] = '기본 주문 상태';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 무료 체크아웃 모듈을 편집할 권한이 없습니다!';