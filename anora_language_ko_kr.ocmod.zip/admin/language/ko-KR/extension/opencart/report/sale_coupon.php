<?php
// 제목
$_['heading_title'] = '할인쿠폰 보고서';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_edit'] = '쿠폰 보고서 편집';
$_['text_success'] = '성공: 쿠폰 보고서 설정이 업데이트되었습니다!';
$_['text_filter'] = '필터';

//열
$_['column_name'] = '할인쿠폰 이름';
$_['column_code'] = '할인쿠폰코드';
$_['column_orders'] = '주문수';
$_['column_total'] = '전체';
$_['column_action'] = '액션';

// 항목
$_['entry_date_start'] = '시작일';
$_['entry_date_end'] = '종료일';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 쿠폰 보고서를 편집할 권한이 없습니다!';