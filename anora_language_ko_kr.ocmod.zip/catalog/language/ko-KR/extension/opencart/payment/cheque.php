<?php
// Heading
$_['heading_title'] = '수표/우편환';

// 텍스트
$_['text_instruction'] = '수표/머니오더 지침';
$_['text_payable'] = '지급 대상: ';
$_['text_address'] = '보내기: ';
$_['text_payment']     = '귀하의 주문은 결제가 완료될 때까지 배송되지 않습니다.';