<?php
// 제목
$_['heading_title'] = 'OpenCart 확장 모듈 마켓 API';

//텍스트
$_['text_success'] = '성공: 확장 모듈 마켓 API 모듈 설정이 업데이트되었습니다!';
$_['text_signup'] = '오픈카트 API 계정 정보를 입력하세요. 아직 오픈카트 API 계정이 없다면 <a href="https://www.opencart.com/index.php? Route=account /store" target="_blank" class="alert-link">여기에서 신청하세요</a>. ';

// 항목
$_['entry_username'] = '사용자 이름';
$_['entry_secret'] = '비밀';

// 오류
$_['error_permission'] = '경고: 확장 마켓플레이스 API를 편집할 권한이 없습니다!';
$_['error_username'] = '사용자 이름을 입력해야 합니다!';
$_['error_secret'] = '비밀번호를 입력해야 합니다!';