<?php
// 제목 제목
$_['heading_title'] = '홍보 모듈';