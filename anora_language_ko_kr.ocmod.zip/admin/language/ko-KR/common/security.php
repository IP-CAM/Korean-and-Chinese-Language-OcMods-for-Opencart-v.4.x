<?php
// 제목
$_['heading_title'] = '중요 보안 알림!';

//텍스트
$_['text_install'] = '시스템 설치 디렉터리(설치 디렉터리)';
$_['text_install_description'] = '시스템 설치 디렉터리는 설치가 완료된 후 삭제하는 것이 좋습니다!';
$_['text_install_success'] = '성공: 시스템 설치 디렉터리가 삭제되었습니다!';
$_['text_storage'] = '시스템 데이터 디렉터리 경로(저장 경로)';
$_['text_storage_description'] = '시스템 데이터 디렉터리는 중요한 문서(예: error.log)를 저장하는 데 사용됩니다. 경로를 웹사이트 루트 디렉터리(예: public_html, www 또는 htdocs) 외부로 이동하는 것이 좋습니다. ';
$_['text_storage_success'] = '성공: 시스템 데이터 디렉터리 경로가 변경되었습니다!';
$_['text_admin'] = 'admin/config.php 문서 설정 편집';
$_['text_admin_description'] = '백그라운드 관리 디렉터리는 디렉터리 이름을 변경하는 것이 좋습니다';
$_['text_admin_success'] = '성공: 백그라운드 관리 디렉터리 이름이 변경되었습니다!';
$_['text_path'] = '경로';

// 항목
$_['entry_path'] = '디렉토리';
$_['entry_path_current'] = '현재 경로';
$_['entry_path_new'] = '새 경로';
$_['entry_name'] = '디렉토리 이름';

// 버튼
$_['button_move'] = '이동';
$_['button_rename'] = '변경';

// 오류
$_['error_permission'] = '경고: 보안 설정을 편집할 수 있는 권한이 없습니다!';
$_['error_install'] = '경고: 시스템 설치 디렉터리가 존재하지 않습니다!';
$_['error_storage'] = '경고: 시스템 데이터 디렉터리가 존재하지 않습니다!';
$_['error_storage_exists'] = '경고: 새로운 시스템 데이터 디렉토리 이름이 이미 존재합니다!';
$_['error_admin'] = '경고: 백그라운드 관리 디렉터리가 존재하지 않습니다!';
$_['error_admin_exists'] = '경고: 새로운 관리자 이름이 이미 존재합니다!';
$_['error_admin_name'] = '경고: 백그라운드 관리자 이름은 외부 세계에 공개되므로 'admin'이 될 수 없습니다!';
$_['error_writable'] = '경고: config.php 파일과 admin/config.php 파일은 쓰기 가능해야 합니다!';