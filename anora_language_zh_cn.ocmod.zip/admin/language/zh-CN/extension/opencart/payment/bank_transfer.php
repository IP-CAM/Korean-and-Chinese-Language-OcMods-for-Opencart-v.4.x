<?php
// Heading
$_['heading_title']      = '银行汇款或转帐';

// Text
$_['text_extension']     = '扩展模块';
$_['text_success']       = '成功: 银行汇款或转帐模块设置已更新!';
$_['text_edit']          = '编辑银行汇款或转帐';

// Entry
$_['entry_bank']         = '银行汇款或转帐相关数据';
$_['entry_order_status'] = '默认订单状态';
$_['entry_geo_zone']     = '适用地区';
$_['entry_status']       = '状态';
$_['entry_sort_order']   = '排序';

// Error
$_['error_permission']   = '警告: 您没有权限编辑银行汇款或转帐模块!';
$_['error_bank']         = '银行汇款或转帐相关数据必须填写!';