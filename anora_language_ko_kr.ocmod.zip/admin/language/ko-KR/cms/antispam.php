<?php
// 제목
$_['heading_title'] = '스팸방지';

//텍스트
$_['text_success'] = '성공: 안티스팸이 업데이트되었습니다!';
$_['text_list'] = '스팸 방지 목록';
$_['text_add'] = '스팸 메시지 방지를 위해 추가';
$_['text_edit'] = '스팸 방지를 위해 편집';

//열
$_['column_keyword'] = '정적 URL';
$_['column_action'] = '액션';

// 항목
$_['entry_keyword'] = '정적 URL';

// 오류
$_['error_warning'] = '경고: 필드 입력에 오류가 있는지 확인하십시오!';
$_['error_permission'] = '경고: 스팸 방지 메시지(Anti-Spam)를 편집할 수 있는 권한이 없습니다!';
$_['error_keyword'] = '고정 URL은 1~64자여야 합니다!';
$_['error_keyword_exists'] = '정적 URL은 반복될 수 없습니다!';