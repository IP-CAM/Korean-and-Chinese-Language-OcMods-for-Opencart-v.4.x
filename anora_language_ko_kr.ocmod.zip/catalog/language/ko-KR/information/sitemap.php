<?php
// 제목
$_['heading_title'] = '웹사이트 탐색';
 
//텍스트
$_['text_special'] = '특별 제안';
$_['text_account'] = '내 계정';
$_['text_edit'] = '계정정보';
$_['text_password'] = '비밀번호 업데이트';
$_['text_address'] = '공통주소';
$_['text_history'] = '내 주문';
$_['text_download'] = '내 다운로드';
$_['text_cart'] = '장바구니';
$_['text_checkout'] = '결제';
$_['text_search'] = '검색';
$_['text_information'] = '상점정보';
$_['text_contact'] = '연락처';