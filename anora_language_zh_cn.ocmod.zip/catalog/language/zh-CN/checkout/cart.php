<?php
// Heading  
$_['heading_title']              = '购物车';

// Text
$_['text_success']               = '成功: 已添加商品<a href="%s">%s</a> 到 <a href="%s">购物车</a>！';
$_['text_edit']                  = '成功: 购物车内容已更新!';
$_['text_remove']                = '成功: 已从购物车移除一件商品！';
$_['text_login']                 = '警告: 您必须<a href="%s">登录</a> 或 <a href="%s">注册新帐号</a> 后才能显示售价！';
$_['text_no_results']            = '您的购物车内没有任何商品！';
$_['text_next']                  = '下一步您想要做什么？';
$_['text_next_choice']           = '选择使用折价券，或使用点数折扣，或预估运费';
$_['text_points']                = '红利点数';
$_['text_subscription']          = '订阅方案';
$_['text_subscription_trial']    = '%s every %d %s(s) for %d payment(s) then ';
$_['text_subscription_duration'] = '%s every %d %s(s) for %d payment(s)';
$_['text_subscription_cancel']   = '%s every %d %s(s) until canceled';
$_['text_day']                   = '每天';
$_['text_week']                  = '每周';
$_['text_semi_month']            = '每半月';
$_['text_month']                 = '每月';
$_['text_year']                  = '每年';

// Column
$_['column_image']               = '图片';
$_['column_name']                = '品名';
$_['column_model']               = '型号';
$_['column_quantity']            = '数量';
$_['column_price']               = '售价';
$_['column_total']               = '总计';

// Error
$_['error_stock']                = '商品标示有 *** 表示数量不足或没有库存！';
$_['error_minimum']              = '%s 最低购买数量是 %s 件！';	
$_['error_required']             = '%s 必须填写！';	
$_['error_product']              = '警告: 您的购物车内没有商品！';	
$_['error_subscription']         = '请选择订阅方案！';