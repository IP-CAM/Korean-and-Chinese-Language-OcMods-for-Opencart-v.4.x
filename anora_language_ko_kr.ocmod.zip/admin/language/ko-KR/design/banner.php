<?php
// 제목
$_['heading_title'] = '광고 이미지';

//텍스트
$_['text_success'] = '성공: 광고 이미지 설정이 업데이트되었습니다! ';
$_['text_list'] = '광고 사진 목록';
$_['text_add'] = '광고 이미지 추가';
$_['text_edit'] = '광고 이미지 편집';
$_['text_default'] = '기본값';

//열
$_['column_name'] = '광고 이미지 이름';
$_['column_status'] = '상태';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '광고 이미지 이름';
$_['entry_title'] = '제목';
$_['entry_link'] = '링크';
$_['entry_image'] = '이미지';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬 표시';

// 오류
$_['error_permission'] = '경고: 광고 이미지를 편집할 수 있는 권한이 없습니다! ';
$_['error_name'] = '광고 이미지 이름은 3~64자여야 합니다! ';
$_['error_title'] = '광고 이미지 제목은 2~64 단어로 구성되어야 합니다! ';