<?php
// Heading
$_['heading_title']        = '货到付款';

// Error
$_['error_order_id']       = '订单数据不存在!';
$_['error_payment_method'] = '付款方式不正确!';