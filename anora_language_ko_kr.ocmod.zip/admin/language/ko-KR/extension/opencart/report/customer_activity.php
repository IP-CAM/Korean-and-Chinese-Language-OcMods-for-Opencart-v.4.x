<?php
// 제목
$_['heading_title'] = '회원활동기록';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_edit'] = '회원 활동기록 편집';
$_['text_success'] = '성공: 회원 활동 기록 설정이 업데이트되었습니다!';
$_['text_filter'] = '녹화 필터';
$_['text_activity_register'] = '<a href="customer_id=%d">%s</a> 계정 등록';
$_['text_activity_edit'] = '<a href="customer_id=%d">%s</a>님이 계정 데이터를 업데이트했습니다.';
$_['text_activity_password'] = '<a href="customer_id=%d">%s</a>님이 비밀번호를 업데이트했습니다.';
$_['text_activity_reset'] = '<a href="customer_id=%d">%s</a> 비밀번호 재설정';
$_['text_activity_login'] = '<a href="customer_id=%d">%s</a> 로그인';
$_['text_activity_forgotten'] = '<a href="customer_id=%d">%s</a>에는 새 비밀번호가 필요합니다.';
$_['text_activity_address_add'] = '<a href="customer_id=%d">%s</a> 새 주소 추가';
$_['text_activity_address_edit'] = '<a href="customer_id=%d">%s</a>가 주소를 업데이트했습니다.';
$_['text_activity_address_delete'] = '<a href="customer_id=%d">%s</a>가 일련의 주소를 삭제했습니다.';
$_['text_activity_return_account'] = '<a href="customer_id=%d">%s</a>님이 제품 반품을 신청했습니다.';
$_['text_activity_return_guest'] = '%s님이 제품 반품을 신청했습니다';
$_['text_activity_order_account'] = '<a href="customer_id=%d">%s</a>가 <a href="order_id=%d">새 주문</a>을 추가했습니다.';
$_['text_activity_order_guest'] = '%s님이 <a href="order_id=%d">새 주문</a>을 추가했습니다.';
$_['text_activity_affiliate_add'] = '<a href="customer_id=%d">%s</a> 추천 계정 추가';
$_['text_activity_affiliate_edit'] = '<a href="customer_id=%d">%s</a>님이 추천 계정을 업데이트했습니다.';
$_['text_activity_transaction'] = '<a href="customer_id=%d">%s</a>이(가) <a href="order_id=%d">신규 주문</a> 수수료로부터 추천을 받았습니다.';

//열
$_['column_customer'] = '회원';
$_['column_comment'] = '비고';
$_['column_ip'] = 'IP';
$_['column_date_added'] = '날짜 추가';

// 항목
$_['entry_customer'] = '회원';
$_['entry_ip'] = 'IP';
$_['entry_date_start'] = '시작일';
$_['entry_date_end'] = '종료일';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 회원 활동 기록을 편집할 수 있는 권한이 없습니다!';