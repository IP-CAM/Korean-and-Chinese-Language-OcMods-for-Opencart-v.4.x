<?php
// 제목
$_['heading_title'] = '언어 편집';

//텍스트
$_['text_success'] = '성공: 언어 편집 설정이 업데이트되었습니다!';
$_['text_list'] = '번역 목록';
$_['text_add'] = '번역 추가';
$_['text_edit'] = '번역 편집';
$_['text_default'] = '기본값';
$_['text_store'] = '저장';
$_['text_language'] = '언어';

//열
$_['column_store'] = '저장';
$_['column_language'] = '언어';
$_['column_route'] = '경로';
$_['column_key'] = '키';
$_['column_value'] = '번역된 텍스트';
$_['column_action'] = '액션';

// 항목
$_['entry_store'] = '스토어';
$_['entry_language'] = '언어';
$_['entry_route'] = '경로';
$_['entry_key'] = '열쇠';
$_['entry_default'] = '기본값';
$_['entry_value'] = '번역된 텍스트';

// 오류
$_['error_permission'] = '경고: 언어 편집기를 수정할 권한이 없습니다!';
$_['error_key'] = '키는 3~64자여야 합니다!';