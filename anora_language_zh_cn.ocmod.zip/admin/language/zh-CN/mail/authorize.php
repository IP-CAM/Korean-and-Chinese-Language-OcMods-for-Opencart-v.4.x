<?php
// Text
$_['text_subject'] = '安全验证';
$_['text_code']    = '您必须为后端管理设置安全码';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Best Regards';