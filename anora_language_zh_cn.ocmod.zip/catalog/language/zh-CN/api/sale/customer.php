<?php
// Text
$_['text_success']         = '会员数据已更新';

// Error
$_['error_customer']       = '您必须选择一个会员!';
$_['error_customer_group'] = '会员等级似乎无效!';
$_['error_firstname']      = '名字必须是 1 到 32 个字！';
$_['error_lastname']       = '姓氏必须是 1 到 32 个字！';
$_['error_email']          = 'Email 格式不正确！';
$_['error_telephone']      = '联系电话必须是 3 到 32 个字！';
$_['error_custom_field']   = '%s 必须填写！';
$_['error_regex']          = '%s 不是一个有效的值!';
