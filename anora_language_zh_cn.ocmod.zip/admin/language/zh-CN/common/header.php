<?php
// Heading
$_['heading_title']          = 'OpenCart';

// Text
$_['text_notification']      = '消息通知';
$_['text_notification_all']  = '显示全部';
$_['text_notification_none'] = '目前没有任何消息通知';
$_['text_profile']           = '帐号数据';
$_['text_store']             = '网站';
$_['text_help']              = '协助';
$_['text_homepage']          = '首页';
$_['text_support']           = '支持论坛';
$_['text_documentation']     = '说明文档';
$_['text_logout']            = '注销';