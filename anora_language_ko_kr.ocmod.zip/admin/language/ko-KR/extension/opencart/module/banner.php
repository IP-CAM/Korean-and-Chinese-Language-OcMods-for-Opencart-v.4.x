<?php
// 제목
$_['heading_title'] = '광고 이미지';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 광고 이미지 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '광고 이미지 모듈 편집';
$_['text_slide'] = '슬라이드 인 및 슬라이드 아웃';
$_['text_fade'] = '페이드 인 및 페이드 아웃';

// 항목
$_['entry_name'] = '광고 이미지 이름';
$_['entry_banner'] = '광고 이미지';
$_['entry_effect'] = '효과';
$_['entry_items'] = '각 그룹의 슬라이드 사진 수';
$_['entry_controls'] = '컨트롤';
$_['entry_indicators'] = '지표';
$_['entry_interval'] = '간격 시간(ms)';
$_['entry_width'] = '너비';
$_['entry_height'] = '높이';
$_['entry_status'] = '상태:';

// 돕다
$_['help_items'] = '각 슬라이드 그룹의 사진 수';

// 오류
$_['error_permission'] = '경고: 광고 이미지 모듈을 수정할 권한이 없습니다! ';
$_['error_name'] = '광고 이미지 이름은 3~64자 사이여야 합니다!';
$_['error_interval'] = '간격값을 입력해야 합니다!';
$_['error_width'] = '폭을 입력해야 합니다!';
$_['error_height'] = '키를 입력해야 합니다!';