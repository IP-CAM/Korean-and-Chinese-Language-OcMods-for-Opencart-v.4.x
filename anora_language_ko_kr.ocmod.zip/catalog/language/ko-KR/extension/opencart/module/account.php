<?php
// 제목
$_['heading_title'] = '회원센터';

//텍스트
$_['text_register'] = '회원가입';
$_['text_login'] = '회원 로그인';
$_['text_logout'] = '회원 로그아웃';
$_['text_forgotten'] = '비밀번호를 잊어버렸습니다';
$_['text_account'] = '내 계정';
$_['text_edit'] = '계정 편집';
$_['text_password'] = '비밀번호 변경';
$_['text_address'] = '공통주소';
$_['text_wishlist'] = '추적 목록';
$_['text_order'] = '내 주문';
$_['text_download'] = '내 다운로드';
$_['text_reward'] = '내 포인트';
$_['text_return'] = '상품반품';
$_['text_transaction'] = '쇼핑 크레딧';
$_['text_newsletter'] = '뉴스레터 구독';
$_['text_subscription'] = '내 구독';