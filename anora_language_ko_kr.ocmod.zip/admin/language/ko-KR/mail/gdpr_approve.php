<?php
// 텍스트
$_['text_subject'] = '%s - GDPR 요청이 승인되었습니다!';
$_['text_request'] = '계정 삭제 요청';
$_['text_hello'] = '안녕하세요 <strong>%s</strong>,';
$_['text_user'] = '사용자';
$_['text_gdpr'] = '귀하의 GDPR 데이터 삭제 요청이 승인되었으며 <strong>%s일</strong> 후에 삭제될 것입니다.';
$_['text_q'] = '질문. 왜 우리는 귀하의 데이터를 즉시 삭제하지 않습니까?';
$_['text_a'] = 'A. 계정 삭제 요청은 <strong>%s일</strong> 후에 처리되므로 환불, 지불 거절 또는 사기 적발이 처리될 수 있습니다.';
$_['text_delete'] = '귀하의 계정이 삭제되면 이를 알리는 이메일을 받게 됩니다.';
$_['text_thanks'] = '감사합니다';