<?php
// Heading 
$_['heading_title']      = '红利点数';

// Column
$_['column_date_added']  = '添加日期';
$_['column_description'] = '说明';
$_['column_points']      = '红利点数';

// Text
$_['text_account']       = '我的帐号';
$_['text_reward']        = '红利点数';
$_['text_total']         = '累计的红利点数：';
$_['text_no_results']    = '您目前还没有任何红利点数！';
