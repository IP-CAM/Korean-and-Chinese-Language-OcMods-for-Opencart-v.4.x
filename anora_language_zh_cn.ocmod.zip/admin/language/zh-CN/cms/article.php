<?php
// Heading
$_['heading_title']           = '文章';

// Text
$_['text_success']            = '成功: 文章内容已更新!';
$_['text_list']               = '文章清单';
$_['text_add']                = '添加文章';
$_['text_edit']               = '编辑文章';
$_['text_default']            = '默认';
$_['text_keyword']            = '请勿使用空格，使用 - 取代空格，并确定静态网址是没有重复过的。';

// Column
$_['column_name']             = '文章标题';
$_['column_author']           = '文章作者';
$_['column_date_added']       = '添加日期';
$_['column_action']           = '操作';

// Entry
$_['entry_image']             = '特色图片';
$_['entry_name']              = '文章标题';
$_['entry_description']       = '文章内容';
$_['entry_tag']               = '标签';
$_['entry_meta_title']        = 'Meta 标签标题';
$_['entry_meta_keyword']      = 'Meta 标签关键字';
$_['entry_meta_description']  = 'Meta 标签描述';
$_['entry_topic']             = '文章主题分类';
$_['entry_author']            = '文章作者';
$_['entry_store']             = '商店';
$_['entry_sort_order']        = '排序';
$_['entry_status']            = '状态';
$_['entry_keyword']           = '静态网址';
$_['entry_layout']            = '指定 Layout';

// Error
$_['error_warning']           = '警告: 请检查字段输入的错误!';
$_['error_permission']        = '警告: 您没有权限编辑文章!';
$_['error_name']              = '文章标题必须是 1 到 255 个字!';
$_['error_meta_title']        = 'Meta 标签标题必须是 1 到 255 个字!';
$_['error_keyword']           = '静态网址必须是 1 到 64 个字!';
$_['error_keyword_exists']    = '静态网址不能重复!';
$_['error_keyword_character'] = '静态网址只能使用 a-z, 0-9, - 和 _ 等字符!';
$_['error_author']            = '文章作者必须是 3 到 64 个字!';