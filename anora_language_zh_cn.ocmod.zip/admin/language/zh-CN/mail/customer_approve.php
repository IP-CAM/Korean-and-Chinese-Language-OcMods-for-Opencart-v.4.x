<?php
// Text
$_['text_subject'] = '%s - 您的会员帐号已经被启用！';
$_['text_welcome'] = '欢迎并感谢您加入 %s！';
$_['text_login']   = '您的会员帐号已创建，并已可以使用您的Email和密码从以下网址登录到我们的网站:';
$_['text_service'] = '登录后，您将能够使用服务包括查看订单记录、和编辑您的帐号数据！';
$_['text_thanks']  = '谢谢';

// Button
$_['button_login'] = '登录';