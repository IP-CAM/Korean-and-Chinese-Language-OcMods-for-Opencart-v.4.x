<?php
// Text
$_['text_success']     = '成功: %s 工作调度已运行!';

// Error
$_['error_permission'] = '警告: 您没有权限更动工作调度!';