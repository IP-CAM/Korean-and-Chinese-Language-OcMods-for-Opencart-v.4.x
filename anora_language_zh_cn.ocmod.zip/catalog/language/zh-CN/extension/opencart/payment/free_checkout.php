<?php
// Heading
$_['heading_title'] = '免费结帐';