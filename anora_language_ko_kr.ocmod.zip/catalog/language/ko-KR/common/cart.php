<?php
//텍스트
$_['text_items'] = '%s 항목 - %s';
$_['text_points'] = '보너스 포인트';
$_['text_subscription'] = '구독 계획';
$_['text_subscription_trial'] = '%s 매 %d %s(s)마다 %d 결제 후 ';
$_['text_subscription_duration'] = '%s 매 %d %s(s)마다 %d 결제';
$_['text_subscription_cancel'] = '취소될 때까지 %s마다 %d %s(s)';
$_['text_day'] = '요일';
$_['text_week'] = '주';
$_['text_semi_month'] = '반달';
$_['text_month'] = '월';
$_['text_year'] = '연도';
$_['text_no_results'] = '장바구니에 품목이 없습니다!';
$_['text_cart'] = '장바구니 보기';
$_['text_checkout'] = '결제';

// 오류
$_['error_product'] = '경고: 제품을 찾을 수 없습니다!';