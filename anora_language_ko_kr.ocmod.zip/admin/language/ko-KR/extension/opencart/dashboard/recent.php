<?php
// 제목
$_['heading_title'] = '최근 주문';

//텍스트
$_['text_extension'] = '확장 기능';
$_['text_success'] = '성공: 정보 개요의 최신 주문 설정이 업데이트되었습니다!';
$_['text_edit'] = '최근 주문 정보 개요 편집';

//열
$_['column_order_id'] = '주문번호';
$_['column_customer'] = '고객 이름';
$_['column_status'] = '상태';
$_['column_total'] = '금액';
$_['column_date_added'] = '날짜 추가';
$_['column_action'] = '관리';

// 항목
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';
$_['entry_width'] = '너비';

// 오류
$_['error_permission'] = '경고: 정보 개요에서 최신 주문을 수정할 권한이 없습니다!';