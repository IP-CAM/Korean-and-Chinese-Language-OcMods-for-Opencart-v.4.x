<?php
// Text
$_['text_subject']       = '%s - 退换状态更新 %s';
$_['text_return_id']     = '退换编号(ID):';
$_['text_date_added']    = '退换日期:';
$_['text_return_status'] = '您的商品退换已更新为以下状态:';
$_['text_comment']       = '您的商品退换备注:';
$_['text_footer']        = '如果您有任何问题请回复此 Email。';
