<?php
// Heading
$_['heading_title']           = '主题分类';

// Text
$_['text_success']            = '成功: 主题分类以更新!';
$_['text_list']               = '主题分类清单';
$_['text_add']                = '添加主题分类';
$_['text_edit']               = '编辑主题分类';
$_['text_default']            = '默认';
$_['text_keyword']            = '请勿使用空格，使用 - 取代空格，并确定静态网址是没有重复过的。';

// Column
$_['column_name']             = '主题分类名称';
$_['column_sort_order']       = '排序';
$_['column_action']           = '操作';

// Entry
$_['entry_image']             = '主题分类图标';
$_['entry_name']              = '主题分类名称';
$_['entry_description']       = '说明';
$_['entry_meta_title']        = 'Meta 标签标题';
$_['entry_meta_keyword']      = 'Meta 标签关键字';
$_['entry_meta_description']  = 'Meta 标签描述';
$_['entry_store']             = '商店';
$_['entry_sort_order']        = '排序';
$_['entry_status']            = '状态';
$_['entry_keyword']           = '静态网址';

// Error
$_['error_warning']           = '警告: 请检查字段输入的错误!';
$_['error_permission']        = '警告: 您没有权限编辑主题分类!';
$_['error_name']              = '主题分类名称必须是 1 到 255 个字!';
$_['error_meta_title']        = 'Meta 标签标题必须是 1 到 255 个字!';
$_['error_keyword']           = '静态网址必须是 1 到 64 个字!';
$_['error_keyword_exists']    = '静态网址不能重复!';
$_['error_keyword_character'] = '静态网址只能使用 a-z, 0-9, - 和 _ 等字符!';