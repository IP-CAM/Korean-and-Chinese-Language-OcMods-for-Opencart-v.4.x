<?php
// 제목
$_['heading_title'] = '개인 문서';

//텍스트
$_['text_success'] = '성공: 개인 문서가 업데이트되었습니다!';
$_['text_edit'] = '개인 문서 편집';
$_['text_user'] = '개인 문서 내용';
$_['text_password'] = '비밀번호';

// 항목
$_['entry_username'] = '관리자 계정';
$_['entry_password'] = '관리자 비밀번호';
$_['entry_confirm'] = '확인';
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_email'] = '이메일';
$_['entry_image'] = '이미지';

// 오류
$_['error_permission'] = '경고: 개인 문서를 편집할 수 있는 권한이 없습니다!';
$_['error_username_exists'] = '경고: 관리자 계정이 사용되었습니다!';
$_['error_username'] = '관리자 계정은 3~20자여야 합니다!';
$_['error_password'] = '관리자 비밀번호는 4~20자여야 합니다!';
$_['error_confirm'] = '관리자 비밀번호가 확인 비밀번호와 일치하지 않습니다!';
$_['error_firstname'] = '이름은 1~32자여야 합니다!';
$_['error_lastname'] = '성은 1~32자여야 합니다!';
$_['error_email'] = '유효한 이메일 계정을 입력하세요!';
$_['error_email_exists'] = '경고: 이메일 계정이 사용되었습니다!';