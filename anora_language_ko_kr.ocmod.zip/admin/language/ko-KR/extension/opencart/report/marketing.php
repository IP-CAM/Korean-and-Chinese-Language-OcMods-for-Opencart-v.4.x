<?php
// 제목
$_['heading_title'] = '마케팅 활동 보고서';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_edit'] = '마케팅 활동 보고서 편집';
$_['text_success'] = '성공: 캠페인 보고서 설정이 업데이트되었습니다!';
$_['text_filter'] = '필터';
$_['text_all_status'] = '모든 상태';

//열
$_['column_campaign'] = '캠페인 이름';
$_['column_code'] = '활동 할인코드';
$_['column_clicks'] = '클릭수';
$_['column_orders'] = '주문수';
$_['column_total'] = '전체';

// 항목
$_['entry_date_start'] = '시작일';
$_['entry_date_end'] = '종료일';
$_['entry_order_status'] = '주문상태';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 캠페인 보고서를 편집할 권한이 없습니다!';