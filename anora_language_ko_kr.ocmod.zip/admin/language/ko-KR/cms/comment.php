<?php
// 제목
$_['heading_title'] = '글 메시지';

//텍스트
$_['text_success'] = '성공: 기사 메시지가 업데이트되었습니다!';
$_['text_list'] = '기사 메시지 목록';
$_['text_filter'] = '필터';

//열
$_['column_comment'] = '메시지';
$_['column_article'] = '기사';
$_['column_status'] = '상태';
$_['column_date_add'] = '날짜 추가';
$_['column_action'] = '액션';

// 항목
$_['entry_keyword'] = '정적 URL';
$_['entry_article'] = '기사';
$_['entry_customer'] = '회원';
$_['entry_status'] = '상태';
$_['entry_date_add'] = '날짜 추가';

// 오류
$_['error_warning'] = '경고: 필드 입력에 오류가 있는지 확인하십시오!';
$_['error_permission'] = '경고: 기사 댓글을 편집할 수 있는 권한이 없습니다!';
$_['error_keyword'] = '고정 URL은 1~64자여야 합니다!';