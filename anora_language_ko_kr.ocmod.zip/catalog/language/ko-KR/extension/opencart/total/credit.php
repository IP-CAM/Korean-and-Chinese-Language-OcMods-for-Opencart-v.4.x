<?php
//텍스트
$_['text_credit'] = '쇼핑 크레딧';
$_['text_order_id'] = '주문번호: #%s';