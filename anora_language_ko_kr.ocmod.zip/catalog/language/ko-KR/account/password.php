<?php
// 제목
$_['heading_title'] = '비밀번호 변경';

//텍스트
$_['text_account'] = '내 계정';
$_['text_password'] = '비밀번호';
$_['text_success'] = '성공: 비밀번호가 업데이트되었습니다. ';

// 항목
$_['entry_password'] = '비밀번호';
$_['entry_confirm'] = '비밀번호 확인';

// 오류
$_['error_token'] = '경고: 키가 만료되었습니다!';
$_['error_password'] = '비밀번호 길이는 영숫자 4~20자 사이여야 합니다! ';
$_['error_confirm'] = '확인 비밀번호가 입력한 비밀번호와 일치하지 않습니다! ';