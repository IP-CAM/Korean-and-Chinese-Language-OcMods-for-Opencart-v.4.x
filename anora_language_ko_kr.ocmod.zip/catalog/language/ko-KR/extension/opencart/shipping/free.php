<?php
// 제목
$_['heading_title'] = '무료 배송';

//텍스트
$_['text_description'] = '무료 배송';