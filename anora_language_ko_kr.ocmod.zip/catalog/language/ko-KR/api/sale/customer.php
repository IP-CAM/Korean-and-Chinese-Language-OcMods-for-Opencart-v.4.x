<?php
//텍스트
$_['text_success'] = '회원 데이터가 업데이트되었습니다';

// 오류
$_['error_customer'] = '회원을 선택해야 합니다!';
$_['error_customer_group'] = '회원 등급이 올바르지 않은 것 같습니다!';
$_['error_firstname'] = '이름은 1~32자여야 합니다! ';
$_['error_lastname'] = '성은 1~32자여야 합니다! ';
$_['error_email'] = '이메일 형식이 잘못되었습니다! ';
$_['error_telephone'] = '연락처 번호는 3~32자여야 합니다! ';
$_['error_custom_field'] = '%s을(를) 입력해야 합니다! ';
$_['error_regex'] = '%s은(는) 유효한 값이 아닙니다!';