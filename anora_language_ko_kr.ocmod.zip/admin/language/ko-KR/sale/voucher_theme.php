<?php
// 제목
$_['heading_title'] = '상품권 테마';

//텍스트
$_['text_success'] = '성공: 상품권 테마 설정이 업데이트되었습니다! ';
$_['text_list'] = '상품권 테마 목록';
$_['text_add'] = '상품권 테마 추가';
$_['text_edit'] = '상품권 테마 편집';

//열
$_['column_name'] = '상품권 테마명';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '상품권 테마명';
$_['entry_description'] = '상품권 테마 설명';
$_['entry_image'] = '이미지';

// 오류
$_['error_permission'] = '경고: 상품권 테마를 변경할 수 있는 권한이 없습니다! ';
$_['error_name'] = '상품권 테마 이름은 3~32자여야 합니다! ';
$_['error_image'] = '제품 이미지를 입력해주세요! ';
$_['error_voucher'] = '경고: %s 그룹 상품권이 이미 사용 중이므로 이 상품권 주제를 삭제할 수 없습니다! ';