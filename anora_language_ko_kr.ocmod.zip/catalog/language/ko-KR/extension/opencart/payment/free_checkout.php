<?php
// Heading
$_['heading_title'] = '무료 체크아웃';