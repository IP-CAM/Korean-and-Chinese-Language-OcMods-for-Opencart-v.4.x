<?php
// Text
$_['text_subject']  = '%s - 推荐奖金';
$_['text_received'] = '恭喜您! 您收到一笔来自 %s 的推荐奖金';
$_['text_amount']   = '您已收到:';
$_['text_total']    = '您目前的推荐奖金是:';