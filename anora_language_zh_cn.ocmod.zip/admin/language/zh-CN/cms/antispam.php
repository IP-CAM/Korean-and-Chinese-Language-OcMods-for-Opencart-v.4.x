<?php
// Heading
$_['heading_title']        = '防止垃圾消息(Anti-Spam)';

// Text
$_['text_success']         = '成功: 防止垃圾消息(Anti-Spam)已更新!';
$_['text_list']            = '防止垃圾消息清单';
$_['text_add']             = '添加防止垃圾消息';
$_['text_edit']            = '编辑防止垃圾消息';

// Column
$_['column_keyword']       = '静态网址';
$_['column_action']        = '操作';

// Entry
$_['entry_keyword']        = '静态网址';

// Error
$_['error_warning']        = '警告: 请检查字段输入的错误!';
$_['error_permission']     = '警告: 您没有权限编辑防止垃圾消息(Anti-Spam)!';
$_['error_keyword']        = '静态网址必须是 1 到 64 个字!';
$_['error_keyword_exists'] = '静态网址不能重复!';