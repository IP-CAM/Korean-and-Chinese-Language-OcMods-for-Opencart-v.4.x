<?php
// Heading
$_['heading_title']    = '功能模块';

// Text
$_['text_success']     = '成功: 功能模块设置已更新!';
$_['text_layout']      = '在安装设置功能模块之后，就可以至 <a href="%s" class="alert-link">模板管理</a> 中将功能模块添加至某个模板中!';
$_['text_add']         = '安装模块';
$_['text_list']        = '功能模块清单';

// Column
$_['column_name']      = '功能模块名称';
$_['column_status']    = '状态';
$_['column_action']    = '操作';

// Entry
$_['entry_code']       = '模块';
$_['entry_name']       = '功能模块名称';

// Error
$_['error_permission'] = '警告: 您没有权限编辑功能模块!';
$_['error_extension']  = '警告: 扩展模块不存在!';
$_['error_name']       = '模块名称必须是 3 到 64 个字!';
$_['error_code']       = '扩展模块必须有!';
