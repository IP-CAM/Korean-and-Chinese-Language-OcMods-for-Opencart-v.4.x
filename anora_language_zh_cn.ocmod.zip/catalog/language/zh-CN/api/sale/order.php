<?php
// Text
$_['text_success']           = '成功: 订单已更新';

// Error
$_['error_order']            = '警告: 找不到订单 !';
$_['error_customer']         = '警告: 会员的明细数据必须设置！';
$_['error_payment_address']  = '警告: 帐单地址必须填写！';
$_['error_payment_method']   = '警告: 付款方式必须填写！';
$_['error_no_payment']       = '警告: 没有付款选项可选!';
$_['error_shipping_address'] = '警告: 运送地址必须填写！';
$_['error_shipping_method']  = '警告: 运送方式必须填写！';
$_['error_no_shipping']      = '警告: 没有运送选项可选!';
$_['error_stock']            = '警告: 商品标有 *** 表示数量不足或没有库存！';
$_['error_minimum']          = '警告: %s 最低购买数量是 %s 件！';	
$_['error_product']          = '警告: 必须要有商品!';
$_['error_comment']          = '警告: 必须要有备注!';
