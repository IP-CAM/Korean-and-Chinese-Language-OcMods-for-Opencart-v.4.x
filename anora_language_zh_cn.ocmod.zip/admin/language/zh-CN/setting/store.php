<?php
// Heading
$_['heading_title']                    = '商店管理';

// Text
$_['text_settings']                    = '商店管理';
$_['text_success']                     = '成功: 商店管理设置已更新！';
$_['text_list']                        = '商店清单';
$_['text_add']                         = '添加商店';
$_['text_edit']                        = '编辑商店';
$_['text_items']                       = '商品';
$_['text_shipping']                    = '运送地址';
$_['text_payment']                     = '帐单地址';
$_['text_product']                     = '商品';
$_['text_legal']                       = '法规';
$_['text_tax']                         = '税率';
$_['text_account']                     = '帐户';
$_['text_checkout']                    = '结帐';
$_['text_stock']                       = '商品库存';
$_['text_image']                       = '图片大小';

// Column
$_['column_name']                      = '商店名称';
$_['column_url']	                   = '商店网址';
$_['column_action']                    = '管理';

// Entry
$_['entry_url']                        = '商店网址';
$_['entry_meta_title']                 = 'Meta 标题';
$_['entry_meta_description']           = 'Meta 描述';
$_['entry_meta_keyword']               = 'Meta 标签关键词';
$_['entry_layout']                     = '默认模板';
$_['entry_theme']                      = '网站版型';
$_['entry_name']                       = '商店名称';
$_['entry_owner']                      = '商店管理员';
$_['entry_address']                    = '商店地址';
$_['entry_geocode']                    = '经纬度座标';
$_['entry_email']                      = '邮件地址';
$_['entry_telephone']                  = '电话';
$_['entry_image']                      = '图片';
$_['entry_open']                       = '营业时间';
$_['entry_comment']                    = '备注';
$_['entry_location']                   = '商店地址';
$_['entry_country']                    = '国家';
$_['entry_zone']                       = '县市';
$_['entry_language']                   = '前台语系';
$_['entry_currency']                   = '币别设置';
$_['entry_product_description_length'] = '清单产品描述字数限制';
$_['entry_pagination']                 = '每页默认笔数';
$_['entry_product_count']              = '分类商品数统计';
$_['entry_cookie']                     = 'Cookie 隐私政策';
$_['entry_gdpr']                       = 'GDPR 隐私政策';
$_['entry_tax']                        = '显示含税价';
$_['entry_tax_default']                = '使用商店所在地税率';
$_['entry_tax_customer']               = '使用会员所在地税率';
$_['entry_customer_group']             = '会员等级';
$_['entry_customer_group_display']     = '会员等级';
$_['entry_customer_price']             = '登录后显示价格';
$_['entry_account']                    = '帐户条款';
$_['entry_cart_weight']                = '在购物车中显示重量';
$_['entry_checkout_guest']             = '访客结帐';
$_['entry_checkout']                   = '结帐条款';
$_['entry_stock_display']              = '显示库存';
$_['entry_stock_checkout']             = '缺货结帐';
$_['entry_logo']                       = '商店图标';
$_['entry_image_category']             = '分类图片尺寸 (宽 x 高)';
$_['entry_image_thumb']                = '商品缩略图尺寸 (宽 x 高)';
$_['entry_image_popup']                = '商品大图尺寸 (宽 x 高)';
$_['entry_image_product']              = '商品清单缩略图尺寸 (宽 x 高)';
$_['entry_image_additional']           = '商品页额外图片缩略图尺寸 (宽 x 高)';
$_['entry_image_related']              = '相关商品缩略图尺寸 (宽 x 高)';
$_['entry_image_compare']              = '比较商品缩略图尺寸 (宽 x 高)';
$_['entry_image_wishlist']             = '关注商品缩略图尺寸 Size (宽 x 高)';
$_['entry_image_cart']                 = '购物车商品缩略图尺寸 (宽 x 高)';
$_['entry_image_location']             = '商店缩略图尺寸 (宽 x 高)';
$_['entry_width']                      = '宽度';
$_['entry_height']                     = '高度';

// Help
$_['help_url']                         = '请输入你商店的完整网址。 注意在最后加上 \'/\' 。 例: https://www.yourdomain.com/path/<br /><br />请使用网址或子网址。';
$_['help_geocode']                     = '请输入您商店地址的经纬度座标。';
$_['help_open']                        = '您商店的营业时间。';
$_['help_comment']                     = '此处为任何你想告诉会员之说明，例如商店不接受支票。';
$_['help_location']                    = '你有不同的仓库地址，您要显示在联系表格。';
$_['help_currency']                    = '更改默认币别，清除浏览器缓存中现有的 Cookie。';
$_['help_pagination']                  = '确定每页显示多少项目(例如商品、分类)';
$_['help_product_description_length']  = '在清单模式中，商品简短描述字符限制(分类、特价等)';
$_['help_cookie']                      = '显示 Cookie 政策作为欧盟法律的一部分.';
$_['help_gdpr']                        = '启用 GDPR 功能，例如客户能够请求删除帐号。';
$_['help_tax_default']                 = '非注册会员使用商店所在地税率。 你可以使用商店所在地税率计算税费。';
$_['help_tax_customer']                = '注册会员使用会员所在地税率。 你可以使用商店所在地税率计算税费。';
$_['help_customer_group']              = '默认会员等级。';
$_['help_customer_group_display']      = '显示会员等级，新注册会员时可以选择。';
$_['help_customer_price']              = '会员登录后，才能显示价格。';
$_['help_account']                     = '注册条款。';
$_['help_checkout_guest']              = '允许未注册会员直接结帐，此项交易不适用于可下载的商品。';
$_['help_checkout']                    = '结帐条款。';
$_['help_stock_display']               = '显示商品页面上的库存数量。';
$_['help_stock_checkout']              = '如果会员订购的商品缺货，仍然允许结帐。';
$_['help_product_count']               = '主菜单显示子分类中的商品数, 提醒，如果子分类多将或多或少会影响性能!';

// Error
$_['error_warning']                    = '警告: 请确实检查您输入的数据！';
$_['error_permission']                 = '警告: 您没有权限更改商店设置！';
$_['error_url']                        = '商店网址无效！';
$_['error_meta_title']                 = '标题必须是 3 到 32 个字！';
$_['error_name']                       = '商店名称必须是 3 到 32 个字！';
$_['error_owner']                      = '商店管理员名称必须是 3 到 64 个字!';
$_['error_address']                    = '商店地址必须是 10 到 256 个字!';
$_['error_email']                      = 'E-Mail 地址无效!';
$_['error_telephone']                  = '电话必须是 3 到 32 个字!';
$_['error_product_description_length'] = '商品描述长度限制必须输入!';
$_['error_pagination']                 = '每页显示多少项目必须输入!';
$_['error_customer_group_display']     = '如果您将使用此功能，您必须加入默认会员等级!';
$_['error_default']                    = '警告:您不能删除默认商店！';
$_['error_store']                      = '警告:此商店不能被删除，因为它已有 %s 笔订单！';
$_['error_image_thumb']                = '商品页缩略图尺寸必须输入!';
$_['error_image_popup']                = '商品页大图尺寸必须输入!';
$_['error_image_product']              = '商品清单缩略图尺寸必须输入!';
$_['error_image_category']             = '商品分类清单缩略图尺寸必须输入!';
$_['error_image_additional']           = '商品额外图片缩略图尺寸必须输入!';
$_['error_image_related']              = '相关商品缩略图尺寸必须输入!';
$_['error_image_compare']              = '比较商品缩略图尺寸必须输入!';
$_['error_image_wishlist']             = '关注商品缩略图尺寸必须输入!';
$_['error_image_cart']                 = '购物车商品缩略图尺寸必须输入!';
$_['error_image_location']             = '商店缩略图尺寸必须输入!';