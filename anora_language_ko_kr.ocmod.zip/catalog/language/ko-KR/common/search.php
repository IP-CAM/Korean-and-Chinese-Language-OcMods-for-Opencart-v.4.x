<?php
//텍스트
$_['text_search'] = '상품검색';