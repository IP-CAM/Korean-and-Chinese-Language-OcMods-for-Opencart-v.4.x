<?php
// Heading
$_['heading_title']     = '模板编辑';

// Text
$_['text_success']      = '成功: 模板编辑设置已更新!';
$_['text_edit']         = '编辑模板';
$_['text_store']        = '选择商店';
$_['text_template']     = '选择网站模板';
$_['text_default']      = '默认';
$_['text_extension']    = '扩展模块';
$_['text_history']      = '模板编辑纪录';
$_['text_twig']         = '模板编辑功能使用 Twig 语法，您可参考 <a href="http://twig.sensiolabs.org/documentation" target="_blank" class="alert-link">Twig 语法说明文档</a>.';

// Column
$_['column_store']      = '商店';
$_['column_route']      = 'Route';
$_['column_date_added'] = '加入日期';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 您没有权限修改模板编辑!';
$_['error_twig']        = '警告: 您只能保存 .twig 文档!';