<?php
// Heading 
$_['heading_title']      = '帐号编辑';

// Text
$_['text_account']       = '我的帐号';
$_['text_edit']          = '帐号编辑';
$_['text_your_details']  = '个人基本数据';
$_['text_success']       = '成功: 帐号基本数据已更新';

// Entry
$_['entry_firstname']    = '名字';
$_['entry_lastname']     = '姓氏';
$_['entry_email']        = 'Email';
$_['entry_telephone']    = '手机号码';

// Error
$_['error_token']        = '警告: 密钥已失效!';
$_['error_exists']       = '警告: 该 Email 已被注册，请更换另一个 Email！';
$_['error_firstname']    = '名字必须是 1 到 32 个字！';
$_['error_lastname']     = '姓氏必须是 1 到 32 个字！';
$_['error_email']        = '无效的 Email！';
$_['error_telephone']    = '手机号码必须是 3 到 32 个字！';
$_['error_custom_field'] = '%s 必须填写！';
$_['error_regex']        = '%s 不是有效值!';