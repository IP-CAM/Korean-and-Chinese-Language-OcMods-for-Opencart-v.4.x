<?php
//텍스트
$_['text_reviews'] = '%s개의 댓글';
$_['text_write'] = '의견 작성';
$_['text_login'] = '<a href="%s">회원으로 로그인</a>하거나 <a href="%s">회원으로 등록</a>하시기 바랍니다';
$_['text_no_results'] = '이 제품은 현재 리뷰가 없습니다. ';
$_['text_note'] = '<span class="text-danger">참고:</span> HTML 구문을 지원하지 않습니다!';
$_['text_success'] = '댓글을 남겨주셔서 감사합니다. 관리자가 댓글을 읽은 후 공개할 것입니다. ';

// 항목
$_['entry_name'] = '이름';
$_['entry_review'] = '콘텐츠 검토';
$_['entry_rating'] = '평가';
$_['entry_good'] = '훌륭함';
$_['entry_bad'] = '나쁨';

//탭
$_['tab_review'] = '검토(%s)';

// 오류
$_['error_token'] = '경고: 잘못된 댓글 키!';
$_['error_product'] = '경고: 제품을 찾을 수 없습니다!';
$_['error_name'] = '이름은 3~25자여야 합니다!';
$_['error_text'] = '댓글은 25~1000 단어 사이여야 합니다!';
$_['error_rating'] = '등급을 선택하세요!';
$_['error_guest'] = '댓글을 작성하시려면 먼저 로그인을 하셔야 합니다!';
$_['error_purchased'] = '댓글을 작성하기 전에 이 제품을 구매해야 합니다!';