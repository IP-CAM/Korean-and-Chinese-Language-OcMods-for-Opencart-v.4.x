<?php
// Text
$_['text_reviews']    = '%s 则评论';
$_['text_write']      = '填写评论';
$_['text_login']      = '请先 <a href="%s">登录会员</a> 或 <a href="%s">注册会员</a>';
$_['text_no_results'] = '此商品目前没有任何评论。';
$_['text_note']       = '<span class="text-danger">注意:</span> 不支持 HTML 语法!';
$_['text_success']    = '感谢您提供评论，管理员会在看过之后公开您的评论。';

// Entry
$_['entry_name']       = '姓名';
$_['entry_review']     = '评论内容';
$_['entry_rating']     = '评分';
$_['entry_good']       = '优';
$_['entry_bad']        = '劣';

// Tabs
$_['tab_review']       = '评论 (%s)';

// Error
$_['error_token']      = '警告: 评论密钥无效!';
$_['error_product']    = '警告: 找不到商品!';
$_['error_name']       = '姓名必须是 3 到 25 个字!';
$_['error_text']       = '评论内容必须是 25 到 1000 个字!';
$_['error_rating']     = '请选择评分!';
$_['error_guest']      = '您必须先登录才能填写评论!';
$_['error_purchased']  = '您必须有购买过此商品，才能填写评论!';