<?php
// Text
$_['text_success']           = '成功: 运送方式已设置!';

// Error
$_['error_shipping_address'] = '警告: 必须有运送地址!';
$_['error_shipping_method']  = '警告: 必须有运送方式!';
$_['error_no_shipping']      = '警告: 没有有效的运送方式!';
$_['error_shipping']         = '警告: 没有需要运送的产品';