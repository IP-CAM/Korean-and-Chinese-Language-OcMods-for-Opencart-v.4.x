<?php
// Heading
$_['heading_title']           = '회원 데이터';

// Text
$_['text_login'] = '회원 계정이 있는 경우 <a href="%s"><strong>회원으로 로그인</strong></a>하시기 바랍니다.';
$_['text_register'] = '계정 등록';
$_['text_guest'] = '직접 결제';
$_['text_payment_address']    = '회원주소';
$_['text_shipping_address'] = '배송주소';
$_['text_your_password'] = '비밀번호';
$_['text_agree'] = '<a href="%s" class="modal-link"><b>%s</b></a>를 읽었으며 이에 동의합니다.';
$_['text_success_add'] = '성공: 회원 계정이 생성되었습니다!';
$_['text_success_guest'] = '성공: 게스트 계정 데이터가 저장되었습니다!';
$_['text_success_edit'] = '성공: 회원 계정 데이터가 업데이트되었습니다. ';

// Entry
$_['entry_customer_group'] = '계정 그룹';
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_email'] = '이메일';
$_['entry_telephone'] = '휴대폰번호';
$_['entry_password'] = '비밀번호';
$_['entry_confirm'] = '비밀번호 확인';
$_['entry_company'] = '회사명';
$_['entry_address_1'] = '주소';
$_['entry_address_2'] = '주소 2';
$_['entry_postcode'] = '우편번호';
$_['entry_city'] = '타운십 도시';
$_['entry_country'] = '국가';
$_['entry_zone'] = '군/지역';
$_['entry_match'] = '배송주소와 회원주소가 동일합니다. ';
$_['entry_newsletter'] = '%s 뉴스레터를 구독하고 싶습니다. ';

// Error
$_['error_guest'] = '경고: 결제하기 전에 회원으로 등록해야 합니다!';
$_['error_firstname'] = '이름은 1~32자여야 합니다!';
$_['error_lastname'] = '성은 1~32자여야 합니다!';
$_['error_customer_group'] = '잘못된 회원등급입니다!';
$_['error_customer_approval'] = '경고: 귀하의 멤버십 레벨을 검토해야 하며 게스트 계정에서는 사용할 수 없습니다. ';
$_['error_email'] = '이메일 계정 형식이 잘못되었습니다!';
$_['error_exists'] = '경고: 해당 이메일 계정은 이미 회원으로 등록되어 있습니다!';
$_['error_telephone'] = '휴대전화 번호는 3~32자여야 합니다!';
$_['error_password'] = '비밀번호는 4~20자여야 합니다!';
$_['error_confirm'] = '비밀번호가 확인 비밀번호와 일치하지 않습니다!';
$_['error_address_1'] = '주소는 ​​3~128 단어여야 합니다!';
$_['error_city'] = '도시와 도시는 2~128자여야 합니다!';
$_['error_postcode'] = '우편번호는 2~10자여야 합니다!';
$_['error_country'] = '국가를 선택하세요!';
$_['error_zone'] = '국가/지역을 선택하세요!';
$_['error_agree'] = '경고: %s에 동의해야 합니다!';
$_['error_custom_field'] = '%s 필드를 입력해야 합니다!';
$_['error_regex'] = '%s은(는) 유효한 값이 아닙니다!';
