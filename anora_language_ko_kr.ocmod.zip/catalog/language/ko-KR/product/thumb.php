<?php
//텍스트
$_['text_price'] = '가격:';
$_['text_tax'] = '비과세:';