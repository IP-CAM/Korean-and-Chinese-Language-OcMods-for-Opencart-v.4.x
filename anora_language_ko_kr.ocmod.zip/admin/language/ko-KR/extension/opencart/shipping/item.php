<?php
// 제목
$_['heading_title'] = '개별 청구';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 개별 지불 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '개별 청구 모듈 편집';

// 항목
$_['entry_cost'] = '운송비';
$_['entry_tax_class'] = '세금 분류';
$_['entry_geo_zone'] = '해당지역';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 유료 모듈을 변경할 권한이 없습니다! ';