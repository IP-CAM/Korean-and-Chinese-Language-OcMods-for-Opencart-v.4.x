<?php
// 제목
$_['heading_title'] = '길이 단위';

//텍스트
$_['text_success'] = '성공: 길이 단위 설정이 업데이트되었습니다! ';
$_['text_list'] = '길이 단위 목록';
$_['text_add'] = '길이 단위 추가';
$_['text_edit'] = '길이 단위 편집';

//열
$_['column_title'] = '제목 길이';
$_['column_unit'] = '길이 단위';
$_['column_value'] = '값';
$_['column_action'] = '관리';

// 항목
$_['entry_title'] = '제목 길이';
$_['entry_unit'] = '길이 단위';
$_['entry_value'] = '값';

// 돕다
$_['help_value'] = '이것이 기본 길이 단위라면 1.00000으로 설정하세요. ';

// 오류
$_['error_permission'] = '경고: 길이 단위를 수정할 권한이 없습니다! ';
$_['error_title'] = '제목 길이는 3~32 단어여야 합니다! ';
$_['error_unit'] = '길이 단위 길이는 1~4 단어여야 합니다! ';
$_['error_default'] = '경고: 이 길이 단위는 스토어의 기본 길이 단위이므로 삭제할 수 없습니다! ';
$_['error_product'] = '경고: %s 제품이 이미 사용되었기 때문에 이 길이 단위를 삭제할 수 없습니다! ';