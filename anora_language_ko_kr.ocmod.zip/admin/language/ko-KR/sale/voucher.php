<?php
// 제목
$_['heading_title'] = '쇼핑상품권';

//텍스트
$_['text_success'] = '성공: 쇼핑상품권 설정이 업데이트되었습니다! ';
$_['text_list'] = '쇼핑상품권 목록';
$_['text_add'] = '쇼핑상품권 추가';
$_['text_edit'] = '쇼핑 상품권 편집';
$_['text_sent'] = '성공: 상품권 이메일이 전송되었습니다!';
$_['text_history'] = '역사';

//열
$_['column_name'] = '쇼핑상품권 이름';
$_['column_code'] = '쇼핑상품권 코드';
$_['column_from'] = '발신자';
$_['column_to'] = '쿠폰 수집가';
$_['column_theme'] = '테마';
$_['column_amount'] = '금액';
$_['column_status'] = '상태';
$_['column_order_id'] = '주문ID';
$_['column_customer'] = '회원';
$_['column_date_added'] = '날짜 추가';
$_['column_action'] = '관리';

// 항목
$_['entry_code'] = '쇼핑상품권 코드';
$_['entry_from_name'] = '보내는 사람';
$_['entry_from_email'] = '보낸 사람의 이메일';
$_['entry_to_name'] = '티켓 수집가';
$_['entry_to_email'] = '쿠폰 수신자 이메일';
$_['entry_theme'] = '테마';
$_['entry_message'] = '콘텐츠';
$_['entry_amount'] = '금액';
$_['entry_status'] = '상태';

// 돕다
$_['help_code'] = '쇼핑 쿠폰을 활성화하려면 코드가 필요합니다. ';

// 오류
$_['error_permission'] = '경고: 쇼핑 상품권을 수정할 권한이 없습니다! ';
$_['error_exists'] = '경고: 쇼핑 쿠폰 코드가 사용되었습니다! ';
$_['error_code'] = '코드는 3~10단어여야 합니다! ';
$_['error_to_name'] = '쿠폰 수령자 이름은 1~64자여야 합니다! ';
$_['error_from_name'] = '이름은 1~64자여야 합니다! ';
$_['error_email'] = '잘못된 이메일 주소입니다! ';
$_['error_amount'] = '총 금액은 1보다 크거나 같아야 합니다! ';
$_['error_order'] = '경고: 이 쇼핑 바우처는 <a href="%s">주문</a>의 일부이므로 삭제할 수 없습니다! ';