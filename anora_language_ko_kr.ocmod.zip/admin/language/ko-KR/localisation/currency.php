<?php
// 제목
$_['heading_title'] = '통화관리';

//텍스트
$_['text_success'] = '성공: 통화 관리 설정이 업데이트되었습니다! ';
$_['text_list'] = '통화 목록';
$_['text_add'] = '통화 추가';
$_['text_edit'] = '통화 편집';
$_['text_iso'] = '전체 ISO 통화 코드 및 설정은 http://www.xe.com/iso4217.php에서 찾을 수 있습니다. ';

//열
$_['column_title'] = '통화명';
$_['column_code'] = '코드';
$_['column_value'] = '환율';
$_['column_status'] = '상태';
$_['column_date_modified'] = '최종 업데이트';
$_['column_action'] = '관리';

// 항목
$_['entry_title'] = '통화명';
$_['entry_code'] = '코드';
$_['entry_value'] = '환율';
$_['entry_symbol_left'] = '왼쪽 기호';
$_['entry_symbol_right'] = '오른쪽 기호';
$_['entry_decimal_place'] = '십진수';
$_['entry_status'] = '상태';

// 돕다
$_['help_code'] = '기본 통화인 경우 변경하지 마십시오.</br> 유효한 ISO 코드여야 합니다. ';
$_['help_value'] = '이것이 기본 통화라면 1.00000으로 설정하세요. ';

// 오류
$_['error_permission'] = '경고: 통화 설정을 변경할 권한이 없습니다.';
$_['error_extension'] = '경고: 통화 모듈을 찾을 수 없습니다!';
$_['error_title'] = '통화 이름은 3~32자여야 합니다! ';
$_['error_code'] = '통화 코드는 3자여야 합니다! ';
$_['error_default'] = '경고: 이 통화는 상점의 기본 통화이므로 삭제할 수 없습니다! ';
$_['error_store'] = '경고: 이 통화는 %s 상점에서 이미 사용하고 있기 때문에 삭제할 수 없습니다! ';
$_['error_order'] = '경고: 이 통화는 %s 주문에 사용되었기 때문에 삭제할 수 없습니다! ';