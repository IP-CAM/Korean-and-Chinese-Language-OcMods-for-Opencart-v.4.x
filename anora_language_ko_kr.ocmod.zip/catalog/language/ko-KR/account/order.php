<?php
// 제목
$_['heading_title'] = '내 주문';

//텍스트
$_['text_account'] = '내 계정';
$_['text_order'] = '주문정보';
$_['text_invoice_no'] = '송장번호';
$_['text_order_id'] = '주문번호';
$_['text_order_status'] = '주문 상태';
$_['text_shipping_method'] = '배송방법';
$_['text_pay_method'] = '결제수단';
$_['text_date_add'] = '주문 날짜';
$_['text_shipping_address'] = '배송주소';
$_['text_지불_주소'] = '청구서 수신 주소';
$_['text_subscription'] = '정기결제';
$_['text_subscription_trial'] = '%s 매 %d %s(s)마다 %d 결제 후 ';
$_['text_subscription_duration'] = '%s 매 %d %s(s)마다 %d 결제';
$_['text_subscription_cancel'] = '취소될 때까지 %s마다 %d %s(s)';
$_['text_day'] = '요일';
$_['text_week'] = '주';
$_['text_semi_month'] = '반달';
$_['text_month'] = '월';
$_['text_year'] = '연도';
$_['text_comment'] = '주문 메모';
$_['text_history'] = '주문 기록';
$_['text_success'] = '성공: <a href="%s">%s</a> 항목을 <a href="%s">장바구니</a>에 추가했습니다! ';
$_['text_no_results'] = '아직 주문기록이 없습니다! ';
$_['text_error'] = '찾고 있는 주문을 찾을 수 없습니다! ';

//열
$_['column_order_id'] = '주문번호';
$_['column_customer'] = '회원';
$_['column_product'] = '제품 수량';
$_['column_name'] = '제품명';
$_['column_model'] = '모델';
$_['column_Quantity'] = '수량';
$_['column_price'] = '판매가';
$_['column_total'] = '전체';
$_['column_action'] = '액션';
$_['column_status'] = '상태';
$_['column_comment'] = '비고';
$_['column_date_add'] = '주문 날짜';

// 오류
$_['error_reorder'] = '현재 %s을(를) 다시 구입할 수 없습니다. ';