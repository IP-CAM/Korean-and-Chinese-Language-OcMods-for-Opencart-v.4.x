<?php
// Heading
$_['heading_title']           = '国家管理';

// Text
$_['text_success']            = '成功: 更新国家管理设置已更新！';
$_['text_list']               = '国家清单';
$_['text_add']                = '添加国家';
$_['text_edit']               = '编辑国家';
$_['text_filter']             = 'Filter';

// Column
$_['column_name']             = '国家名称';
$_['column_iso_code_2']       = 'ISO 代码 (2)';
$_['column_iso_code_3']       = 'ISO 代码 (3)';
$_['column_action']           = '管理';

// Entry
$_['entry_name']              = '国家名称';
$_['entry_iso_code_2']        = 'ISO 代码 (2)';
$_['entry_iso_code_3']        = 'ISO 代码 (3)';
$_['entry_address_format']    = '地址格式';
$_['entry_postcode_required'] = '邮递区号必填';
$_['entry_status']            = '状态';

// Error
$_['error_permission']        = '警告: 您没有权限更改国家设置！';
$_['error_name']              = '警告: 国家名称必须在 1 到 128 个字！';
$_['error_default']           = '警告: 该国家不能删除，因为它已被设为商店的默认国家！';
$_['error_store']             = '警告: 该国家不能删除，因为它已设置给 %s 个商店使用！';
$_['error_address']           = '警告: 该国家不能删除，因为它已设置给 %s 个常用地址记录！';
$_['error_zone']              = '警告: 该国家不能删除，因为它已设置给 %s 个县市！';
$_['error_zone_to_geo_zone']  = '警告: 该国家不能删除，因为它已设置给 %s 个地区！';