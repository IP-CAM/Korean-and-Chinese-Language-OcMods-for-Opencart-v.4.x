<?php
// 제목
$_['heading_title'] = '한국어';

//텍스트
$_['text_home'] = '집';
$_['text_headline'] = '중국어 간체';
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 한국어가 업데이트되었습니다!';
$_['text_edit'] = '중국어 간체 편집';
$_['text_translation'] = '번역';
$_['text_version'] = '버전';
$_['언어_버전'] = 'V4.0.2.2';
$_['text_translator'] = '잭슨';
$_['text_improfment'] = '';

// 항목
$_['entry_status'] = '상태';
$_['entry_frontend'] = '프론트엔드';
$_['entry_stores'] = '상점';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 한국어 편집 권한이 없습니다!';