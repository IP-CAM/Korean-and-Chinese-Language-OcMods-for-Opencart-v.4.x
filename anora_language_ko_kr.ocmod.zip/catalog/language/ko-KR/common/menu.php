<?php
//텍스트
$_['text_category'] = '범주';
$_['text_all'] = '모두 표시';