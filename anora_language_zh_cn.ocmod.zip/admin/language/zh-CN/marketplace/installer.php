<?php
// Heading
$_['heading_title']          = '扩展模块安装';

// Text
$_['text_upload']            = '成功: 扩展模块已上传!';
$_['text_success']           = '成功: 扩展模块已安装!';
$_['text_progress']          = '安装进度';
$_['text_installed']         = '已安装扩展模块';

// Column
$_['column_image']           = '图标';
$_['column_name']            = '模块名称';
$_['column_version']         = '版本';
$_['column_date_added']      = '加入日期';
$_['column_action']          = '管理';

// Entry
$_['entry_progress']         = '安装进度';

// Error
$_['error_permission']       = '警告: 您没有权限编辑扩展模块安装!';
$_['error_install']          = '扩展模块正在安装，请再稍候几秒钟!';
$_['error_default']          = '内置的扩展模块不能卸载或删除!';
$_['error_extension']        = '找不到已安装的扩展模块!';
$_['error_installed']        = '扩展模块已安装过!';
$_['error_uninstall']        = '有 %s 套扩展模块需要先卸载才能安全的解除这套扩展模块!';
$_['error_name']             = '模块名称必须是 3 到 128 个字!';
$_['error_version']          = '版本必须是 3 到 128 个字!';
$_['error_author']           = '作者必须是 3 到 128 个字!';
$_['error_link']             = '链接网址必须是 3 到 128 个字!';
$_['error_filename']         = '文档名称必须是 3 到 128 个字!';
$_['error_file']             = '找不到文档!';
$_['error_file_exists']      = '文档已存在!';
$_['error_file_type']        = '无效的文档类型!';
$_['error_directory']        = '安装目录 %s 不存在!';
$_['error_directory_exists'] = '目录 %s 已经存在!';
$_['error_unzip']            = '无法开启您上传的 Zip 文档!';
$_['error_upload']           = '文档无法上传!';
