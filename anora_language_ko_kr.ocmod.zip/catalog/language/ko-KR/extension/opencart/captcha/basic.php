<?php
//텍스트
$_['text_captcha'] = '인증코드';

// 항목
$_['entry_captcha'] = '아래 텍스트 상자에 인증 코드를 입력하세요';

// 오류
$_['error_captcha'] = '입력한 인증번호가 잘못되었습니다!';