<?php
// Heading
$_['heading_title']     = '规格群组';

// Text
$_['text_success']      = '成功: 规格群组设置已更新！';
$_['text_list']         = '规格群组清单';
$_['text_add']          = '添加规格群组';
$_['text_edit']         = '编辑规格群组';

// Column
$_['column_name']       = '规格群组名称';
$_['column_sort_order'] = '显示排序';
$_['column_action']     = '管理';

// Entry
$_['entry_name']        = '规格群组名称';
$_['entry_sort_order']  = '显示排序';

// Error
$_['error_warning']     = '警告: 请确实检查表单字段填写的内容!';
$_['error_permission']  = '警告: 您没有权限修改规格群组！';
$_['error_name']        = '警告: 规格群组名称必须是 1 到 64 个字！';
$_['error_attribute']   = '警告: 这个规格群组不能被删除，因为它已设置了 %s 项规格！';
$_['error_product']     = '警告: 这个规格群组不能被删除，因为它已指定给 %s 项商品了！';