<?php
// Heading
$_['heading_title']    = '特色商品';

// Text
$_['text_extension']   = '扩展模块';
$_['text_success']     = '成功: 特色商品模块设置已更新！';
$_['text_edit']        = '编辑特色商品模块';
$_['text_horizontal']  = '水平';
$_['text_vertical']    = '垂直';

// Entry
$_['entry_name']       = '模块名称';
$_['entry_product']    = '特色商品';
$_['entry_axis']       = '排列方式';
$_['entry_width']      = '图片宽度';
$_['entry_height']     = '图片高度';
$_['entry_status']     = '状态';

// Help
$_['help_product']     = '(自动完成)';

// Error
$_['error_permission'] = '警告: 您没有权限修改特色商品模块！';
$_['error_name']       = '模块名称必须在 3 到 64 个字之间 !';
$_['error_width']      = '图片宽度必须输入 !';
$_['error_height']     = '图片高度必须输入 !';