<?php
// Heading
$_['heading_title']          = '商品规格';

// Text
$_['text_success']           = '成功: 规格设置已更新！';
$_['text_list']              = '规格清单';
$_['text_add']               = '添加规格';
$_['text_edit']              = '编辑规格';

// Column
$_['column_name']            = '规格名称';
$_['column_attribute_group'] = '规格群组';
$_['column_sort_order']      = '排序';
$_['column_action']          = '管理';

// Entry
$_['entry_name']             = '规格名称';
$_['entry_attribute_group']  = '规格群组';
$_['entry_sort_order']       = '显示排序';

// Error
$_['error_warning']          = '警告: 请检查字段输入的错误!';
$_['error_permission']       = '警告: 您没有权限修改规格！';
$_['error_attribute_group']  = '规格群组必须输入!';
$_['error_name']             = '规格名称必须是 1 到 64 个字！';
$_['error_product']          = '警告: 该规格不能被删除，因为目前已经有 %s 项商品使用中！';