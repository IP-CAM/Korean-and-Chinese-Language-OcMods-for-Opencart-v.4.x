<?php
// Text
$_['text_subject'] = '%s - 주문 번호 %s';
$_['text_received'] = '새로운 주문이 있습니다';
$_['text_order_id'] = '주문번호:';
$_['text_date_add'] = '주문 날짜:';
$_['text_order_status'] = '주문 상태:';
$_['text_product'] = '제품';
$_['text_total'] = '합계';
$_['text_comment'] = '주문 비고:';