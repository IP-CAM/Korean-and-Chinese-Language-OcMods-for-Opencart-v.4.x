<?php
// 제목
$_['heading_title'] = '명세 그룹';

//텍스트
$_['text_success'] = '성공: 사양 그룹 설정이 업데이트되었습니다! ';
$_['text_list'] = '명세 그룹 목록';
$_['text_add'] = '명세그룹 추가';
$_['text_edit'] = '규격그룹 편집';

//열
$_['column_name'] = '명세그룹명';
$_['column_sort_order'] = '정렬 표시';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '명세그룹 이름';
$_['entry_sort_order'] = '정렬 표시';

// 오류
$_['error_warning'] = '경고: 양식 필드에 작성된 내용을 확인하십시오!';
$_['error_permission'] = '경고: 사양 그룹을 수정할 권한이 없습니다! ';
$_['error_name'] = '경고: 사양 그룹 이름은 1~64자여야 합니다! ';
$_['error_attribute'] = '경고: 이 사양 그룹에는 %s 사양이 설정되어 있으므로 삭제할 수 없습니다! ';
$_['error_product'] = '경고: 이 사양 그룹은 %s 제품에 할당되어 있으므로 삭제할 수 없습니다! ';