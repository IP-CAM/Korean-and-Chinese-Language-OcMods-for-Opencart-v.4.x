<?php
// 제목
$_['heading_title'] = '확장모듈 설치';

//텍스트
$_['text_upload'] = '성공: 확장 모듈이 업로드되었습니다!';
$_['text_success'] = '성공: 확장 모듈이 설치되었습니다!';
$_['text_progress'] = '설치 진행';
$_['text_installed'] = '확장 모듈 설치됨';

//열
$_['column_image'] = '아이콘';
$_['column_name'] = '모듈 이름';
$_['column_version'] = '버전';
$_['column_date_added'] = '추가된 날짜';
$_['column_action'] = '관리';

// 항목
$_['entry_progress'] = '설치 진행';

// 오류
$_['error_permission'] = '경고: 확장 모듈 설치를 편집할 수 있는 권한이 없습니다!';
$_['error_install'] = '확장 모듈을 설치하는 중입니다. 잠시 기다려 주십시오!';
$_['error_default'] = '내장된 확장 모듈을 제거하거나 삭제할 수 없습니다!';
$_['error_extension'] = '설치된 확장 모듈을 찾을 수 없습니다!';
$_['error_installed'] = '확장 모듈이 설치되었습니다!';
$_['error_uninstall'] = '이 확장 모듈 세트를 안전하게 제거하기 전에 제거해야 할 확장 모듈 세트가 %s개 있습니다!';
$_['error_name'] = '모듈 이름은 3~128자여야 합니다!';
$_['error_version'] = '버전은 3~128 단어여야 합니다!';
$_['error_author'] = '저자는 3~128단어여야 합니다!';
$_['error_link'] = '링크 URL은 3~128자여야 합니다!';
$_['error_filename'] = '문서 이름은 3~128자여야 합니다!';
$_['error_file'] = '문서를 찾을 수 없습니다!';
$_['error_file_exists'] = '문서가 이미 존재합니다!';
$_['error_file_type'] = '잘못된 문서 형식입니다!';
$_['error_directory'] = '%s 설치 디렉터리가 존재하지 않습니다!';
$_['error_directory_exists'] = '%s 디렉토리가 이미 존재합니다!';
$_['error_unzip'] = '업로드한 Zip 파일을 열 수 없습니다!';
$_['error_upload'] = '문서를 업로드할 수 없습니다!';