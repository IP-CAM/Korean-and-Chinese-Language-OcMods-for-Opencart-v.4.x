<?php
// Text
$_['text_success'] = '成功: 商店别已变更!';

// Error
$_['error_store']  = '警告: 找不到商店!';