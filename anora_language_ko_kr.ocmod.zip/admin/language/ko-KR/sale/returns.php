<?php
// 제목
$_['heading_title'] = '제품 반품';

//텍스트
$_['text_success'] = '성공: 상품 반품 및 교환 설정이 업데이트되었습니다! ';
$_['text_list'] = '반품상품 목록';
$_['text_add'] = '반품상품 추가';
$_['text_edit'] = '반품 상품 수정';
$_['text_opened'] = '열림';
$_['text_unopened'] = '미개봉';
$_['text_order'] = '주문 메시지';
$_['text_product'] = '상품정보 및 반품/교환 사유';
$_['text_history'] = '반환 기록';
$_['text_history_add'] = '반품 기록 추가';
$_['text_filter'] = '필터';

//열
$_['column_return_id'] = '반품ID';
$_['column_order_id'] = '주문ID';
$_['column_customer'] = '회원';
$_['column_product'] = '제품명';
$_['column_model'] = '제품 모델';
$_['column_status'] = '상태';
$_['column_date_added'] = '신청일';
$_['column_date_modified'] = '수정된 날짜';
$_['column_comment'] = '비고';
$_['column_notify'] = '회원 알림';
$_['column_action'] = '액션';

// 항목
$_['entry_customer'] = '회원';
$_['entry_order_id'] = '주문ID';
$_['entry_date_ordered'] = '주문 날짜';
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_email'] = '이메일';
$_['entry_telephone'] = '연락처 번호';
$_['entry_product'] = '제품명';
$_['entry_model'] = '아이템 모델';
$_['entry_quantity'] = '수량';
$_['entry_opened'] = '열림';
$_['entry_comment'] = '비고';
$_['entry_return_reason'] = '반품 사유';
$_['entry_return_action'] = '반품 관리';
$_['entry_return_status'] = '반품 상태';
$_['entry_notify'] = '회원 알림';
$_['entry_return_id'] = '반품ID';
$_['entry_date_from'] = '날짜(부터)';
$_['entry_date_to'] = '날짜(종료)';

// 돕다
$_['help_product'] = '(자동완성)';

// 오류
$_['error_warning'] = '경고: 오류 메시지를 확인하세요! ';
$_['error_permission'] = '경고: 반품 제품을 변경할 권한이 없습니다! ';
$_['error_return'] = '경고: 반환 데이터를 찾을 수 없습니다!';
$_['error_order_id'] = '주문 ID를 반드시 입력해야 합니다! ';
$_['error_firstname'] = '이름은 1~32자여야 합니다! ';
$_['error_lastname'] = '성은 1~32자여야 합니다! ';
$_['error_email'] = '이메일 주소가 유효하지 않습니다! ';
$_['error_telephone'] = '전화번호는 3~32자여야 합니다! ';
$_['error_product'] = '제품 이름은 3~255자여야 합니다! ';
$_['error_model'] = '제품 모델은 3~64자여야 합니다! ';