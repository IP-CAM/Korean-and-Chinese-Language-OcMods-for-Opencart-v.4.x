<?php
// Heading
$_['heading_title'] = '대금 상환';

// 오류
$_['error_order_id'] = '주문 데이터가 존재하지 않습니다!';
$_['error_payment_method'] = '결제수단이 잘못되었습니다!';