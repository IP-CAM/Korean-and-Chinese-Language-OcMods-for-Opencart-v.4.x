<?php
// 제목
$_['heading_title'] = '관리자 관리';

//텍스트
$_['text_success'] = '성공: 관리자 계정 설정이 업데이트되었습니다! ';
$_['text_list'] = '관리자 계정 목록';
$_['text_add'] = '관리자 계정 추가';
$_['text_edit'] = '관리자 계정 편집';
$_['text_user'] = '관리자 데이터';
$_['text_password'] = '비밀번호';
$_['text_user_login'] = '관리자 로그인';
$_['text_other'] = '기타';
$_['text_login'] = '로그인 기록';

//열
$_['column_username'] = '관리자 계정';
$_['column_status'] = '상태';
$_['column_ip'] = 'IP';
$_['column_user_agent'] = '사용자 에이전트';
$_['column_date_added'] = '날짜 추가';
$_['column_action'] = '관리';

// 항목
$_['entry_username'] = '관리자 계정';
$_['entry_user_group'] = '계정 그룹';
$_['entry_password'] = '비밀번호';
$_['entry_confirm'] = '비밀번호 확인';
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_email'] = '이메일';
$_['entry_image'] = '이미지';
$_['entry_status'] = '상태';

//탭
$_['tab_login'] = '로그인';

// 오류
$_['error_permission'] = '경고: 관리자 계정을 변경할 수 있는 권한이 없습니다! ';
$_['error_account'] = '경고: 계정을 삭제할 수 없습니다! ';
$_['error_login'] = '경고: 계정 로그인이 존재하지 않습니다!';
$_['error_username'] = '관리자 계정은 3~20자여야 합니다! ';
$_['error_username_exists'] = '경고: 관리자 계정이 이미 존재합니다! ';
$_['error_firstname'] = '이름은 1~32자여야 합니다! ';
$_['error_lastname'] = '성은 1~32자여야 합니다! ';
$_['error_email'] = '이메일 계정이 유효하지 않습니다!';
$_['error_email_exists'] = '경고: 이메일 계정이 이미 등록되어 있습니다!';
$_['error_password'] = '비밀번호 길이는 4~20자여야 합니다! ';
$_['error_confirm'] = '비밀번호와 확인 비밀번호가 일치하지 않습니다! ';