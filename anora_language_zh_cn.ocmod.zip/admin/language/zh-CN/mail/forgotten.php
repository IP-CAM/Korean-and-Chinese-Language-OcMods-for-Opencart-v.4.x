<?php
// Text
$_['text_subject']  = '%s - 请求密码重设';
$_['text_greeting'] = '%s 管理员已要求一组新的密码.';
$_['text_change']   = '要重设密码请点击下方链接:';
$_['text_ip']       = '要求重设密码的 IP: %s';