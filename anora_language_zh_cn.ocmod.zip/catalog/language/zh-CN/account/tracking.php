<?php
// Heading
$_['heading_title']    = '推荐追踪';

// Text
$_['text_account']     = '我的帐号';
$_['text_description'] = '为了确保您可以获得推荐奖金，我们需要在URL加上我们的追踪码，您可以使用下面的工具来产生％s网站的追踪链接。';

// Entry
$_['entry_code']       = '您的推荐追踪码';
$_['entry_generator']  = '产生追踪链接';
$_['entry_link']       = '追踪链接';

// Help
$_['help_generator']   = '输入您要产生追踪链接的商品';