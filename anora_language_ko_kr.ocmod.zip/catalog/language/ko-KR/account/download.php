<?php
// Heading 
$_['heading_title'] = '내 다운로드';

//텍스트
$_['text_account'] = '내 계정';
$_['text_downloads'] = '제품 다운로드';
$_['text_no_results'] = '다운로드 제품을 구매하지 않았습니다! ';

//열
$_['column_order_id'] = '주문번호';
$_['column_name'] = '파일 이름';
$_['column_size'] = '파일 크기';
$_['column_date_add'] = '날짜 추가';

// 오류
$_['error_not_found'] = '오류: %s 파일을 찾을 수 없습니다!';
$_['error_headers_sent'] = '오류: 헤더가 이미 전송되었습니다!';
