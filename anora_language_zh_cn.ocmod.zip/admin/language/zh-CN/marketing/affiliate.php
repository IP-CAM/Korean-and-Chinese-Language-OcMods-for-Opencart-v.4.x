<?php
// Heading
$_['heading_title']             = '会员推荐';

// Text
$_['text_success']              = '成功: 会员推荐设置已更新!';
$_['text_list']                 = '会员推荐清单';
$_['text_add']                  = '添加推荐会员';
$_['text_edit']                 = '编辑推荐会员';
$_['text_affiliate']            = '推荐数据';
$_['text_payment']              = '拨款数据';
$_['text_other']                = '其他设置';
$_['text_balance']              = '奖金余额';
$_['text_cheque']               = '支票';
$_['text_paypal']               = 'PayPal';
$_['text_bank']                 = '银行转帐';
$_['text_history']              = '纪录';
$_['text_history_add']          = '添加纪录';
$_['text_transaction']          = '购物金';
$_['text_transaction_add']      = '添加购物金';
$_['text_report']               = '报表';
$_['text_filter']               = '筛选';
$_['text_payment_cheque']       = 'Cheque Payment';
$_['text_payment_paypal']       = 'PayPal Payment';
$_['text_payment_bank']         = 'Bank Transfer Payment';

// Column
$_['column_name']               = '会员名称';
$_['column_tracking']           = '追踪';
$_['column_commission']         = '奖金';
$_['column_balance']            = 'Balance';
$_['column_status']             = '状态';
$_['column_ip']                 = 'IP';
$_['column_account']            = '帐号';
$_['column_store']              = '商店';
$_['column_country']            = '国别';
$_['column_date_added']         = '添加日期';
$_['column_comment']            = '备注';
$_['column_description']        = '说明';
$_['column_amount']             = '金额';
$_['column_action']             = '管理';

// Entry
$_['entry_customer']            = '会员';
$_['entry_company']             = '公司名称';
$_['entry_tracking']            = '追踪码';
$_['entry_website']             = '媒体频道';
$_['entry_commission']          = '分润比例 (%)';
$_['entry_tax']                 = 'Tax ID';
$_['entry_payment_method']      = '付款方式';
$_['entry_cheque']              = '支票抬头';
$_['entry_paypal']              = 'PayPal Email Account';
$_['entry_bank_name']           = '银行名称';
$_['entry_bank_branch_number']  = 'ABA/BSB number (Branch Number)';
$_['entry_bank_swift_code']     = 'SWIFT Code';
$_['entry_bank_account_name']   = '银行帐户名称';
$_['entry_bank_account_number'] = '银行帐户号码';
$_['entry_comment']             = '备注';
$_['entry_description']         = '说明';
$_['entry_amount']              = '金额';
$_['entry_date_from']           = '添加日期(起)';
$_['entry_date_to']             = '添加日期(止)';
$_['entry_status']              = '状态';
$_['entry_limit']               = '笔数限制';

// Help
$_['help_tracking']             = '这是用来辨识推荐链接的追踪码。';
$_['help_commission']           = '每一笔订单可分润的 %数';

// Error
$_['error_warning']             = '警告: 请确实检查错误的字段!';
$_['error_permission']          = '警告: 您没有权限编辑会员推荐!';
$_['error_customer']            = '警告: 必须指定会员!';
$_['error_already']             = '警告: 此会员已注册为推荐会员!';
$_['error_tracking']            = '追踪码必须填写!';
$_['error_exists']              = '追踪码已有其他人使用!';
$_['error_payment_method']      = '付款方式必须设置!';
$_['error_cheque']              = '支票抬头必须填写!';
$_['error_paypal']              = 'PayPal Email 帐号不正确!';
$_['error_bank_account_name']   = '银行帐户名称必须填写!';
$_['error_bank_account_number'] = '银行帐户号码必须填写!';
$_['error_custom_field']        = '%s 必须填写!';
