<?php
// Text
$_['text_captcha']  = '验证码';

// Entry
$_['entry_captcha'] = '在下面的文本框中输入验证码';

// Error
$_['error_captcha'] = '您输入的验证码有误!';