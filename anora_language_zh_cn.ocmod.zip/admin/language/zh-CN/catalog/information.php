<?php
// Heading
$_['heading_title']			  = '页面管理';

// Text
$_['text_success']			  = '成功: 商店信息页面设置已更新！';
$_['text_list']				  = '页面清单';
$_['text_add']				  = '添加信息页面';
$_['text_edit']				  = '编辑信息页面';
$_['text_default']	 		  = '默认';
$_['text_keyword']            = '请勿使用空格，使用 - 取代空格，并确定静态网址(SEO URL)是没有重复过的。';

// Column
$_['column_title']			  = '页面标题';
$_['column_sort_order']		  = '排序';
$_['column_action']			  = '管理';

// Entry
$_['entry_title']			  = '页面标题';
$_['entry_description']		  = '页面内容';
$_['entry_meta_title'] 		  = 'Meta 标签标题';
$_['entry_meta_keyword'] 	  = 'Meta 标签关键字';
$_['entry_meta_description']  = 'Meta 标签描述';
$_['entry_store']			  = '商店';
$_['entry_keyword']			  = '静态网址';
$_['entry_bottom']			  = '页面底部';
$_['entry_status']			  = '状态';
$_['entry_sort_order'] 		  = '显示排序';
$_['entry_layout']			  = '指定模板';

// Help
$_['help_bottom']			  = '在页面底部显示';

// Error 
$_['error_warning']			  = '警告: 数据未正确输入！';
$_['error_permission']		  = '警告: 您没有权限编辑商店信息页面！';
$_['error_title']			  = '页面标题必须是 1 到 64 个字！';
$_['error_description']		  = '页面内容长度不得少于 3 个字！';
$_['error_meta_title']		  = 'Meta 标题必须是 1 到 255 个字！';
$_['error_keyword']			  = '静态网址(SEO URL)必须是 1 到 64 个字!';
$_['error_keyword_exists']	  = '静态网址(SEO URL)必须是没有重复的!';
$_['error_keyword_character'] = '静态网址(SEO URL)只能使用 a-z, 0-9, - and _ 等字符!';
$_['error_account']			  = '警告: 此页面不能被删除，因为它是目前为默认的商店会员条款！';
$_['error_checkout']		  = '警告: 此页面不能被删除，因为它是目前为默认的商店结帐条款！';
$_['error_affiliate']		  = '警告: 此页面不能被删除，因为它是目前为默认的商店推荐条款！';
$_['error_return']			  = '警告: 此页面不能被删除，因为它是目前为默认的商店退换条款！';
$_['error_store']			  = '警告: 此页面不能被删除，因为目前已有 %s 家商店使用中！';