<?php
// Text
$_['text_success']   = '成功: 币别已变更!';

// Error
$_['error_currency'] = '警告: 币别代码无效!';