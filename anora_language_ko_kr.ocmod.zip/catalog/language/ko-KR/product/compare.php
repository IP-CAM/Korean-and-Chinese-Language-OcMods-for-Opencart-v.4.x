<?php
// Heading
$_['heading_title'] = '제품 비교';
 
//텍스트
$_['text_product'] = '제품 세부정보';
$_['text_name'] = '제품';
$_['text_image'] = '사진';
$_['text_price'] = '가격';
$_['text_model'] = '모델';
$_['text_manufacturer'] = '브랜드';
$_['text_availability'] = '재고현황';
$_['text_instock'] = '재고 있음';
$_['text_rated'] = '평점';
$_['text_reviews'] = '%s개의 리뷰를 기반으로 함';
$_['text_summary'] = '요약';
$_['text_weight'] = '체중';
$_['text_dimension'] = '크기(길이 x 너비 x 높이)';
$_['text_compare'] = '제품 비교(%s)';
$_['text_success'] = '성공: <a href="%s">%s</a>를 <a href="%s">제품 비교 목록</a>에 추가했습니다! ';
$_['text_remove'] = '성공: 제품 비교 목록을 업데이트했습니다! ';
$_['text_no_results'] = '비교할 제품을 선택하지 않았습니다. ';

// 오류
$_['error_product'] = '경고: 제품을 찾을 수 없습니다!';