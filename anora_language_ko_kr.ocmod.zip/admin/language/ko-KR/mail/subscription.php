<?php
//텍스트
$_['text_subject'] = '%s - 구독';
$_['text_subscription_id'] = '구독ID';
$_['text_date_added'] = '구독 날짜:';
$_['text_subscription_status'] = '귀하의 구독이 다음 상태로 변경되었습니다:';
$_['text_comment'] = '구독 지침:';
$_['text_pay_method'] = '결제수단';
$_['text_pay_code'] = '결제수단 코드';
$_['text_footer'] = '질문이 있으시면 이 편지에 회신해 주십시오.';