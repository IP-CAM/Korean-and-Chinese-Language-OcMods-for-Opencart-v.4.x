<?php
// Heading
$_['heading_title']    = '红利点数';

// Text
$_['text_extension']   = '扩展模块';
$_['text_success']     = '成功: 红利点数模块设置已更新！';
$_['text_edit']        = '编辑红利点数模块';

// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告: 您没有权限编辑红利点数模块！';