<?php
//텍스트
$_['text_success'] = '성공: API 세션이 성공적으로 활성화되었습니다! ';

// 오류
$_['error_permission'] = '경고: 이 API를 사용할 권한이 없습니다!';
$_['error_key'] = '경고: API 키가 올바르지 않습니다!';
$_['error_ip'] = '경고: 귀하의 IP %s은(는) 이 API를 사용할 수 없습니다!';