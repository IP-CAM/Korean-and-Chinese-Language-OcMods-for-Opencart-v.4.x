<?php
// Heading 
$_['heading_title'] = '热卖商品';