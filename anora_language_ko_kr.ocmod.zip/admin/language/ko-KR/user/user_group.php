<?php
// 제목
$_['heading_title'] = '관리자 그룹';

//텍스트
$_['text_success'] = '성공: 관리자 그룹 설정이 업데이트되었습니다! ';
$_['text_list'] = '관리자 그룹';
$_['text_add'] = '관리자 그룹 추가';
$_['text_edit'] = '관리자 그룹 편집';
$_['text_access'] = '접속';
$_['text_modify'] = '수정';

//열
$_['column_name'] = '관리자 그룹 이름';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '관리자 그룹 이름';
$_['entry_permission'] = '권한';
$_['entry_extension'] = '모듈';

// 오류
$_['error_permission'] = '경고: 관리자 그룹을 변경할 권한이 없습니다! ';
$_['error_name'] = '관리자 그룹 이름은 3~64자여야 합니다! ';
$_['error_user'] = '경고: %s 관리자 계정이 이미 이 그룹에 속해 있기 때문에 이 관리자 계정 그룹을 삭제할 수 없습니다! ';