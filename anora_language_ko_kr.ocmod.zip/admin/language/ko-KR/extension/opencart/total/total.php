<?php
// 제목
$_['heading_title'] = '총 주문량';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 주문 전체 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '주문 전체 모듈 편집';

// 항목
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 총 주문 모듈을 편집할 수 있는 권한이 없습니다! ';