<?php
// 제목
$_['heading_title'] = '템플릿 편집';

//텍스트
$_['text_success'] = '성공: 템플릿 편집 설정이 업데이트되었습니다!';
$_['text_edit'] = '템플릿 편집';
$_['text_store'] = '상점 선택';
$_['text_template'] = '웹사이트 템플릿 선택';
$_['text_default'] = '기본값';
$_['text_extension'] = '확장 모듈';
$_['text_history'] = '템플릿 편집 기록';
$_['text_twig'] = '템플릿 편집 기능은 Twig 구문을 사용합니다. <a href="http://twig.sensiolabs.org/documentation" target="_blank" class="alert-link"를 참조하세요. >Twig 문법 문서</a>.';

//열
$_['column_store'] = '저장';
$_['column_route'] = '경로';
$_['column_date_added'] = '추가된 날짜';
$_['column_action'] = '액션';

// 오류
$_['error_permission'] = '경고: 템플릿 편집기를 수정할 권한이 없습니다!';
$_['error_twig'] = '경고: .twig 문서만 저장할 수 있습니다!';