<?php
// 제목
$_['heading_title'] = '제품 기능';

//텍스트
$_['text_success'] = '성공: 제품 기능 설정이 업데이트되었습니다! ';
$_['text_list'] = '제품 기능 목록';
$_['text_add'] = '제품 기능 추가';
$_['text_edit'] = '제품 특성 편집';
$_['text_group'] = '제품 특성 그룹';
$_['text_value'] = '제품특성값';

//열
$_['column_group'] = '제품특성그룹';
$_['column_sort_order'] = '정렬 표시';
$_['column_action'] = '관리';

// 항목
$_['entry_group'] = '상품속성그룹명';
$_['entry_name'] = '제품 기능 이름';
$_['entry_sort_order'] = '정렬 표시';

// 오류
$_['error_warning'] = '경고: 양식 필드에 작성된 내용을 확인하십시오!';
$_['error_permission'] = '경고: 제품 특성을 수정할 권한이 없습니다! ';
$_['error_group'] = '제품 기능 그룹 이름은 1~64자여야 합니다! ';
$_['error_name'] = '제품 기능 이름은 1~64자여야 합니다! ';
$_['error_values'] = '경고: 상품 속성 값을 입력해야 합니다!';