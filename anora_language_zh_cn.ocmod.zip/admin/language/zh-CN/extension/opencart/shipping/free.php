<?php
// Heading
$_['heading_title']    = '免运费';

// Text
$_['text_extension']   = '扩充功能';
$_['text_success']     = '成功: 免运费模块设置已更新！';
$_['text_edit']        = '编辑免运费模块';

// Entry
$_['entry_total']      = '最低订单金额';
$_['entry_geo_zone']   = '适用地区';
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Help
$_['help_total']       = '可使用免运费的最低订单金额。';

// Error
$_['error_permission'] = '警告: 您没有权限修改免运费模块！';