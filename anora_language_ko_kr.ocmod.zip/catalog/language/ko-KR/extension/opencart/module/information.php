<?php
// 제목
$_['heading_title'] = '상점정보';

//텍스트
$_['text_contact'] = '연락처';
$_['text_sitemap'] = '웹사이트 탐색';