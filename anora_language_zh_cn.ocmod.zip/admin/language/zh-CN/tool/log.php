<?php
// Heading
$_['heading_title']    = '错误日志';

// Text
$_['text_success']     = '成功: 错误日志已清除！';
$_['text_list']        = '错误清单';

// Error
$_['error_permission'] = '警告: 您没有权限清调试误日志！';
$_['error_file']       = 'Warning: %s file could not be found!';
$_['error_size']       = 'Warning: 错误日志文档 %s is %s!';
$_['error_empty']      = 'Warning: 错误日志文档 %s is empty!';