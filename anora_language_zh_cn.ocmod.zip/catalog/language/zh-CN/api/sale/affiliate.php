<?php
// Text
$_['text_success']    = '成功: 推荐奖金将被套用在此订单!';
$_['text_remove']     = '成功: 推荐奖金已被移除!';

// Error
$_['error_affiliate'] = '警告: 找不到推荐数据!';