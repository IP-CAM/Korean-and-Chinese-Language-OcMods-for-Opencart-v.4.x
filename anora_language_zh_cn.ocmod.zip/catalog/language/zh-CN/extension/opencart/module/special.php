<?php
// Heading 
$_['heading_title'] = '特价商品';