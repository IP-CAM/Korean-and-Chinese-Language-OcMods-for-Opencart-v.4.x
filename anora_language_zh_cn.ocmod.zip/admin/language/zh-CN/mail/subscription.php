<?php
// Text
$_['text_subject']             = '%s - 订阅';
$_['text_subscription_id']     = '订阅 ID';
$_['text_date_added']          = '订阅日期:';
$_['text_subscription_status'] = '您的订阅已被变更为下面的状态:';
$_['text_comment']             = '您的订阅说明:';
$_['text_payment_method']      = '付款方式';
$_['text_payment_code']        = '付款方式代码';
$_['text_footer']              = '若有任何问题请回复此信件';
