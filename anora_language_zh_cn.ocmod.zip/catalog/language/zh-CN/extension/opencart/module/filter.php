<?php
// Heading
$_['heading_title'] = '商品特性筛选';