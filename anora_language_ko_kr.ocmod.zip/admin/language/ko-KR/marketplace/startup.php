<?php
// 제목
$_['heading_title'] = '시작 모듈';

//텍스트
$_['text_success'] = '성공: 시작 모듈이 업데이트되었습니다!';
$_['text_list'] = '시작 모듈 목록';

//열
$_['column_code'] = '시작코드';
$_['column_sort_order'] = '정렬';
$_['column_action'] = '액션';

// 오류
$_['error_permission'] = '경고: 시작 모듈을 편집할 수 있는 권한이 없습니다!';