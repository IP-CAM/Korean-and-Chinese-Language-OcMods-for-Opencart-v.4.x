<?php
// Heading
$_['heading_title']         = '会员地址';

// Text
$_['text_address_new']      = '添加地址';
$_['text_address_existing'] = '使用常用地址';
$_['text_success']          = '成功: 会员地址已更新!';

// Entry
$_['entry_address']         = '选择地址';
$_['entry_firstname']       = '名字';
$_['entry_lastname']        = '姓氏';
$_['entry_company']         = '公司名称';
$_['entry_address_1']       = '地址';
$_['entry_address_2']       = '地址 2';
$_['entry_postcode']        = '邮递区号';
$_['entry_city']            = '乡镇市区';
$_['entry_country']         = '国家';
$_['entry_zone']            = '县市/地区';

// Error
$_['error_customer']        = '必须有客户数据!';
$_['error_address']         = '警告: 找不到会员地址!';
$_['error_firstname']       = '名字必须是 1 到 32 个字!';
$_['error_lastname']        = '姓氏必须是 1 到 32 个字!';
$_['error_address_1']       = '地址的长度必须是 3 到 128 个字!';
$_['error_city']            = '乡镇市区必须是 2 到 128 个字!';
$_['error_postcode']        = '邮递区号必须是 2 到 10 个字!';
$_['error_country']         = '请选择一个国家!';
$_['error_zone']            = '请选择县市/地区!';
$_['error_custom_field']    = '%s 字段必须输入!';
$_['error_regex']           = '%s 不是有效的值!';
