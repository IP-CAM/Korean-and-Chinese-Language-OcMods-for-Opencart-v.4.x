<?php
// Text
$_['text_search'] = '검색';
$_['text_brand'] = '제품 브랜드:';
$_['text_manufacturer'] = '브랜드:';
$_['text_model'] = '제품 모델:';
$_['text_reward'] = '보너스 포인트:';
$_['text_points'] = '포인트를 사용하여 구매하세요:';
$_['text_stock'] = '재고상태:';
$_['text_instock'] = '재고 있음';
$_['text_tax'] = '비과세:';
$_['text_discount'] = '개(포함) 이상';
$_['text_option'] = '스타일 및 크기:';
$_['text_minimum'] = '이 제품의 최소 구매 수량은 %s개입니다';
$_['text_reviews'] = '%s 제품 리뷰';
$_['text_write'] = '이 제품에 대해 질문이 있는 경우 여기에 의견과 제안을 남겨주세요! ';
$_['text_login'] = '제품 리뷰를 보려면 <a href="%s">로그인</a>하거나 <a href="%s">등록</a>하세요! ';
$_['text_관련'] = '관련 상품';
$_['text_tags'] = '태그:';
$_['text_error'] = '이 제품은 존재하지 않습니다! ';
$_['text_subscription'] = '일반 결제 방식';
$_['text_subscription_trial'] = '%s가 %d를 지불한 후 %d마다';
$_['text_subscription_duration'] = '할부 %s당 지불, %d %s마다 1회 할부, 총 %d 할부';
$_['text_subscription_cancel'] = '취소될 때까지 %s마다 %d %s';
$_['text_day'] = '일';
$_['text_week'] = '주';
$_['text_semi_month'] = '반달';
$_['text_month'] = '월';
$_['text_year'] = '연도';

// 항목
$_['entry_qty'] = '수량';
$_['entry_rating']               = '평가';

// Tabs
$_['tab_description'] = '제품 설명';
$_['tab_attribute'] = '제품 속성';
$_['tab_review'] = '제품 리뷰(%s개의 제품 리뷰가 있습니다)';
