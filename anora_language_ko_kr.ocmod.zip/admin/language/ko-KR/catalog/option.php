<?php
// 제목
$_['heading_title'] = '제품 옵션';

//텍스트
$_['text_success'] = '성공: 옵션 데이터 설정이 업데이트되었습니다! ';
$_['text_list'] = '옵션 목록';
$_['text_add'] = '옵션 추가';
$_['text_edit'] = '편집 옵션';
$_['text_choose'] = '선택';
$_['text_select'] = '목록';
$_['text_radio'] = '라디오 선택';
$_['text_checkbox'] = '체크박스';
$_['text_input'] = '텍스트 상자';
$_['text_text'] = '텍스트';
$_['text_textarea'] = '여러줄 텍스트 상자';
$_['text_file'] = '문서';
$_['text_date'] = '날짜';
$_['text_datetime'] = '날짜 및 시간';
$_['text_time'] = '시간';
$_['text_option'] = '옵션';
$_['text_value'] = '옵션 값';

//열
$_['column_name'] = '옵션 이름';
$_['column_sort_order'] = '정렬 표시';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '옵션 이름';
$_['entry_type'] = '유형';
$_['entry_option_value'] = '옵션 값';
$_['entry_image'] = '이미지';
$_['entry_sort_order'] = '정렬 표시';

// 오류
$_['error_warning'] = '경고: 양식 필드에 작성된 내용을 확인하십시오!';
$_['error_permission'] = '경고: 제품 옵션을 수정할 권한이 없습니다! ';
$_['error_name'] = '옵션 이름은 1~128자여야 합니다! ';
$_['error_type'] = '경고: 옵션 값을 입력해야 합니다! ';
$_['error_option_value'] = '옵션 값의 이름은 1~128자여야 합니다! ';
$_['error_value'] = '경고: %s 항목이 이미 사용 중이므로 이 옵션 값을 삭제할 수 없습니다!';
$_['error_product'] = '경고: %s 제품이 이미 사용 중이므로 이 옵션을 삭제할 수 없습니다! ';