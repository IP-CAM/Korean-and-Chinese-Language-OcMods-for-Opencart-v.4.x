<?php
// Heading
$_['heading_title']    = '管理员群组';

// Text
$_['text_success']     = '成功: 管理员群组设置已更新！';
$_['text_list']        = '管理员群组';
$_['text_add']         = '添加管理员群组';
$_['text_edit']        = '编辑管理员群组';
$_['text_access']      = 'Access';
$_['text_modify']      = 'Modify';

// Column
$_['column_name']      = '管理员群组名称';
$_['column_action']    = '管理';

// Entry
$_['entry_name']       = '管理员群组名称';
$_['entry_permission'] = '权限';
$_['entry_extension']  = '模块';

// Error
$_['error_permission'] = '警告: 您没有权限更改管理员群组！';
$_['error_name']       = '管理员群组名称长度必须是 3 到 64 个字！';
$_['error_user']       = '警告: 此管理员帐号群组不能被删除，因为已有 %s 位管理员帐号属于此群组！';