<?php
// Heading
$_['heading_title']     = '营销活动';

// Text
$_['text_success']      = '成功: 营销活动管理设置已更新！';
$_['text_list']         = '营销活动清单';
$_['text_add']          = '添加营销活动';
$_['text_edit']         = '编辑营销活动';
$_['text_filter']       = '活动筛选';
$_['text_history']      = '活动纪录';
$_['text_history_add']  = '添加纪录';
$_['text_report']       = '统计报表';

// Column
$_['column_name']       = '活动名称';
$_['column_code']       = '追踪代码';
$_['column_clicks']     = '浏览次数';
$_['column_orders']     = '订单数';
$_['column_ip']         = 'IP';
$_['column_account']    = '帐号';
$_['column_store']      = '商店';
$_['column_country']    = '国别';
$_['column_date_added'] = '添加日期';
$_['column_action']     = '管理';

// Entry
$_['entry_name']        = '活动名称';
$_['entry_description'] = '活动说明';
$_['entry_code']        = '追踪代码';
$_['entry_example']     = '链接范例';
$_['entry_date_from']   = '添加日期(起)';
$_['entry_date_to']     = '添加日期(止)';

// Help
$_['help_code']         = '追踪代码将被使用在营销活动中。';
$_['help_example']      = '将追踪代码加在网址后面，以便系统能追踪到推荐者。';

// Error
$_['error_permission']  = '警告: 您没有权限修改营销活动 !';
$_['error_name']        = '活动名称必须是 1 到 32 个字 !';
$_['error_code']        = '追踪代码必须填写 !';
$_['error_exists']      = '此追踪代码已被使用在其他的营销活动中!';