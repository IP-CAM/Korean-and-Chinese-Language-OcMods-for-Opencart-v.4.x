<?php
// Text
$_['text_subject'] = '%s - 추천 보너스';
$_['text_received'] = '축하합니다! %s로부터 추천 보너스를 받았습니다';
$_['text_amount'] = '당신은 다음을 받았습니다:';
$_['text_total'] = '현재 추천 보너스는:';