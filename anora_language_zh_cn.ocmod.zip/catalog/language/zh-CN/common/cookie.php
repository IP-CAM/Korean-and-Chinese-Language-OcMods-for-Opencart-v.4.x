<?php
// Text
$_['text_success']    = '感谢您让我们知道您的选择!';
$_['text_cookie']     = '本网站使用 cookies 保存数据，请点击阅读 <a href="%s" class="alert-link modal-link">详细内容</a>。';

// Button
$_['button_agree']    = '同意!';
$_['button_disagree'] = '不同意!';