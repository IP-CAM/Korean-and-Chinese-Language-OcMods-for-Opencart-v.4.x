<?php
// 제목
$_['heading_title'] = '통계 보고서';

//텍스트
$_['text_success'] = '성공: 통계 보고서 설정이 업데이트되었습니다!';
$_['text_type'] = '통계 보고서 유형 선택';
$_['text_filter'] = '조건부 필터';