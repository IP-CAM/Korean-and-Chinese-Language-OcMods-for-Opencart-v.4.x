<?php
// Heading
$_['heading_title']    = '简体中文';

// Text
$_['text_home']        = '首页';
$_['text_headline']    = '简体中文';
$_['text_extension']   = '扩展模块';
$_['text_success']     = '成功：简体中文已更新!';
$_['text_edit']        = '编辑简体中文';
$_['text_translation'] = '翻译';
$_['text_version']     = '版本';
$_['language_version'] = 'V4.0.2.2';
$_['text_translator']  = 'Jaxon';
$_['text_improfment']  = '';

// Entry
$_['entry_status']     = '状态';
$_['entry_frontend']   = '前端';
$_['entry_stores']     = '商店';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告：您没有权限编辑简体中文!';
