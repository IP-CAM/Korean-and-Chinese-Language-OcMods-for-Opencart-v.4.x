<?php
// Heading
$_['heading_title']    = '宅配';

// Text
$_['text_description'] = '宅配';