<?php
// Heading
$_['heading_title']			= '管理员管理';

// Text
$_['text_success']			= '成功: 管理员帐号设置已更新！';
$_['text_list']				= '管理员帐号清单';
$_['text_add']				= '添加管理员帐号';
$_['text_edit']				= '编辑管理员帐号';
$_['text_user']             = '管理员数据';
$_['text_password']         = '密码';
$_['text_user_login']       = '管理员登录';
$_['text_other']            = '其他';
$_['text_login']            = '登录纪录';

// Column
$_['column_username']   	= '管理员帐号';
$_['column_status']     	= '状态';
$_['column_ip']             = 'IP';
$_['column_user_agent']     = 'User Agent';
$_['column_date_added'] 	= '添加日期';
$_['column_action']    	 	= '管理';

// Entry
$_['entry_username']    	= '管理员帐号';
$_['entry_user_group']  	= '帐号群组';
$_['entry_password']    	= '密码';
$_['entry_confirm']     	= '确认密码';
$_['entry_firstname']   	= '名字';
$_['entry_lastname']    	= '姓氏';
$_['entry_email']       	= 'E-Mail';
$_['entry_image']      		= '图片';
$_['entry_status']      	= '状态';

// Tab
$_['tab_login']             = '登录';

// Error
$_['error_permission']  	= '警告: 您没有权限更改管理员帐号！';
$_['error_account']     	= '警告: 您不能删除自己的帐号！';
$_['error_login']           = '警告: 帐号登录不存在!';
$_['error_username']		= '管理员帐号必须是 3 到 20 个字！';
$_['error_username_exists'] = '警告: 管理员帐号已经存在！';
$_['error_firstname']		= '名字必须是 1 到 32 个字！';
$_['error_lastname']		= '姓氏必须是 1 到 32 个字！';
$_['error_email']           = 'E-Mail 帐号无效!';
$_['error_email_exists']    = '警告: E-Mail 帐号已经注册过!';
$_['error_password']		= '密码长度必须是 4 到 20 个字！';
$_['error_confirm']			= '密码和确认密码不一致！';
