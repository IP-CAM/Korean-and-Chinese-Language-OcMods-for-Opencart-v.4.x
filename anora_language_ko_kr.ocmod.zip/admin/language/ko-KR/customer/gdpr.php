<?php
// 제목
$_['heading_title'] = 'GDPR 승인';

//텍스트
$_['text_success'] = '성공: GDPR 승인이 업데이트되었습니다!';
$_['text_list'] = 'GDPR 승인 목록';
$_['text_info'] = '<strong>GDPR</strong> 계정 삭제 요청은 <strong>%s일</strong> 후에 처리되므로 사기 감지, 지불 거절 또는 환불이 처리될 수 있습니다.';
$_['text_approve'] = '승인';
$_['text_deny'] = '거부';
$_['text_delete'] = '삭제';
$_['text_unverified'] = '확인되지 않음';
$_['text_pending'] = '대기 중';
$_['text_processing'] = '처리 중';
$_['text_complete'] = '완료';
$_['text_denied'] = '거부됨';
$_['text_export'] = '내보내기';
$_['text_remove'] = '제거';
$_['text_filter'] = '필터';

//열
$_['column_email'] = '이메일';
$_['column_request'] = '요청';
$_['column_status'] = '상태';
$_['column_date_add'] = '날짜 추가';
$_['column_action'] = '액션';

// 항목
$_['entry_email'] = '이메일';
$_['entry_action'] = '액션';
$_['entry_status'] = '상태';
$_['entry_date_from'] = '시작일';
$_['entry_date_to'] = '마감일';

// 오류
$_['error_permission'] = '경고: GDPR 승인을 관리할 권한이 없습니다!';