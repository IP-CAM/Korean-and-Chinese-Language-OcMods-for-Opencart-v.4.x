<?php
// Heading
$_['heading_title']     = '启动模块';

// Text
$_['text_success']      = '成功: 启动模块已更新!';
$_['text_list']         = '启动模块清单';

// Column
$_['column_code']       = '启动码';
$_['column_sort_order'] = '排序';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 您没有权限编辑启动模块!';
