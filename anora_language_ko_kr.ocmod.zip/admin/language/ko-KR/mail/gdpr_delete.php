<?php
// 텍스트
$_['text_subject'] = '%s - GDPR 요청이 처리되었습니다!';
$_['text_request'] = '계정 삭제 요청';
$_['text_hello'] = '안녕하세요 <strong>%s</strong>,';
$_['text_user'] = '사용자';
$_['text_delete'] = '귀하의 GDPR 데이터 삭제 요청이 이제 완료되었습니다.';
$_['text_contact'] = '더 많은 정보를 원하시면 여기에서 상점 주인에게 연락하실 수 있습니다:';
$_['text_thanks'] = '감사합니다';

// 버튼
$_['button_contact'] = '문의하기';