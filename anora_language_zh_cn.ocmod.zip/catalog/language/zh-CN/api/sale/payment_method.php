<?php
// Text
$_['text_success']          = '成功: 付款方式已套用!';

// Error
$_['error_payment_address'] = '警告: 必须有会员地址!';
$_['error_payment_method']  = '警告: 必须有付款方式!';
$_['error_no_payment']      = '警告: 没有可用的商品选项!';
$_['error_product']         = '警告: 必须有商品!';