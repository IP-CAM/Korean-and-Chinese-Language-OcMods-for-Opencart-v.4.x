<?php
// Text
$_['text_subject'] = '%s - 등록해주셔서 감사합니다';
$_['text_welcome'] = '%s에 참여해 주셔서 감사합니다!';
$_['text_login'] = '귀하의 계정이 생성되었습니다. 귀하의 이메일과 비밀번호를 사용하여 당사 웹사이트 또는 다음 URL에 로그인하실 수 있습니다:';
$_['text_approval'] = '귀하의 계정은 로그인하기 전에 승인되어야 합니다. 검토를 통과한 후, 귀하는 당사 웹사이트 또는 다음 URL로 이동하여 귀하의 이메일과 비밀번호를 사용하여 로그인할 수 있습니다:';
$_['text_service'] = '로그인 후 주문현황 확인, 주문기록 조회, 기타 관리항목을 확인하실 수 있습니다. ';
$_['text_thanks'] = '감사합니다';
$_['text_new_customer'] = '새 회원';
$_['text_signup'] = '새 회원이 등록되었습니다:';
$_['text_customer_group'] = '회원등급:';
$_['text_firstname'] = '이름:';
$_['text_lastname'] = '성:';
$_['text_email'] = '이메일:';
$_['text_telephone'] = '전화번호:';

// 버튼
$_['button_login'] = '로그인';