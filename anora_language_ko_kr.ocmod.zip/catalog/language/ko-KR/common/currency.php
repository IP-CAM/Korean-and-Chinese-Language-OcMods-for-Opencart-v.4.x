<?php
// 텍스트
$_['text_currency'] = '금';