<?php
// Heading 
$_['heading_title'] = '结帐';

// Text
$_['text_cart']     = '购物车';
