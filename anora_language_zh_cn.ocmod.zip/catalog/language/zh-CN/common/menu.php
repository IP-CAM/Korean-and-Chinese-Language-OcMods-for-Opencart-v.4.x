<?php
// Text
$_['text_category']  = '分类';
$_['text_all']       = '全部显示';