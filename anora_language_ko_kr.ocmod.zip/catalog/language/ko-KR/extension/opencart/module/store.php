<?php
// 제목
$_['heading_title'] = '상점 선택';

//텍스트
$_['text_default'] = '기본값';
$_['text_store'] = '탐색하려는 매장을 선택하세요';