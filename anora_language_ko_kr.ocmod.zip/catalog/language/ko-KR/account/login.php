<?php
// Heading 
$_['heading_title'] = '회원 로그인';

//텍스트
$_['text_account'] = '내 계정';
$_['text_login'] = '로그인';
$_['text_new_customer'] = '새 회원';
$_['text_register'] = '계정 등록';
$_['text_register_account'] = '계정을 등록하시면 더 빠르게 쇼핑하고, 주문 상태를 확인하고, 주문 기록을 확인하고, 더 많은 상품을 관리하실 수 있습니다. ';
$_['text_returning_customer'] = '회원 로그인';
$_['text_i_am_returning_customer'] = '이미 이 사이트의 회원이시라면 직접 로그인하시기 바랍니다. ';
$_['text_forgotten'] = '비밀번호를 잊으셨나요? ';

// 항목
$_['entry_email'] = '이메일 편지함';
$_['entry_password'] = '비밀번호';

// 오류
$_['error_token'] = '경고: 키가 만료되었습니다!';
$_['error_login'] = '경고: 이메일이나 비밀번호가 일치하지 않습니다! ';
$_['error_attempts'] = '경고: 귀하의 계정에 대한 로그인 시도 실패 횟수가 한도에 도달했습니다. 1시간 후에 다시 시도하십시오!';
$_['error_approved'] = '경고: 귀하의 계정은 아직 승인되지 않았습니다! ';