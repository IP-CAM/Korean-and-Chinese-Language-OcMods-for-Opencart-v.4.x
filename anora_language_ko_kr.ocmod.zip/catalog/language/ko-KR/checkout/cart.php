<?php
// Heading  
$_['heading_title']              = '쇼핑 카트';

// Text
$_['text_success'] = '성공: <a href="%s">%s</a> 제품이 <a href="%s">장바구니</a>에 추가되었습니다! ';
$_['text_edit'] = '성공: 장바구니 내용이 업데이트되었습니다!';
$_['text_remove'] = '성공: 장바구니에서 항목이 제거되었습니다! ';
$_['text_login'] = '경고: 판매를 표시하려면 <a href="%s">로그인</a>하거나 <a href="%s">새 계정을 등록</a>해야 합니다. 가격! ';
$_['text_no_results'] = '장바구니에 품목이 없습니다! ';
$_['text_next'] = '다음에 무엇을 하고 싶으신가요? ';
$_['text_next_choice'] = '할인쿠폰, 할인포인트, 예상배송비 중 선택하세요';
$_['text_points'] = '보너스 포인트';
$_['text_subscription'] = '구독 계획';
$_['text_subscription_trial'] = '%s 매 %d %s(s)마다 %d 결제 후 ';
$_['text_subscription_duration'] = '%s 매 %d %s(s)마다 %d 결제';
$_['text_subscription_cancel'] = '취소될 때까지 %s마다 %d %s(s)';
$_['text_day'] = '매일';
$_['text_week'] = '매주';
$_['text_semi_month'] = '반월마다';
$_['text_month'] = '매월';
$_['text_year'] = '매년';

//열
$_['column_image'] = '사진';
$_['column_name'] = '제품명';
$_['column_model'] = '모델';
$_['column_quantity'] = '수량';
$_['column_price'] = '판매가';
$_['column_total'] = '전체';

// 오류
$_['error_stock'] = '*** 표시가 있는 품목은 수량이 부족하거나 재고가 없음을 나타냅니다! ';
$_['error_minimum'] = '%s 최소 구매 수량은 %s 개입니다! ';
$_['error_required'] = '%s을(를) 입력해야 합니다! ';
$_['error_product'] = '경고: 장바구니에 품목이 없습니다! ';
$_['error_subscription'] = '구독 요금제를 선택하세요! ';