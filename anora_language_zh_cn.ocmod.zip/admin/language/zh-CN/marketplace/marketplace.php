<?php
// Heading
$_['heading_title']      = '扩展模块市集';

// Text
$_['text_success']       = '成功: 扩展模块市集设置已更新!';
$_['text_list']          = '扩展模块清单';
$_['text_filter']        = '模块筛选';
$_['text_search']        = '搜索扩展模块或版型';
$_['text_category']      = '分类';
$_['text_all']           = '全部';
$_['text_theme']         = '布景主题';
$_['text_marketplace']   = '扩展模块市集';
$_['text_language']      = '语系';
$_['text_payment']       = '支付模块';
$_['text_shipping']      = '运送模块';
$_['text_module']        = '功能模块';
$_['text_total']         = '订单总计模块';
$_['text_feed']          = 'Feeds 模块';
$_['text_report']        = '报表模块';
$_['text_other']         = '其他模块';
$_['text_free']          = '免费';
$_['text_paid']          = '付费';
$_['text_purchased']     = '已购买';
$_['text_recommended']   = '推荐的';
$_['text_date_modified'] = '更新日期';
$_['text_date_added']    = '添加日期';
$_['text_rating']        = '评价';
$_['text_reviews']       = '则评论';
$_['text_compatibility'] = '兼容性';
$_['text_downloaded']    = '下载数';
$_['text_member_since']  = '加入会员日期:';
$_['text_price']         = '售价';
$_['text_featured']      = '特色的';
$_['text_partner']       = '由 OpenCart 开发伙伴设计';
$_['text_support']       = '12 个月的免费技术支持';
$_['text_documentation'] = '已内含使用说明文档';
$_['text_sales']         = '已销售';
$_['text_comment']       = '问与答';
$_['text_download']      = '下载中';
$_['text_install']       = '安装中';
$_['text_comment_add']   = '问题提问';
$_['text_write']         = '填写您的问题..';
$_['text_purchase']      = '请确认您的身分!';
$_['text_pin']           = '请输入您的 4 位数 PIN 码，PIN 码是用来保护您的帐号。';
$_['text_secure']        = '请勿提供您的 PIN 码给任何人(包括模块厂商)，如果您需要请模块厂商帮您进行安装，您只要告诉他们您要安装哪一个模块即可。';
$_['text_name']          = '下载名称';
$_['text_available']     = '可安装';
$_['text_action']        = '操作';
$_['text_install']       = '安装';
$_['text_uninstall']     = '卸载';
$_['text_delete']        = '删除';
$_['text_more']          = '观看更多回复...';
$_['text_refresh']		 = '重刷';

// Entry
$_['entry_pin']          = 'PIN 码';

// Tab
$_['tab_description']    = '基本数据';
$_['tab_documentation']  = '详细说明';
$_['tab_download']       = '文档下载';
$_['tab_comment']        = '问与答';

// Button
$_['button_api']         = '扩展模块市集 API';
$_['button_purchase']    = '购买';
$_['button_view_all']    = '查看所有扩展模块';
$_['button_support']     = '请求支持';
$_['button_comment']     = '提问';
$_['button_reply']       = '回复';
$_['button_forgot_pin']  = '忘记 PIN 码';

// Error
$_['error_permission']   = '警告: 您没有权限编辑扩展模块!';
$_['error_api']          = '警告: 您必须输入扩展模块市集 API 数据才能购买扩展模块!';
$_['error_purchase']     = '扩展模块无法购买!';
$_['error_download']     = '扩展模块无法下载!';