<?php
// 제목
$_['heading_title'] = '예상 배송비 및 세금';

//텍스트
$_['text_shipping_method'] = '배송방법을 선택해주세요';
$_['text_destination'] = '배송비를 추정하려면 배송지를 입력하세요';
$_['text_estimate'] = '사용할 배송 방법을 선택하세요';
$_['text_success'] = '성공: 예상 배송비가 적용되었습니다! ';

// 항목
$_['entry_country'] = '국가';
$_['entry_zone'] = '군/지역';
$_['entry_postcode'] = '우편번호';

// 오류
$_['error_postcode'] = '우편번호는 2~10자 사이여야 합니다! ';
$_['error_country'] = '국가를 선택하세요! ';
$_['error_zone'] = '국가/지역을 선택하세요! ';
$_['error_shipping'] = '경고: 배송 방법을 선택하세요! ';
$_['error_no_shipping'] = '경고: 배송 옵션이 없습니다. 도움이 필요하면 <a href="%s">저희에게 연락</a>하세요! ';