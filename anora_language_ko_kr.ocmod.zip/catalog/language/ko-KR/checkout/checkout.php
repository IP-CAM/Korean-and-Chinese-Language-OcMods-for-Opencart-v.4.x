<?php
// 제목
$_['heading_title'] = '결제';

//텍스트
$_['text_cart'] = '쇼핑 카트';