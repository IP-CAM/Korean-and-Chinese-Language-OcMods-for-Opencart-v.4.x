<?php
//텍스트
$_['text_subject'] = '보안 확인';
$_['text_code'] = '백엔드 관리를 위한 보안코드를 설정해야 합니다';
$_['text_ip'] = 'IP:';
$_['text_regards'] = '감사합니다';