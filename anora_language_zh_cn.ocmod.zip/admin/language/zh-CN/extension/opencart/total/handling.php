<?php
// Heading
$_['heading_title']    = '手续费';

// Text
$_['text_extension']   = '扩展模块';
$_['text_success']     = '成功: 手续费模块设置已更新！';
$_['text_edit']        = '编辑手续费模块';

// Entry
$_['entry_total']      = '最低订单金额';
$_['entry_fee']        = '手续费';
$_['entry_tax_class']  = '税别';
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Help
$_['help_total']       = '订单金额必须达到最低订单金额才会生效。';

// Error
$_['error_permission'] = '警告: 您没有权限修改手续费模块！';