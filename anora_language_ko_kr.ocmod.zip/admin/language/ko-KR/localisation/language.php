<?php
// 제목
$_['heading_title'] = '언어 관리';

//텍스트
$_['text_success'] = '성공: 언어 관리 설정이 업데이트되었습니다! ';
$_['text_list'] = '언어 목록';
$_['text_add'] = '언어 추가';
$_['text_edit'] = '언어 편집';

//열
$_['column_name'] = '언어 이름';
$_['column_code'] = '코드';
$_['column_sort_order'] = '정렬';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '언어 이름';
$_['entry_code'] = '코드';
$_['entry_extension'] = '확장 모듈';
$_['entry_locale'] = '로케일';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 돕다
$_['help_locale'] = '예: en_US.UTF-8,en_US,en-gb,en_gb,english';
$_['help_status'] = '프론트엔드 언어 선택 표시 여부';

// 오류
$_['error_permission'] = '경고: 언어를 변경할 권한이 없습니다! ';
$_['error_exists'] = '경고: 이미 이 언어를 추가했습니다!';
$_['error_name'] = '언어 이름은 3~32자여야 합니다! ';
$_['error_code'] = '언어 코드는 2단어여야 합니다! ';
$_['error_locale'] = '로캘을 입력해야 합니다!';
$_['error_default'] = '경고: 이 언어는 매장 프론트 데스크의 기본 언어이므로 삭제할 수 없습니다! ';
$_['error_admin'] = '경고: 이 언어는 스토어 백엔드 관리를 위한 기본 언어이므로 삭제할 수 없습니다! ';
$_['error_store'] = '경고: 이 언어는 %s 상점에서 이미 사용하고 있기 때문에 삭제할 수 없습니다! ';
$_['error_order'] = '경고: 이 언어는 이미 %s 주문에서 사용되고 있기 때문에 삭제할 수 없습니다! ';