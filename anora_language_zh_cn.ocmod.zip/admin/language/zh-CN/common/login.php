<?php
// Heading
$_['heading_title']  = '后台管理系统';

// Text
$_['text_heading']   = '后台管理登录！';
$_['text_login']     = '请输入管理帐号及密码。';
$_['text_forgotten'] = '忘记密码';

// Entry
$_['entry_username'] = '管理帐号';
$_['entry_password'] = '管理密码';

// Button
$_['button_login']   = '登录';

// Error
$_['error_login']    = '请输入正确的管理帐号和密码！';
$_['error_token']    = '帐号逾时注销，请重新登录！';