<?php
// 제목
$_['heading_title'] = '교통 통계';

//텍스트
$_['text_success'] = '성공: 교통통계 설정이 업데이트되었습니다!';
$_['text_list'] = '통계 목록';
$_['text_order_sale'] = '판매 주문';
$_['text_order_processing'] = '처리 중인 주문 수';
$_['text_order_complete'] = '완료된 주문 수';
$_['text_order_other'] = '다른 상태의 주문 수';
$_['text_returns'] = '반품 및 교환';
$_['text_customer'] = '검토를 기다리는 고객 수';
$_['text_affiliate'] = '검토를 기다리는 추천 회원 수';
$_['text_product'] = '품절된 상품수';
$_['text_review'] = '검토 대기 중';

//열
$_['column_name'] = '통계명';
$_['column_value'] = '통계값';
$_['column_action'] = '액션';

// 오류
$_['error_permission'] = '경고: 트래픽 통계를 편집할 권한이 없습니다!';