<?php
// Text
$_['text_success']     = '成功: API Session 启用成功！';

// Error
$_['error_permission'] = '警告: 您没有权限使用此 API!';
$_['error_key']        = '警告: API Key 不正确!';
$_['error_ip']         = '警告: 您的 IP %s 并没有被允许使用此 API!';