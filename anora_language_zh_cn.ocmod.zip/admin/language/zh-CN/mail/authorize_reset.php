<?php
// Text
$_['text_subject'] = '重置安全码尝试';
$_['text_reset']   = '安全码已输入错误超过 3 次';
$_['text_link']    = '点击下方的链接以设置安全码:';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Best Regards';