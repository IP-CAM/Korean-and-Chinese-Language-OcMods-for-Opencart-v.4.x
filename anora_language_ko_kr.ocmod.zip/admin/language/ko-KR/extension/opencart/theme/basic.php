<?php
// 제목
$_['heading_title'] = '기본 웹사이트 레이아웃';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 기본 웹사이트 레이아웃 설정이 업데이트되었습니다!';
$_['text_edit'] = '기본 웹사이트 레이아웃 편집';

// 항목
$_['entry_status'] = '상태';

// 오류
$_['error_permission'] = '경고: 기본 웹사이트 레이아웃을 편집할 수 있는 권한이 없습니다! ';