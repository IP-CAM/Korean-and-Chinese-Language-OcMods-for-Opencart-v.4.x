<?php
// Heading
$_['heading_title']    = 'OpenCart 扩展模块市集 API';

// Text
$_['text_success']     = '成功: 扩展模块市集 API 模块设置已更新!';
$_['text_signup']      = '请输入您的 opencart API 帐号信息，若您尚未有 opencart API 帐号，请至 <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link">这里</a> 申请。';

// Entry
$_['entry_username']   = 'Username';
$_['entry_secret']     = 'Secret';

// Error
$_['error_permission'] = '警告: 您没有权限编辑扩展模块市集 API!';
$_['error_username']   = 'Username 必须输入!';
$_['error_secret']     = 'Secret 必须输入!';
