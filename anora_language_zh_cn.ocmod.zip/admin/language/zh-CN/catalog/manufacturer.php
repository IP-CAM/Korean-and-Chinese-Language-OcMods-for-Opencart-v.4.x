<?php
// Heading
$_['heading_title']			= '品牌/厂牌';

// Text
$_['text_success']			= '成功: 品牌/厂牌数据设置已更新！';
$_['text_list']				= '品牌/厂牌清单';
$_['text_add']				= '添加品牌/厂牌';
$_['text_edit']				= '编辑品牌/厂牌';
$_['text_default']			= '默认';
$_['text_keyword']      	= '请勿使用空格，使用 - 取代空格，并确定静态网址(SEO URL)是没有重复过的。';

// Column
$_['column_name']			= '品牌/厂牌名称';
$_['column_sort_order']		= '显示排序';
$_['column_action']			= '管理';

// Entry
$_['entry_name']			= '品牌/厂牌名称';
$_['entry_store']			= '商店';
$_['entry_keyword']			= '静态网址';
$_['entry_image']			= '图标';
$_['entry_sort_order']		= '显示排序';
$_['entry_layout']			= '指定模板';

// Error
$_['error_warning']     	= '警告: 请确实检查表单字段填写的内容!';
$_['error_permission']		= '警告: 您没有权限更改品牌/厂牌数据！';
$_['error_name']			= '品牌/厂牌名称必须在 1 至 64 个字之间！';
$_['error_keyword']			= '静态网址(SEO URL)必须是 1 至 64 个字!';
$_['error_keyword_exists']	= '静态网址(SEO URL)必须是没有重复的!';
$_['error_keyword_character'] = '静态网址(SEO URL)只能使用 a-z, 0-9, - and _ 等字符!';
$_['error_product']			= '警告: 此品牌/厂牌不得被删除，因为已指定给 %s 项商品!';
