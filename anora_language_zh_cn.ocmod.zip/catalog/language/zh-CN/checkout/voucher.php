<?php
// Heading
$_['heading_title']    = '购买购物礼券';

// Text
$_['text_account']     = '帐号';
$_['text_voucher']     = '购物礼券';
$_['text_description'] = '此礼券将在您的订单付款后通过 Email 发送给收件人。';
$_['text_agree']       = '我以了解并同意礼券不可退款';
$_['text_message']     = '<p>感谢您购买礼券! 完成订单后，您的礼券收件人将收到一封 Email，其中包含如何使用礼券的详细说明。</p>';
$_['text_for']         = '%s 购物礼券 for %s';

// Entry
$_['entry_to_name']    = '收件者姓名';
$_['entry_to_email']   = '收件者 e-mail';
$_['entry_from_name']  = '您的姓名';
$_['entry_from_email'] = '您的 e-mail';
$_['entry_theme']      = '购物礼券主题';
$_['entry_message']    = '留言消息';
$_['entry_amount']     = '金额';

// Help
$_['help_message']     = '选择性';
$_['help_amount']      = '金额必须是 %s 到 %s 之间';

// Error
$_['error_token']      = '警告: 购物礼券密钥无效!';
$_['error_voucher']    = '找不到购物礼券!';
$_['error_to_name']    = '收件者姓名必须是 1 到 64 个字!';
$_['error_from_name']  = '您的姓名必须是 1 到 64 个字!';
$_['error_email']      = 'E-Mail 格式不正确!';
$_['error_theme']      = '必须选择一个购物礼券主题!';
$_['error_amount']     = '金额必须是 %s 到 %s 之间!';
$_['error_agree']      = '警告: 您必须同意礼券不可退款!';