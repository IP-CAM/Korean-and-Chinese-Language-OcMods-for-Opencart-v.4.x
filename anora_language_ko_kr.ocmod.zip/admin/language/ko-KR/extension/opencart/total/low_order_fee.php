<?php
// 제목
$_['heading_title'] = '소액 주문 수수료';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 소량주문 과금모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '소액 주문 과금 모듈 수정';

// 항목
$_['entry_total'] = '주문금액';
$_['entry_fee'] = '수수료';
$_['entry_tax_class'] = '세금 유형';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 돕다
$_['help_total'] = '결제 금액이 주문 금액보다 낮아야 적용됩니다. ';

// 오류
$_['error_permission'] = '경고: 소량 주문 과금 모듈을 수정할 수 있는 권한이 없습니다! ';