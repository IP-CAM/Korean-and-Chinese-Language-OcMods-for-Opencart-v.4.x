<?php
//텍스트
$_['text_upload'] = '파일이 성공적으로 업로드되었습니다! ';

// 오류
$_['error_filename'] = '파일 이름은 3~64자여야 합니다! ';
$_['error_file_type'] = '잘못된 파일 형식입니다! ';
$_['error_upload'] = '파일을 업로드해야 합니다! ';