<?php
// 제목
$_['heading_title'] = '해결사';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 고정 통화 환율 모듈을 수정했습니다!';
$_['text_edit'] = '수정 모듈 편집';
$_['text_signup'] = 'Fixer.io는 통화 변환 서비스입니다. <a href="https://fixer.io/" target="_blank" class="alert-link">여기서 가입하세요</a> .';
$_['text_support'] = '이 확장 프로그램은 EUR 통화에서 통화 옵션을 사용할 수 있어야 합니다.';

// 항목
$_['entry_api'] = 'API 액세스 키';
$_['entry_status'] = '상태';

// 오류
$_['error_permission'] = '경고: 환율 고정 모듈을 편집할 권한이 없습니다!';
$_['error_api'] = 'API 액세스 키를 입력해야 합니다!';