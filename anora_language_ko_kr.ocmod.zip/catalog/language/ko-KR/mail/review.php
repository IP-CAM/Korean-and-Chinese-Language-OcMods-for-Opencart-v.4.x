<?php
//텍스트
$_['text_subject'] = '%s - 제품 리뷰';
$_['text_waiting'] = '리뷰를 기다리는 새로운 제품 리뷰가 있습니다.';
$_['text_product'] = '제품: %s';
$_['text_reviewer'] = '검토자: %s';
$_['text_rated'] = '평점: %s';
$_['text_review'] = '내용 검토:';