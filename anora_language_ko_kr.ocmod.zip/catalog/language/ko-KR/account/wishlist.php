<?php
// Heading 
$_['heading_title'] = '제품 팔로우';

//텍스트
$_['text_account'] = '내 계정';
$_['text_instock'] = '재고 있음';
$_['text_wishlist'] = '제품 팔로우(%s)';
$_['text_login']      = '먼저<a href="%s">로그인</a>하거나  <a href="%s">새 계정 등록</a>는 <a href="%s">관심 있는 상품</a>에 <a href="%s">%s</a> 저장하기 위해서 ！';
$_['text_success'] = '성공: <a href="%s">%s</a>를 <a href="%s">다음 제품</a>에 추가했습니다! ';
$_['text_remove'] = '성공: 다음 제품 목록을 업데이트했습니다! ';
$_['text_no_results'] = '현재 관심을 두고 있는 제품이 없습니다.';

//열
$_['column_image'] = '사진';
$_['column_name'] = '제품명';
$_['column_model'] = '모델';
$_['column_stock'] = '재고';
$_['column_price'] = '판매가';
$_['column_action'] = '액션';

// 오류
$_['error_product'] = '경고: 제품을 찾을 수 없습니다!';