<?php
// Heading
$_['heading_title']    = '商品特性'; 

// Text
$_['text_extension']   = '扩展模块';
$_['text_success']     = '成功: 商品特性模块设置已更新！';
$_['text_edit']        = '编辑商品特性模块';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 您没有修改商品特性模块的权限！';