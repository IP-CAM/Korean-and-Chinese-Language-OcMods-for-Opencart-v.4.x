<?php
// Heading
$_['heading_title'] = '정기 지급';

//텍스트
$_['text_success'] = '성공: 반복결제 설정이 업데이트되었습니다! ';
$_['text_list'] = '정기 지급 목록';
$_['text_add'] = '반복결제 추가';
$_['text_edit'] = '반복결제(#%s)';
$_['text_filter'] = '필터';
$_['text_date_added'] = '날짜 추가';
$_['text_order'] = '주문번호';
$_['text_customer'] = '회원';
$_['text_subscription_plan'] = '구독 계획';
$_['text_product'] = '제품';
$_['text_quantity'] = '수량';
$_['text_trial'] = '시험';
$_['text_subscription'] = '정기 결제 내역';
$_['text_subscription_trial'] = '%s 매 %d %s(s)마다 %d 결제 후 ';
$_['text_subscription_duration'] = '%d 결제마다 %d %s(s)마다 %s';
$_['text_subscription_cancel'] = '취소될 때까지 %s마다 %d %s(s)';
$_['text_cancel'] = '취소까지';
$_['text_day'] = '요일';
$_['text_week'] = '주';
$_['text_semi_month'] = '반달';
$_['text_month'] = '월';
$_['text_year'] = '연도';
$_['text_date_next'] = '다음 결제일';
$_['text_remaining'] = '남은 비용';
$_['text_payment_address'] = '회원 주소';
$_['text_payment_method'] = '결제방법';
$_['text_shipping_address'] = '배송주소';
$_['text_shipping_method'] = '배송방법';
$_['text_history'] = '기록';
$_['text_history_add'] = '기록 추가';
// Column
$_['column_subscription_id'] = '반복결제ID';
$_['column_order_id'] = '주문ID';
$_['column_customer'] = '회원';
$_['column_comment'] = '비고';
$_['column_description'] = '설명';
$_['column_amount'] = '총액';
$_['column_notify'] = '회원에게 알림';
$_['column_status'] = '상태';
$_['column_date_added'] = '날짜 추가';
$_['column_product'] = '제품 세부정보';
$_['column_quantity'] = '수량';
$_['column_total'] = '전체';
$_['column_action'] = '관리';

// Entry
$_['entry_customer'] = '고객';
$_['entry_subscription_id'] = '구독ID';
$_['entry_order_id'] = '등록번호';
$_['entry_subscription_plan'] = '구독 계획';
$_['entry_trial_price'] = '시험 가격';
$_['entry_trial_duration'] = '시험기간';
$_['entry_trial_remaining'] = '남은 평가판';
$_['entry_trial_frequency'] = '시험 주기';
$_['entry_trial_주파수'] = '시험 빈도';
$_['entry_trial_status'] = '시험 상태';
$_['entry_price'] = '가격';
$_['entry_duration'] = '기간';
$_['entry_remaining'] = '남음';
$_['entry_cycle'] = '주기';
$_['entry_frequency'] = '빈도';
$_['entry_date_next'] = '다음 날짜';
$_['entry_comment'] = '입력';
$_['entry_amount'] = "금액";
$_['entry_notify'] = '통지정보';
$_['entry_override'] = '대대';
$_['entry_date_from'] = '일요일(起)';
$_['entry_date_to'] = '일요일(止)';
$_['entry_subscription_status'] = '가입 상태';

// Help
$_['help_trial_duration'] = '기간은 사용자가 결제하는 횟수입니다.';
$_['help_trial_cycle'] = '구독 금액은 빈도와 주기에 따라 계산됩니다.';
$_['help_trial_frequency'] = '빈도를 "주"로, 주기를 "2"로 사용하면 사용자에게 2주마다 비용이 청구됩니다.';
$_['help_duration'] = '기간은 사용자가 결제를 하는 횟수입니다. 취소될 때까지 결제를 원할 경우 이 값을 0으로 설정하세요.';
$_['help_cycle'] = '구독 금액은 빈도와 주기에 따라 계산됩니다.';
$_['help_frequency'] = '빈도를 "주"로, 주기를 "2"로 사용하면 사용자에게 2주마다 비용이 청구됩니다.';

// Tab
$_['tab_order']                  = '주문';

// Error
$_['error_permission'] = '경고: 구독을 수정할 권한이 없습니다!';
$_['error_status'] = '오류: 구독 상태가 스토어 상태와 일치하지 않습니다!';
$_['error_subscription'] = '읽기: 표시되지 않음!';
$_['error_subscription_plan'] = '가입: 취소할 수 없습니다!';
$_['error_subscription_status'] = '경고: 구독 상태를 선택해야 합니다!';
$_['error_payment_method'] = '결제: 결제 방법이 없습니다!';
$_['error_service_type'] = '서비스 상태가 이 거래에 포함되지 않았습니다. 이 오류 메시지가 표시되면 구독 서비스를 담당하는 확장 개발자에게 문의하여 이 문제를 해결하세요!';