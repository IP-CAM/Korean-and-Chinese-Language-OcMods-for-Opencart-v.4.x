<?php
// Text
$_['text_cart']       = '成功: 购物车内容已更新！';
$_['text_for']        = '%s 购物礼券送给 %s';
$_['text_success']    = '成功: 购物礼券已套用!';
$_['text_remove']     = '成功: 购物礼券已移除';

// Error
$_['error_voucher']    = '警告: 礼券无效或余额已用完!';
$_['error_to_name']    = '收件人的姓名必须是 1 到 64 个字！';
$_['error_from_name']  = '您的姓名必须是 1 到 64 个字！';
$_['error_email']      = '电子邮件地址无效！';
$_['error_theme']      = '你必须选择一个主题！';
$_['error_amount']     = '金额必须在 %s 和 %s 之间！';