<?php
// Heading
$_['heading_title'] = '택배';

// Text
$_['text_description'] = '택배';