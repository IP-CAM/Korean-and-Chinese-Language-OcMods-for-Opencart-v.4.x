<?php
// 제목
$_['heading_title'] = '회원주소';

//텍스트
$_['text_address_new'] = '주소 추가';
$_['text_address_existing'] = '공통 주소 사용';
$_['text_success'] = '성공: 회원 주소가 업데이트되었습니다!';

// 항목
$_['entry_address'] = '주소 선택';
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_company'] = '회사명';
$_['entry_address_1'] = '주소';
$_['entry_address_2'] = '주소 2';
$_['entry_postcode'] = '우편번호';
$_['entry_city'] = '타운십 도시';
$_['entry_country'] = '국가';
$_['entry_zone'] = '군/지역';

// 오류
$_['error_customer'] = '고객 데이터가 있어야 합니다!';
$_['error_address'] = '경고: 회원 주소를 찾을 수 없습니다!';
$_['error_firstname'] = '이름은 1~32자여야 합니다!';
$_['error_lastname'] = '성은 1~32자여야 합니다!';
$_['error_address_1'] = '주소 길이는 3~128 단어여야 합니다!';
$_['error_city'] = '도시와 도시는 2~128자여야 합니다!';
$_['error_postcode'] = '우편번호는 2~10자여야 합니다!';
$_['error_country'] = '국가를 선택하세요!';
$_['error_zone'] = '국가/지역을 선택하세요!';
$_['error_custom_field'] = '%s 필드를 입력해야 합니다!';
$_['error_regex'] = '%s은(는) 유효한 값이 아닙니다!';