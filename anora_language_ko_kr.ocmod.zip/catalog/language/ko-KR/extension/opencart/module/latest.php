<?php
// Heading
$_['heading_title'] = '최신 제품';