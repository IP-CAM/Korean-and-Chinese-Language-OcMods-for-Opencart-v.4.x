<?php
// 제목
$_['heading_title'] = '결제수단';

//텍스트
$_['text_account'] = '내 계정';
$_['text_pay_method'] = '결제수단';
$_['text_success'] = '결제수단이 삭제되었습니다';
$_['text_no_results'] = '현재 결제 수단이 없습니다';

//열
$_['column_pay_method'] = '결제수단';
$_['column_type'] = '유형';
$_['column_date_expire'] = '만료일';
$_['column_action'] = '관리';

// 오류
$_['error_paid_method'] = '경고: 결제 수단을 찾을 수 없습니다!';