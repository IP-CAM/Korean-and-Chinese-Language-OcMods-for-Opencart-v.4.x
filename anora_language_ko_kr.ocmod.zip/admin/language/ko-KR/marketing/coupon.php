<?php
// 제목
$_['heading_title'] = '할인 활동';

//텍스트
$_['text_success'] = '성공: 할인 활동 설정이 업데이트되었습니다! ';
$_['text_list'] = '할인 활동 목록';
$_['text_add'] = '할인 활동 추가';
$_['text_edit'] = '할인 활동 편집';
$_['text_percent'] = '퍼센트';
$_['text_amount'] = '고정 금액';
$_['text_coupon'] = '할인활동기록';

//열
$_['column_name'] = '할인 활동 이름';
$_['column_code'] = '할인코드';
$_['column_discount'] = '할인금액';
$_['column_date_start'] = '시작일';
$_['column_date_end'] = '종료일';
$_['column_status'] = '상태';
$_['column_order_id'] = '주문번호';
$_['column_customer'] = '회원';
$_['column_amount'] = '주문 금액 기준';
$_['column_date_add'] = '날짜 추가';
$_['column_action'] = '액션';

// 항목
$_['entry_name'] = '할인 활동명';
$_['entry_code'] = '할인코드';
$_['entry_type'] = '할인 유형';
$_['entry_discount'] = '할인금액';
$_['entry_logged'] = '회원 로그인';
$_['entry_shipping'] = '무료 배송';
$_['entry_total'] = '주문 금액 기준';
$_['entry_category'] = '해당 제품 카테고리';
$_['entry_product'] = '적용제품';
$_['entry_date_start'] = '시작일';
$_['entry_date_end'] = '종료일';
$_['entry_uses_total'] = '할인코드를 사용할 수 있는 총 횟수';
$_['entry_uses_customer'] = '회원별 이용횟수';
$_['entry_status'] = '상태';

// 돕다
$_['help_code'] = '회원은 할인코드를 입력하여 할인을 받으실 수 있습니다. ';
$_['help_type'] = '퍼센트 또는 고정 금액. ';
$_['help_logged'] = '할인코드를 사용하시려면 먼저 로그인을 하셔야 합니다. ';
$_['help_total'] = '주문 금액이 이 금액에 도달할 때까지 할인 코드를 사용할 수 없습니다. ';
$_['help_category'] = '선택한 카테고리의 모든 제품을 선택하세요. ';
$_['help_product'] = '할인코드가 적용되는 상품을 선택하세요. 해당 상품을 선택하지 않으시면 모든 상품에 적용됩니다. ';
$_['help_uses_total'] = '할인코드를 사용할 수 있는 최대 총 횟수이며, 설정하지 않으면 제한이 없습니다. ';
$_['help_uses_customer'] = '회원 1인이 할인코드를 사용할 수 있는 최대 횟수이며, 설정하지 않을 경우 제한이 없습니다. ';

// 오류
$_['error_permission'] = '경고: 할인 활동을 수정할 권한이 없습니다!';
$_['error_exists'] = '경고: 할인 코드가 사용되었습니다!';
$_['error_name'] = '할인 이벤트 이름은 3~128자여야 합니다!';
$_['error_code'] = '할인 코드는 3~128자여야 합니다!';