<?php
// 제목
$_['heading_title'] = '인증코드';

//텍스트
$_['text_success'] = '성공: 인증코드 모듈 설정이 업데이트되었습니다!';
$_['text_list'] = '인증코드 모듈 목록';

//열
$_['column_name'] = '인증코드 모듈 이름';
$_['column_status'] = '상태';
$_['column_action'] = '액션';

// 오류
$_['error_permission'] = '경고: 인증 코드 모듈을 편집할 수 있는 권한이 없습니다!';
$_['error_extension'] = '경고: 확장 모듈이 존재하지 않습니다!';