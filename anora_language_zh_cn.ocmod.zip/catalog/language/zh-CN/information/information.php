<?php
// Text
$_['text_error'] = '找不到信息页面！';