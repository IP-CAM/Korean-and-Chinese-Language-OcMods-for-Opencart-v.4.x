<?php
// 제목
$_['heading_title'] = '제품 사양';

//텍스트
$_['text_success'] = '성공: 사양 설정이 업데이트되었습니다! ';
$_['text_list'] = '사양 목록';
$_['text_add'] = '사양 추가';
$_['text_edit'] = '사양 편집';

//열
$_['column_name'] = '명세 이름';
$_['column_attribute_group'] = '명세 그룹';
$_['column_sort_order'] = '정렬';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '사양 이름';
$_['entry_attribute_group'] = '명세 그룹';
$_['entry_sort_order'] = '정렬 표시';

// 오류
$_['error_warning'] = '경고: 필드 입력에 오류가 있는지 확인하십시오!';
$_['error_permission'] = '경고: 사양을 수정할 권한이 없습니다! ';
$_['error_attribute_group'] = '특정 그룹을 입력해야 합니다!';
$_['error_name'] = '명세 이름은 1~64자여야 합니다! ';
$_['error_product'] = '경고: %s 항목이 이미 사용 중이므로 이 사양을 삭제할 수 없습니다! ';