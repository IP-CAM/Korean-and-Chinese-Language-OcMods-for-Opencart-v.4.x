<?php
// Heading
$_['heading_title']    = '语言编辑';

// Text
$_['text_success']     = '成功: 语言编辑设置已更新!';
$_['text_list']        = '翻译清单';
$_['text_add']         = '添加翻译';
$_['text_edit']        = '编辑翻译';
$_['text_default']     = '默认';
$_['text_store']       = '商店';
$_['text_language']    = '语系';

// Column
$_['column_store']     = '商店';
$_['column_language']  = '语系';
$_['column_route']     = '路径';
$_['column_key']       = 'Key';
$_['column_value']     = '翻译文本';
$_['column_action']    = '操作';

// Entry
$_['entry_store']      = '商店';
$_['entry_language']   = '语系';
$_['entry_route']      = '路径';
$_['entry_key']        = 'Key';
$_['entry_default']    = '默认';
$_['entry_value']      = '翻译文本';

// Error
$_['error_permission'] = '警告: 您没有权限修改语言编辑!';
$_['error_key']        = 'Key 必须是 3 到 64 个字!';
