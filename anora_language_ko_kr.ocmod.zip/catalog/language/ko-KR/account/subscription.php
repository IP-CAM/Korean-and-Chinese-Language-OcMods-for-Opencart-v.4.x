<?php
// 제목
$_['heading_title'] = '구독 서비스';

//텍스트
$_['text_account'] = '내 계정';
$_['text_subscription'] = '구독 서비스 #%s';
$_['text_invoice_no'] = '송장번호:';
$_['text_subscription_id'] = '구독번호:';
$_['text_order_id'] = '주문번호:';
$_['text_shipping_address'] = '배송주소';
$_['text_shipping_method'] = '배송 방법:';
$_['text_paid_address'] = '회원 주소';
$_['text_paid_method'] = '결제 방법:';
$_['text_subscription_trial'] = '%s 매 %d %s(s)마다 %d 결제 후 ';
$_['text_subscription_duration'] = '%s 매 %d %s(s)마다 %d 결제';
$_['text_subscription_cancel'] = '취소될 때까지 %s마다 %d %s(s)';
$_['text_day'] = '요일';
$_['text_week'] = '주';
$_['text_semi_month'] = '반달';
$_['text_month'] = '월';
$_['text_year'] = '연도';
$_['text_date_add'] = '추가된 날짜:';
$_['text_status'] = '상태:';
$_['text_description'] = '설명';
$_['text_quantity'] = '수량';
$_['text_order'] = '주문 기록';
$_['text_no_results'] = '구독이 없습니다!';
$_['text_error'] = '구독 항목을 찾을 수 없습니다!';
$_['text_cancelled'] = '반복결제 취소됨';

//열
$_['column_subscription_id'] = '구독번호';
$_['column_product'] = '제품';
$_['column_order_id'] = '주문번호';
$_['column_status'] = '상태';
$_['column_total'] = '주문금액';
$_['column_comment'] = '비고';
$_['column_date_add'] = '추가';

// 오류
$_['error_not_cancelled'] = '오류: %s';
$_['error_not_found'] = '반복 결제를 취소할 수 없습니다';