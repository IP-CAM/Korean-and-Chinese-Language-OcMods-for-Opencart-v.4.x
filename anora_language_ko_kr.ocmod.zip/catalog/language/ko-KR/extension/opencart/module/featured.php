<?php
// 제목
$_['heading_title'] = '추천 제품';