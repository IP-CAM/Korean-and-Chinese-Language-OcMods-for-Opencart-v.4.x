<?php
// Text
$_['text_subject']      = '%s - 订单更新 %s';
$_['text_order_id']     = '订单编号:';
$_['text_date_added']   = '订单日期:';
$_['text_order_status'] = '您的订单已经更新为以下的状态:';
$_['text_comment']      = '订单备注:';
$_['text_link']         = '需要查看订单，请点击下面链接:';
$_['text_footer']       = '如果您有任何问题请回复本邮件';