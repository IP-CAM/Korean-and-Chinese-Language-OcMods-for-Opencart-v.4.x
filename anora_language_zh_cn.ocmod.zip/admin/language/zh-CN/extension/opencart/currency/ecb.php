<?php
// Heading
$_['heading_title']    = 'European Central Bank Currency Converter';

// Text
$_['text_extension']   = '扩展模块';
$_['text_success']     = '成功: European Central Bank Currency Converter 模块已更新!';
$_['text_edit']        = '编辑 European Central Bank 模块';
$_['text_support']     = 'This extension requires at EUR currency to be available currency option.';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 您没有权限编辑 European Central Bank Currency Converter 模块!';