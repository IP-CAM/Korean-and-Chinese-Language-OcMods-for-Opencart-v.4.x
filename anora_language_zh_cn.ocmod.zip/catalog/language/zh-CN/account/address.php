<?php
// Heading 
$_['heading_title']      = '常用地址';

// Text
$_['text_account']       = '我的帐号';
$_['text_address_book']  = '常用地址';
$_['text_address_add']   = '添加地址';
$_['text_address_edit']  = '编辑地址';
$_['text_add']           = '地址已添加 !';
$_['text_edit']          = '地址已更新 !';
$_['text_delete']        = '地址已删除 !';
$_['text_no_results']    = '您尚未创建常用地址 !';

// Entry
$_['entry_firstname']    = '名字';
$_['entry_lastname']     = '姓氏';
$_['entry_company']      = '公司名称';
$_['entry_address_1']    = '地址';
$_['entry_address_2']    = '地址2';
$_['entry_postcode']     = '邮递区号';
$_['entry_city']         = '乡镇市区';
$_['entry_country']      = '国家';
$_['entry_zone']         = '县市/地区';
$_['entry_default']      = '默认地址';

// Error
$_['error_token']        = '警告：密钥已失效!';
$_['error_subscription'] = '警告：此地址仍被一个 %s 定期付款绑定!';
$_['error_default']      = '警告：必须设置默认地址！';
$_['error_delete']       = '警告：您必须至少有一组地址！';
$_['error_firstname']    = '名字必须是 1 到 32 个字！';
$_['error_lastname']     = '姓氏必须是 1 到 32 个字！';
$_['error_address_1']    = '地址必须是 3 到 128 个字！';
$_['error_postcode']     = '邮递区号必须是 2 到 10 个字！';
$_['error_city']         = '乡镇市区必须是 2 到 128 个字！';
$_['error_country']      = '请选择一个国家！';
$_['error_zone']         = '请选择一个县市/地区！';
$_['error_custom_field'] = '%s 必须填写！';
$_['error_regex']        = '%s 不是有效的值!';