<?php
// 제목
$_['heading_title'] = '사용자 정의 필드';

//텍스트
$_['text_success'] = '성공: 사용자 정의 필드 설정이 업데이트되었습니다! ';
$_['text_list'] = '사용자 정의 필드 목록';
$_['text_add'] = '사용자 정의 필드 추가';
$_['text_edit'] = '사용자 정의 필드 편집';
$_['text_choose'] = '선택';
$_['text_select'] = '목록';
$_['text_radio'] = '라디오 선택';
$_['text_checkbox'] = '체크박스';
$_['text_input'] = '텍스트 상자';
$_['text_text'] = '텍스트';
$_['text_textarea'] = '여러줄 텍스트 상자';
$_['text_file'] = '문서';
$_['text_date'] = '날짜';
$_['text_datetime'] = '날짜 및 시간';
$_['text_time'] = '시간';
$_['text_account'] = '계정';
$_['text_address'] = '주소';
$_['text_affiliate'] = '추천';
$_['text_regex'] = '정규식(Regex)';
$_['text_custom_field'] = '사용자 정의 필드';
$_['text_value'] = '사용자 정의 필드 값';

//열
$_['column_name'] = '필드 이름';
$_['column_location'] = '위치';
$_['column_type'] = '유형';
$_['column_status'] = '상태';
$_['column_sort_order'] = '정렬 표시';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '사용자 정의 필드 이름';
$_['entry_location'] = '위치';
$_['entry_type'] = '유형';
$_['entry_value'] = '값';
$_['entry_validation'] = '검증';
$_['entry_custom_value'] = '사용자 정의 필드 값 이름';
$_['entry_customer_group'] = '회원등급';
$_['entry_required'] = '필수';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬 표시';

// 돕다
$_['help_regex'] = '정규식을 사용하세요. 예: /[a-zA-Z0-9_-]/';
$_['help_sort_order'] = '컬렉션의 마지막 필드부터 거꾸로 계산하려면 "-"를 사용하십시오. ';

// 오류
$_['error_permission'] = '경고: 사용자 정의 필드를 수정할 권한이 없습니다! ';
$_['error_name'] = '사용자 정의 필드 이름은 1~128자여야 합니다! ';
$_['error_type'] = '경고: 사용자 정의 필드 값을 입력해야 합니다! ';
$_['error_custom_value'] = '사용자 정의 필드 값 이름은 1~128자여야 합니다! ';