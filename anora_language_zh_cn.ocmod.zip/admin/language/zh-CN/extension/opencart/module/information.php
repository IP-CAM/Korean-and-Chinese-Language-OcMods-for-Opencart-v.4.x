<?php
// Heading
$_['heading_title']    = '商店信息页面';

// Text
$_['text_extension']   = '扩展模块';
$_['text_success']     = '成功: 商店信息页面设置已更新！';
$_['text_edit']        = '编辑商店信息页面';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 您没有权限修改商店信息页面模块！';