<?php
// 제목
$_['heading_title'] = '시스템 업그레이드';

//텍스트
$_['text_success'] = '성공: 시스템이 %s(으)로 업그레이드되었습니다!';
$_['text_upgrade'] = '최신 버전을 확인하세요';
$_['text_information'] = '버전 정보';
$_['text_current_version'] = '현재 사용되는 버전';
$_['text_latest_version'] = '사용 가능한 최신 버전';
$_['text_date_added'] = '게시일';
$_['text_change'] = '기록 업데이트';
$_['text_status'] = '업데이트 상태';
$_['text_ready'] = '최신 버전으로 업그레이드하려면 [업그레이드] 버튼을 클릭하세요...';
$_['text_download'] = '문서 다운로드 중...';
$_['text_install'] = '문서 복사 중...';
$_['text_patch'] = '업데이트 중...';

// 버튼
$_['button_upgrade'] = '업그레이드';

// 오류
$_['error_permission'] = '경고: 운영 체제를 업그레이드할 권한이 없습니다!';
$_['error_connection'] = '업데이트 서버에 연결할 수 없습니다!';
$_['error_version'] = '현재 사용하고 있는 버전보다 낮은 버전입니다!';
$_['error_download'] = '시스템 업데이트 문서를 다운로드할 수 없습니다!';
$_['error_file'] = '업데이트 문서를 찾을 수 없습니다!';
$_['error_directory'] = '%s 디렉토리를 생성할 수 없습니다!';
$_['error_copy'] = '문서 %s을(를) %s에 복사할 수 없습니다!';
$_['error_unzip'] = 'Zip 아카이브의 압축을 풀 수 없습니다!';