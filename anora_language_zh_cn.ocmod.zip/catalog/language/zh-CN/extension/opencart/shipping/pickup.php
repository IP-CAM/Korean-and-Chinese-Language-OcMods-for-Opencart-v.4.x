<?php
// Heading
$_['heading_title']    = '门市取货';

// Text
$_['text_description'] = '到门市取货';