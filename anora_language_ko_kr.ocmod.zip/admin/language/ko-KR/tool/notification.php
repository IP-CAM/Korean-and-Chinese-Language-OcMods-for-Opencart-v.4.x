<?php
// 제목
$_['heading_title'] = '알림';

// 텍스트
$_['text_success'] = '성공: 알림을 수정했습니다!';
$_['text_list'] = '알림 목록';

// 열
$_['column_message'] = '메시지';
$_['column_action'] = '액션';

// 오류
$_['error_permission'] = '경고: 알림을 수정할 권한이 없습니다!';