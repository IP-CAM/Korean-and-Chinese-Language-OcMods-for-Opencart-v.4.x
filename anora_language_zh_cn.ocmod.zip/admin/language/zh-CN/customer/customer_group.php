<?php
// Heading
$_['heading_title']     = '会员等级';

// Text
$_['text_success']      = '成功: 会员等级设置已更新!';
$_['text_list']         = '会员等级清单';
$_['text_add']          = '添加会员等级';
$_['text_edit']         = '编辑会员等级';

// Column
$_['column_name']       = '会员等级名称';
$_['column_sort_order'] = '显示排序';
$_['column_action']     = '管理';

// Entry
$_['entry_name']        = '会员等级名称';
$_['entry_description'] = '会员等级描述';
$_['entry_approval']    = '新会员审核';
$_['entry_sort_order']  = '显示排序';

// Help
$_['help_approval']     = '会员必须先经管理者审核后才能进行登录。';

// Error
$_['error_permission']  = '警告: 您没有权限修改会员等级!';
$_['error_name']        = '会员等级名称必须是 3 到 32 个字!';
$_['error_default']     = '警告: 此会员等级不得删除，因为它是商店默认的会员等级!';
$_['error_store']       = '警告: 此会员等级不得删除，因为它目前已有 %s 个商店使用中!';
$_['error_customer']    = '警告: 此会员等级不得删除，因为它目前已有 %s 个会员使用中!';