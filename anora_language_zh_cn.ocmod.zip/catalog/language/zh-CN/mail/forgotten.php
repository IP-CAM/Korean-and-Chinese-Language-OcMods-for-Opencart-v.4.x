<?php
// Text
$_['text_subject']  = '%s - 会员要求新密码';
$_['text_greeting'] = '我们从 %s 收到您请求新的密码，建议您在使用新密码登录后立即变更此密码，并妥善保管...';
$_['text_change']   = '请点击下方链接以重设您的新密码:';
$_['text_ip']       = '请求使用此功能的 IP 是:';

// Button
$_['button_reset']  = '重设新密码';
