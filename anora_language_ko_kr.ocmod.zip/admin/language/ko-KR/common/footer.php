<?php
// 텍스트
$_['text_footer'] = '<a href="https://www.opencart.com">OpenCart</a> &copy; ' . "날짜('Y')" . ' 판권 소유.';
$_['text_version'] = '전체 %s';