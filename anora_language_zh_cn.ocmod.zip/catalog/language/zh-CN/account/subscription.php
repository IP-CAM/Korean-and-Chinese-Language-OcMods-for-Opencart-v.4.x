<?php
// Heading
$_['heading_title']               = '订阅服务';

// Text
$_['text_account']                = '我的帐号';
$_['text_subscription']           = '订阅服务 #%s';
$_['text_invoice_no']             = 'Invoice No.:';
$_['text_subscription_id']        = '订阅编号:';
$_['text_order_id']               = '订单编号:';
$_['text_shipping_address']       = '运送地址';
$_['text_shipping_method']        = '运送方式:';
$_['text_payment_address']        = '会员地址';
$_['text_payment_method']         = '付款方式:';
$_['text_subscription_trial']     = '%s every %d %s(s) for %d payment(s) then ';
$_['text_subscription_duration']  = '%s every %d %s(s) for %d payment(s)';
$_['text_subscription_cancel']    = '%s every %d %s(s) until canceled';
$_['text_day']                    = '日';
$_['text_week']                   = '周';
$_['text_semi_month']             = '半月';
$_['text_month']                  = '月';
$_['text_year']                   = '年';
$_['text_date_added']             = '添加日期:';
$_['text_status']                 = '状态:';
$_['text_description']            = '说明';
$_['text_quantity']               = '数量';
$_['text_order']                  = '订单纪录';
$_['text_no_results']             = '没有任何订阅!';
$_['text_error']                  = '找不订订阅项目!';
$_['text_cancelled']              = '定期付款已取消';

// Column
$_['column_subscription_id']      = '定阅编号';
$_['column_product']              = '商品';
$_['column_order_id']             = '订单编号';
$_['column_status']               = '状态';
$_['column_total']                = '订单金额';
$_['column_comment']              = '备注';
$_['column_date_added']           = '添加';

// Error
$_['error_not_cancelled']         = '错误: %s';
$_['error_not_found']             = '无法取消定期付款';
