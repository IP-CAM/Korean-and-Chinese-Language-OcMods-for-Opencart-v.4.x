<?php
// 제목
$_['heading_title'] = '개별 청구';

//텍스트
$_['text_description'] = '개수로 화물 계산';