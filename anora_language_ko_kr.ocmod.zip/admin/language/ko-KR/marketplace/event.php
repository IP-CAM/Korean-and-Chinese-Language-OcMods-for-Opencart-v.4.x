<?php
// 제목
$_['heading_title'] = '이벤트 기능 관리';

//텍스트
$_['text_success'] = '성공: 이벤트 기능 모듈 설정이 업데이트되었습니다!';
$_['text_list'] = '이벤트 함수 목록';
$_['text_event'] = '확장 메커니즘은 이벤트 기능 모듈을 사용하여 상점의 기본 기능을 재정의하는 것입니다. 문제가 발생하면 여기에서 이벤트 모듈을 비활성화하거나 활성화할 수 있습니다. ';
$_['text_info'] = '이벤트 기능 정보';

//열
$_['column_code'] = '이벤트 함수 코드';
$_['column_sort_order'] = '정렬';
$_['column_action'] = '액션';

// 항목
$_['entry_description'] = '설명';
$_['entry_trigger'] = '트리거 타이밍';
$_['entry_action'] = '액션';

// 오류
$_['error_permission'] = '경고: 이벤트 기능 모듈을 편집할 수 있는 권한이 없습니다!';