<?php
// Heading
$_['heading_title']         = '个人文档';

// Text
$_['text_success']          = '成功: 个人文档已更新!';
$_['text_edit']             = '编辑个人文档';
$_['text_user']             = '个人文档内容';
$_['text_password']         = '密码';

// Entry
$_['entry_username']        = '管理员帐号';
$_['entry_password']        = '管理员密码';
$_['entry_confirm']         = '确认';
$_['entry_firstname']       = '名字';
$_['entry_lastname']        = '姓氏';
$_['entry_email']           = 'E-Mail';
$_['entry_image']           = '图像';

// Error
$_['error_permission']      = '警告: 您没有权限编辑个人文档!';
$_['error_username_exists'] = '警告: 管理员帐号已被使用!';
$_['error_username']        = '管理员帐号必须是 3 到 20 个字!';
$_['error_password']        = '管理员密码必须是 4 到 20 个字!';
$_['error_confirm']         = '管理员密码与确认密码不相符!';
$_['error_firstname']       = '名字必须是 1 到 32 个字!';
$_['error_lastname']        = '姓氏必须是 1 到 32 个字!';
$_['error_email']           = '请输入有效的 E-Mail 帐号!';
$_['error_email_exists']    = '警告: E-Mail 帐号已被使用!';