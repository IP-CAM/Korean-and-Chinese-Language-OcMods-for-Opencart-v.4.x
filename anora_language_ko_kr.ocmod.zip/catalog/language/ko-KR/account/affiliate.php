<?php
// Heading
$_['heading_title'] = '추천 계정 정보';

//텍스트
$_['text_account'] = '내 계정';
$_['text_affiliate'] = '추천 계정';
$_['text_my_affiliate'] = '내가 추천하는 계정';
$_['text_pay'] = '결제정보';
$_['text_cheque'] = '수표';
$_['text_paypal'] = '페이팔';
$_['text_bank'] = '은행송금';
$_['text_success'] = '성공: 추천 계정 정보가 업데이트되었습니다';
$_['text_agree'] = '<a href="%s" class="agree"><b>%s</b></a>를 읽었으며 이에 동의합니다.';

// 항목
$_['entry_company'] = '회사명';
$_['entry_website'] = '웹사이트 URL';
$_['entry_tax'] = '세금ID';
$_['entry_pay_method'] = '결제수단';
$_['entry_cheque'] = '수표 수취인 이름';
$_['entry_paypal'] = '페이팔 이메일 계정';
$_['entry_bank_name'] = '은행명';
$_['entry_bank_branch_number'] = 'ABA/BSB 번호(지점번호)';
$_['entry_bank_swift_code'] = 'SWIFT 코드';
$_['entry_bank_account_name'] = '은행계좌명';
$_['entry_bank_account_number'] = '은행계좌번호';

// 오류
$_['error_token'] = '경고: 키가 만료되었습니다!';
$_['error_agree'] = '경고: %s에 동의해야 합니다!';
$_['error_pay_method'] = '결제수단을 설정해야 합니다!';
$_['error_cheque'] = '수표 수취인의 이름을 입력해야 합니다!';
$_['error_paypal'] = 'PayPal 이메일 계정은 유효하지 않을 수 있습니다!';
$_['error_bank_account_name'] = '은행 계좌명을 입력해야 합니다!';
$_['error_bank_account_number'] = '은행 계좌번호를 입력해야 합니다!';
$_['error_custom_field'] = '%s을(를) 입력해야 합니다!';
$_['error_regex'] = '%s은(는) 유효한 값이 아닙니다!';