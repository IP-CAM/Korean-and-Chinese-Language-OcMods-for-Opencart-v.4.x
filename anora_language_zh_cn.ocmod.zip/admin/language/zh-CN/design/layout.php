<?php
// Heading
$_['heading_title']       = '模板管理';

// Text
$_['text_success']        = '成功: 模板设置已更新！';
$_['text_list']           = '模板清单';
$_['text_add']            = '添加模板排版';
$_['text_edit']           = '编辑模板排版';
$_['text_remove']         = '移除';
$_['text_route']          = '选择使用模板的商店及路径';
$_['text_module']         = '选择模块放置的位置';
$_['text_default']        = '默认';
$_['text_content_top']    = '内容上方区域';
$_['text_content_bottom'] = '内容下方区域';
$_['text_column_left']    = '左侧区域';
$_['text_column_right']   = '右侧区域';

// Column
$_['column_name']         = '模板名称';
$_['column_action']       = '管理';

// Entry
$_['entry_name']          = '模板名称';
$_['entry_store']         = '商店';
$_['entry_route']         = '路径';
$_['entry_module']        = '模块';

// Error
$_['error_permission']    = '警告: 您没有权限修改模板！';
$_['error_name']          = '模板名称必须是 3 到 64 个字！';
$_['error_module']        = '必须要有模块!';
$_['error_default']       = '警告: 该模板为商店默认的模板，因此无法删除！';
$_['error_store']         = '警告: 该模板不能删除，因为它已设置给 %s 个商店使用中！';
$_['error_product']       = '警告: 该模板不能删除，因为它已设置给 %s 项商品使用中！';
$_['error_category']      = '警告: 该模板不能删除，因为它已设置给 %s 项类别使用中！';
$_['error_manufacturer']  = '警告: 该模板不能删除，因为它已设置给 %s 项品牌/厂牌使用中!';
$_['error_information']   = '警告: 该模板不能删除，因为它已设置给 %s 项商店页面使用中！';