<?php
// 제목
$_['heading_title'] = '회원 추천';

//텍스트
$_['text_success'] = '성공: 회원 추천 설정이 업데이트되었습니다!';
$_['text_list'] = '회원 추천 목록';
$_['text_add'] = '추천 회원 추가';
$_['text_edit'] = '에디터 추천 회원';
$_['text_affiliate'] = '추천 데이터';
$_['text_지불'] = '데이터 부여';
$_['text_other'] = '기타 설정';
$_['text_balance'] = '보너스 잔액';
$_['text_cheque'] = '수표';
$_['text_paypal'] = '페이팔';
$_['text_bank'] = '은행송금';
$_['text_history'] = '기록';
$_['text_history_add'] = '기록 추가';
$_['text_transaction'] = '쇼핑 크레딧';
$_['text_transaction_add'] = '쇼핑 크레딧 추가';
$_['text_report'] = '신고';
$_['text_filter'] = '필터';
$_['text_payment_cheque'] = '수표 결제';
$_['text_payment_paypal'] = '페이팔 결제';
$_['text_payment_bank'] = '계좌이체 결제';

//열
$_['column_name'] = '회원 이름';
$_['column_tracking'] = '추적';
$_['column_commission'] = '보너스';
$_['column_balance'] = '잔액';
$_['column_status'] = '상태';
$_['column_ip'] = 'IP';
$_['column_account'] = '계정';
$_['column_store'] = '저장';
$_['column_country'] = '국가';
$_['column_date_added'] = '날짜 추가';
$_['column_comment'] = '비고';
$_['column_description'] = '설명';
$_['column_amount'] = '금액';
$_['column_action'] = '관리';

// 항목
$_['entry_customer'] = '회원';
$_['entry_company'] = '회사명';
$_['entry_tracking'] = '추적코드';
$_['entry_website'] = '미디어 채널';
$_['entry_commission'] = '이익배분율(%)';
$_['entry_tax'] = '세금ID';
$_['entry_pay_method'] = '결제수단';
$_['entry_cheque'] = '지급 수표';
$_['entry_paypal'] = '페이팔 이메일 계정';
$_['entry_bank_name'] = '은행명';
$_['entry_bank_branch_number'] = 'ABA/BSB 번호(지점번호)';
$_['entry_bank_swift_code'] = 'SWIFT 코드';
$_['entry_bank_account_name'] = '은행계좌명';
$_['entry_bank_account_number'] = '은행계좌번호';
$_['entry_comment'] = '비고';
$_['entry_description'] = '설명';
$_['entry_amount'] = '금액';
$_['entry_date_from'] = '날짜 추가(시작)';
$_['entry_date_to'] = '날짜 추가(~)';
$_['entry_status'] = '상태';
$_['entry_limit'] = '참여 횟수 제한';

// 돕다
$_['help_tracking'] = '추천 링크를 식별하는 데 사용되는 추적 코드입니다. ';
$_['help_commission'] = '주문별로 나눌 수 있는 수익의 %';

// 오류
$_['error_warning'] = '경고: 잘못된 필드를 확인하십시오!';
$_['error_permission'] = '경고: 회원 추천을 편집할 수 있는 권한이 없습니다!';
$_['error_customer'] = '경고: 회원을 지정해야 합니다!';
$_['error_already'] = '경고: 이 회원은 추천회원으로 등록되었습니다!';
$_['error_tracking'] = '추적코드를 입력해야 합니다!';
$_['error_exists'] = '추적코드는 이미 다른 사람이 사용하고 있습니다!';
$_['error_payment_method'] = '결제수단을 설정해야 합니다!';
$_['error_cheque'] = '지급 수표를 작성해야 합니다!';
$_['error_paypal'] = 'PayPal 이메일 계정번호가 올바르지 않습니다!';
$_['error_bank_account_name'] = '은행계좌명을 반드시 입력해야 합니다!';
$_['error_bank_account_number'] = '은행 계좌번호를 반드시 입력해야 합니다!';
$_['error_custom_field'] = '%s을(를) 입력해야 합니다!';