<?php
// Heading
$_['heading_title']        = '邮件通知';

// Text
$_['text_mail']            = '发送邮件通知给会员';
$_['text_success']         = '邮件已成功发送！';
$_['text_sent']            = '邮件已成功发送给 %s / %s 位收件者！';
$_['text_default']         = '默认';
$_['text_newsletter']      = '电子报订阅者';
$_['text_customer_all']    = '所有会员';
$_['text_customer_group']  = '指定会员等级';
$_['text_customer']        = '指定会员';
$_['text_affiliate_all']   = '所有推荐会员';
$_['text_affiliate']       = '指定推荐会员';
$_['text_product']         = '指定商品购买者';

// Entry
$_['entry_store']          = '发送者';
$_['entry_to']             = '发送对象';
$_['entry_customer_group'] = '会员等级';
$_['entry_customer']       = '指定会员';
$_['entry_affiliate']      = '推荐会员';
$_['entry_product']        = '指定商品';
$_['entry_subject']        = '邮件主题';
$_['entry_message']        = '邮件内容';

// Help
$_['help_customer']        = '(自动完成)';
$_['help_affiliate']       = '(自动完成)';
$_['help_product']         = '只发送给已经购买过下列商品的会员。（自动完成）';

// Error
$_['error_permission']     = '警告: 您没有权限发送邮件通知！';
$_['error_subject']        = '邮件通知主题必须填写！';
$_['error_message']        = '邮件通知消息内容必须填写！';
$_['error_email']          = 'E-Mail 必须填写!';