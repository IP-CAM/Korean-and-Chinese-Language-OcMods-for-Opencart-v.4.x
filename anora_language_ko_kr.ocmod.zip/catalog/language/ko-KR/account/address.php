<?php
// Heading 
$_['heading_title'] = '공통 주소';

//텍스트
$_['text_account'] = '내 계정';
$_['text_address_book'] = '공통 주소';
$_['text_address_add'] = '주소 추가';
$_['text_address_edit'] = '주소 수정';
$_['text_add'] = '주소가 추가되었습니다!';
$_['text_edit'] = '주소가 업데이트되었습니다!';
$_['text_delete'] = '주소가 삭제되었습니다!';
$_['text_no_results'] = '아직 공통 주소를 만들지 않았습니다!';

// 항목
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_company'] = '회사명';
$_['entry_address_1'] = '주소';
$_['entry_address_2'] = '주소 2';
$_['entry_postcode'] = '우편번호';
$_['entry_city'] = '타운십 도시';
$_['entry_country'] = '국가';
$_['entry_zone'] = '군/지역';
$_['entry_default'] = '기본 주소';

// 오류
$_['error_token'] = '경고: 키가 만료되었습니다!';
$_['error_subscription'] = '경고: 이 주소는 여전히 %s 반복 결제에 묶여 있습니다!';
$_['error_default'] = '경고: 기본 주소를 설정해야 합니다! ';
$_['error_delete'] = '경고: 최소한 하나의 주소 세트가 있어야 합니다! ';
$_['error_firstname'] = '이름은 1~32자여야 합니다! ';
$_['error_lastname'] = '성은 1~32자여야 합니다! ';
$_['error_address_1'] = '주소는 ​​3~128 단어여야 합니다! ';
$_['error_postcode'] = '우편번호는 2~10자여야 합니다! ';
$_['error_city'] = '도시와 도시는 2~128자여야 합니다! ';
$_['error_country'] = '국가를 선택하세요! ';
$_['error_zone'] = '국가/지역을 선택하세요! ';
$_['error_custom_field'] = '%s을(를) 입력해야 합니다! ';
$_['error_regex'] = '%s은(는) 유효한 값이 아닙니다!';