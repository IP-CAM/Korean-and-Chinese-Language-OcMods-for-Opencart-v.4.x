<?php
// 제목
$_['heading_title'] = '연락처';

//텍스트
$_['text_location'] = '우리의 주소';
$_['text_store'] = '저희 매장';
$_['text_contact'] = '연락처';
$_['text_address'] = '주소';
$_['text_telephone'] = '전화';
$_['text_open'] = '영업시간';
$_['text_comment'] = '댓글';
$_['text_message'] = '<p>귀하의 의견이 전송되었습니다! </p>';

// 항목
$_['entry_name'] = '당신의 이름';
$_['entry_email'] = '이메일 편지함';
$_['entry_enquiry'] = '문의내용';

// 이메일
$_['email_subject'] = '%s에게 물어보세요';

// 오류
$_['error_name'] = '이름은 3~32자여야 합니다! ';
$_['error_email'] = '이메일 주소가 올바르지 않습니다! ';
$_['error_enquiry'] = '문의 길이는 10~3000 단어여야 합니다! ';