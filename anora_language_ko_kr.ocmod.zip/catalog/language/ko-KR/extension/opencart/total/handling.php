<?php
//텍스트
$_['text_handling'] = '취급수수료';