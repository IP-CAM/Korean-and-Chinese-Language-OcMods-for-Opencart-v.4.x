<?php
// Text
$_['text_subject']      = '%s - 订单编号 %s';
$_['text_received']     = '您有一笔新订单';
$_['text_order_id']     = '订单编号:';
$_['text_date_added']   = '订单日期:';
$_['text_order_status'] = '订单状态:';
$_['text_product']      = '商品';
$_['text_total']        = '总计';
$_['text_comment']      = '订单备注:';