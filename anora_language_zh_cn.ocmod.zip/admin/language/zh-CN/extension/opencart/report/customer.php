<?php
// Heading
$_['heading_title']     = '会员统计报表';

// Text
$_['text_extension']    = '扩展模块';
$_['text_edit']         = '编辑会员统计报表';
$_['text_success']      = '成功: 会员统计报表已更新!';
$_['text_filter']       = '筛选';
$_['text_year']         = '年';
$_['text_month']        = '月';
$_['text_week']         = '周';
$_['text_day']          = '日';
$_['text_all_status']   = '所有状态';

// Column
$_['column_date_start'] = '起始日期';
$_['column_date_end']   = '截止日期';
$_['column_total']      = '会员数';

// Entry
$_['entry_date_start']  = '起始日期';
$_['entry_date_end']    = '截止日期';
$_['entry_group']       = '统计时间单位';
$_['entry_status']      = '状态';
$_['entry_sort_order']  = '排序';

// Error
$_['error_permission']  = '警告: 您没有权限编辑会员统计报表!';