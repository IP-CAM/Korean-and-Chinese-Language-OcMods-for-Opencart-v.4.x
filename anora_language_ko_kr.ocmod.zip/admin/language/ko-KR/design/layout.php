<?php
// 제목
$_['heading_title'] = '템플릿 관리';

//텍스트
$_['text_success'] = '성공: 템플릿 설정이 업데이트되었습니다! ';
$_['text_list'] = '템플릿 목록';
$_['text_add'] = '템플릿 레이아웃 추가';
$_['text_edit'] = '템플릿 레이아웃 편집';
$_['text_remove'] = '제거';
$_['text_route'] = '템플릿을 사용할 매장과 경로를 선택하세요';
$_['text_module'] = '모듈이 배치될 위치를 선택하세요';
$_['text_default'] = '기본값';
$_['text_content_top'] = '콘텐츠 위 영역';
$_['text_content_bottom'] = '콘텐츠 아래 영역';
$_['text_column_left'] = '왼쪽 영역';
$_['text_column_right'] = '오른쪽 영역';

//열
$_['column_name'] = '템플릿 이름';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '템플릿 이름';
$_['entry_store'] = '스토어';
$_['entry_route'] = '경로';
$_['entry_module'] = '모듈';

// 오류
$_['error_permission'] = '경고: 템플릿을 수정할 권한이 없습니다! ';
$_['error_name'] = '템플릿 이름은 3~64자여야 합니다! ';
$_['error_module'] = '모듈이 필요합니다!';
$_['error_default'] = '경고: 이 템플릿은 스토어의 기본 템플릿이므로 삭제할 수 없습니다! ';
$_['error_store'] = '경고: 이 템플릿은 %s 상점에서 이미 사용 중이므로 삭제할 수 없습니다! ';
$_['error_product'] = '경고: 이 템플릿은 이미 %s 제품에 사용 중이므로 삭제할 수 없습니다! ';
$_['error_category'] = '경고: 이 템플릿은 이미 %s 항목에 사용 중이므로 삭제할 수 없습니다! ';
$_['error_manufacturer'] = '경고: 이 템플릿은 %s 브랜드/라벨에서 이미 사용 중이므로 삭제할 수 없습니다!';
$_['error_information'] = '경고: 이 템플릿은 %s 아이템 상점 페이지에서 이미 사용 중이므로 삭제할 수 없습니다! ';