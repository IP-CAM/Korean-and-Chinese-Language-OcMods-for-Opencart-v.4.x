<?php
// Heading
$_['heading_title']    = '商品分类';

// Text
$_['text_extension']   = '扩充功能';
$_['text_success']     = '成功: 商品分类模块设置已更新！';
$_['text_edit']        = '编辑商品分类模块';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 您没有权限修改商品分类模块！';