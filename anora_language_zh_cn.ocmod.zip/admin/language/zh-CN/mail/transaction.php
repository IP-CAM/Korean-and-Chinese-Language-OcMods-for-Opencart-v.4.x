<?php
// Text
$_['text_subject']  = '%s - 购物金';
$_['text_received'] = '您已收到 %s 元的购物金!';
$_['text_total']    = '您目前的购物金是 %s 元';
$_['text_credit']   = '您可以在下次购买时使用您的购物金结帐。';