<?php
// Heading
$_['heading_title']    = '折价券报表';

// Text
$_['text_extension']   = '扩展模块';
$_['text_edit']        = '编辑折价券报表';
$_['text_success']     = '成功: 折价券报表设置已更新!';
$_['text_filter']      = '筛选';

// Column
$_['column_name']      = '折价券名称';
$_['column_code']      = '折价券代码';
$_['column_orders']    = '订单数';
$_['column_total']     = '总计';
$_['column_action']    = '操作';

// Entry
$_['entry_date_start'] = '开始日期';
$_['entry_date_end']   = '结束日期';
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告: 您没有权限编辑折价券报表!';