<?php
// Heading 
$_['heading_title']      = '购物金';

// Column
$_['column_date_added']  = '添加日期';
$_['column_description'] = '说明';
$_['column_amount']      = '总计 (%s)';

// Text
$_['text_account']       = '我的帐号';
$_['text_transaction']   = '购物金';
$_['text_total']         = '购物金余额 :';
$_['text_no_results']    = '您目前没有任何购物金！';