<?php
// 제목
$_['heading_title'] = '기사';

//텍스트
$_['text_success'] = '성공: 기사 내용이 업데이트되었습니다!';
$_['text_list'] = '글 목록';
$_['text_add'] = '글 추가';
$_['text_edit'] = '글 편집';
$_['text_default'] = '기본값';
$_['text_keyword'] = '공백을 사용하지 마십시오. 공백을 대체하려면 -를 사용하고 정적 URL이 반복되지 않는지 확인하십시오. ';

//열
$_['column_name'] = '글 제목';
$_['column_author'] = '기사 작성자';
$_['column_date_add'] = '날짜 추가';
$_['column_action'] = '액션';

// 항목
$_['entry_image'] = '추천 이미지';
$_['entry_name'] = '글 제목';
$_['entry_description'] = '글 내용';
$_['entry_tag'] = '태그';
$_['entry_meta_title'] = '메타태그 제목';
$_['entry_meta_keyword'] = '메타태그 키워드';
$_['entry_meta_description'] = '메타태그 설명';
$_['entry_topic'] = '글 주제 분류';
$_['entry_author'] = '기사 작성자';
$_['entry_store'] = '스토어';
$_['entry_sort_order'] = '정렬';
$_['entry_status'] = '상태';
$_['entry_keyword'] = '정적 URL';
$_['entry_layout'] = '레이아웃 지정';

// 오류
$_['error_warning'] = '경고: 필드 입력에 오류가 있는지 확인하십시오!';
$_['error_permission'] = '경고: 기사를 편집할 수 있는 권한이 없습니다!';
$_['error_name'] = '글 제목은 1~255단어여야 합니다!';
$_['error_meta_title'] = '메타태그 제목은 1~255자여야 합니다!';
$_['error_keyword'] = '고정 URL은 1~64자여야 합니다!';
$_['error_keyword_exists'] = '정적 URL은 반복될 수 없습니다!';
$_['error_keyword_character'] = '정적 URL은 a-z, 0-9, - 및 _와 같은 문자만 사용할 수 있습니다!';
$_['error_author'] = '글 작성자는 3~64단어여야 합니다!';