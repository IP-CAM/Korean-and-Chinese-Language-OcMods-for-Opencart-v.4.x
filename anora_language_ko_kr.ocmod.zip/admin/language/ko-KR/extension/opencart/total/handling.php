<?php
// 제목
$_['heading_title'] = '수수료';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 수수료 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '수수료 모듈 편집';

// 항목
$_['entry_total'] = '최소 주문금액';
$_['entry_fee'] = '수수료';
$_['entry_tax_class'] = '세금 분류';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 돕다
$_['help_total'] = '주문 금액이 최소 주문 금액에 도달해야 적용됩니다. ';

// 오류
$_['error_permission'] = '경고: 수수료 모듈을 수정할 권한이 없습니다! ';