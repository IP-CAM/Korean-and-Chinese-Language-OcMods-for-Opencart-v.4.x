<?php
//텍스트
$_['text_success'] = '귀하의 선택을 알려주셔서 감사합니다!';
$_['text_cookie'] = '이 웹사이트는 데이터를 저장하기 위해 쿠키를 사용합니다. <a href="%s" class="alert-link modal-link">세부정보</a>를 읽으려면 클릭하세요. ';

// 버튼
$_['button_agree'] = '동의합니다!';
$_['button_disagree'] = '동의하지 않음!';