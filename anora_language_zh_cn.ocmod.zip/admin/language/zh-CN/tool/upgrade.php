<?php
// Heading
$_['heading_title']        = '系统升级';

// Text
$_['text_success']         = '成功: 系统已升级至 %s!';
$_['text_upgrade']         = '检查最新版本';
$_['text_information']     = '版本信息';
$_['text_current_version'] = '目前使用版本';
$_['text_latest_version']  = '最新可用版本';
$_['text_date_added']      = '发布日期';
$_['text_change']          = '更新纪录';
$_['text_status']          = '更新状态';
$_['text_ready']           = '点击 [升级] 按钮升级到最新版本...';
$_['text_download']        = '文档下载中...';
$_['text_install']         = '文档复制中...';
$_['text_patch']           = '更新中...';

// Button
$_['button_upgrade']       = '升级';

// Error
$_['error_permission']     = '警告: 您没有权限操作系统升级!';
$_['error_connection']     = '无法连接更新服务器!';
$_['error_version']        = '版本低于您目前使用版本!';
$_['error_download']       = '无法下载系统更新文档!';
$_['error_file']           = '找不到更新文档!';
$_['error_directory']      = '无法创建目录 %s!';
$_['error_copy']           = '无法复制文档 %s 到 %s!';
$_['error_unzip']          = '无法解开 Zip 压缩档!';