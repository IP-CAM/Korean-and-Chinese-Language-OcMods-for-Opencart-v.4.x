<?php
// Heading
$_['heading_title'] = '은행송금/이체';

//텍스트
$_['text_instruction'] = '은행 송금/송금 안내';
$_['text_description'] = '주문금액을 아래 은행계좌로 송금 또는 이체해주세요. ';
$_['text_payment']     = '결제 확인 후, 주문하신 상품을 배송해 드립니다.';