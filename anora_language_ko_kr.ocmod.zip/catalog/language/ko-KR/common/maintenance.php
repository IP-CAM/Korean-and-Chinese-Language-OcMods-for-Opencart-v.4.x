<?php
// 제목
$_['heading_title'] = '웹사이트 유지관리';

//텍스트
$_['text_maintenance'] = '웹사이트 점검중';
$_['text_message'] = '<h1 style="text-align:center;">현재 웹사이트 점검 중입니다.<br/>나중에 이 사이트를 다시 찾아보시기 바랍니다. </h1>';