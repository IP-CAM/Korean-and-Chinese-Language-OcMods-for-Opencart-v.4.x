<?php
// 텍스트
$_['text_subject'] = '%s - GDPR 요청이 거부되었습니다!';
$_['text_export'] = '계정 내보내기 데이터 요청';
$_['text_remove'] = '계정 삭제 요청';
$_['text_hello'] = '안녕하세요 <strong>%s</strong>,';
$_['text_user'] = '사용자';
$_['text_contact'] = '안타깝게도 귀하의 요청이 거부되었습니다. 자세한 내용은 여기 매장에 문의하세요:';
$_['text_thanks'] = '감사합니다';

// 버튼
$_['button_contact'] = '문의하기';