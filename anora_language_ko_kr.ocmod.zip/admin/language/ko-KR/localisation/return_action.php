<?php
// 제목
$_['heading_title'] = '직업 복귀';

//텍스트
$_['text_success'] = '성공: 복귀 작업 설정이 업데이트되었습니다! ';
$_['text_list'] = '작업 목록 반환';
$_['text_add'] = '반환 작업 추가';
$_['text_edit'] = '복귀 작업 편집';

//열
$_['column_name'] = '작업 이름 반환';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '작업 이름 반환';

// 오류
$_['error_permission'] = '경고: 반환 작업을 수정할 권한이 없습니다! ';
$_['error_name'] = '반환 작업 이름은 3~64자여야 합니다! ';
$_['error_return'] = '경고: %s 반환 항목이 이미 사용 중이므로 이 반환 작업을 삭제할 수 없습니다! ';