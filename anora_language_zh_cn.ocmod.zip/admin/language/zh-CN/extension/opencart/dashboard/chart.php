<?php
// Heading
$_['heading_title'] 	= '销售分析';

// Text
$_['text_extension']   	= '扩充功能';
$_['text_success']     	= '成功: 信息总览销售分析图设置已更新!';
$_['text_edit']        	= '编辑信息总览销售分析图';
$_['text_order']    	= '订单数';
$_['text_customer']		= '客户数';
$_['text_day']      	= '今日';
$_['text_week']     	= '本周';
$_['text_month']    	= '本月';
$_['text_year']     	= '今年';

// Entry
$_['entry_status']		= '状态';
$_['entry_sort_order']	= '排序';
$_['entry_width']		= '宽度';

// Error
$_['error_permission'] 	= '警告: 您没有权限修改信息总览销售分析图!';