<?php
// Heading
$_['heading_title']    = '商品浏览报表';

// Text
$_['text_extension']   = '扩展模块';
$_['text_edit']        = '编辑商品浏览报表';
$_['text_success']     = '成功: 商品浏览报表设置已更新!';
$_['text_progress']    = '已处理 %s / %s!';

// Column
$_['column_name']      = '商品名称';
$_['column_model']     = '型号';
$_['column_viewed']    = '浏览';
$_['column_percent']   = '百分比';

// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告: 您没有权限编辑商品浏览报表!';