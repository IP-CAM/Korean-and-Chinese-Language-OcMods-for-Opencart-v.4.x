<?php
// Heading
$_['heading_title']    = '免运费';

// Text
$_['text_description'] = '免运费';