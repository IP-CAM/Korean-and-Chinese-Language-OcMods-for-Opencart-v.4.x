<?php
// 제목
$_['heading_title'] = '문서 다운로드';

//텍스트
$_['text_success'] = '성공: 다운로드 문서 설정이 업데이트되었습니다! ';
$_['text_list'] = '문서 목록 다운로드';
$_['text_add'] = '다운로드 문서 추가';
$_['text_edit'] = '다운로드 문서 편집';
$_['text_upload'] = '문서가 성공적으로 업로드되었습니다! ';
$_['text_report'] = '통계 보고서';

//열
$_['column_name'] = '문서 이름';
$_['column_ip'] = 'IP';
$_['column_account'] = '계정';
$_['column_store'] = '저장';
$_['column_country'] = '국가';
$_['column_date_add'] = '날짜 추가';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '다운로드 문서 이름';
$_['entry_filename'] = '문서 이름';
$_['entry_mask'] = '마스크';

// 돕다
$_['help_filename'] = '업로드 버튼을 통해 업로드하거나 FTP를 사용할 수 있습니다. ';
$_['help_mask'] = '네티즌이 다운로드에 직접 링크를 시도하는 것을 방지하기 위해 문서 이름과 마스크를 다르게 설정하는 것이 좋습니다. ';

// 오류
$_['error_warning'] = '경고: 양식 필드에 작성된 내용을 확인하십시오!';
$_['error_permission'] = '경고: 다운로드한 문서를 변경할 수 있는 권한이 없습니다! ';
$_['error_name'] = '문서 이름은 3~64자여야 합니다! ';
$_['error_filename'] = '문서 이름은 3~128자여야 합니다! ';
$_['error_filename_character'] = '문서 이름은 a-z, 0-9, - 및 _와 같은 문자만 사용할 수 있습니다!';
$_['error_directory'] = '다운로드한 문서는 저장/다운로드 디렉토리에 있어야 합니다!';
$_['error_exists'] = '문서가 존재하지 않습니다! ';
$_['error_mask'] = '마스크는 3~128단어여야 합니다! ';
$_['error_mask_character'] = '마스크는 a-z, 0-9, - 및 _와 같은 문자만 사용할 수 있습니다!';
$_['error_file_type'] = '잘못된 문서 유형입니다! ';
$_['error_product'] = '경고: %s 제품이 사용되었기 때문에 이 다운로드를 삭제할 수 없습니다! ';