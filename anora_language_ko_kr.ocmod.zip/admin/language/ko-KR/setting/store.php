<?php
// Heading
$_['heading_title'] = '스토어 관리';

//텍스트
$_['text_settings'] = '스토어 관리';
$_['text_success'] = '성공: 매장 관리 설정이 업데이트되었습니다! ';
$_['text_list'] = '스토어 목록';
$_['text_add'] = '스토어 추가';
$_['text_edit'] = '스토어 편집';
$_['text_items'] = '항목';
$_['text_shipping'] = '배송주소';
$_['text_payment'] = '청구서 수신 주소';
$_['text_product'] = '제품';
$_['text_legal'] = '규정';
$_['text_tax'] = '세율';
$_['text_account'] = '계정';
$_['text_checkout'] = '결제';
$_['text_stock'] = '제품 재고';
$_['text_image'] = '이미지 크기';

//열
$_['column_name'] = '상점 이름';
$_['column_url'] = '스토어 URL';
$_['column_action'] = '관리';

// 항목
$_['entry_url'] = '스토어 URL';
$_['entry_meta_title'] = '메타 제목';
$_['entry_meta_description'] = '메타 설명';
$_['entry_meta_keyword'] = '메타태그 키워드';
$_['entry_layout'] = '기본 템플릿';
$_['entry_theme'] = '웹사이트 레이아웃';
$_['entry_name'] = '상점 이름';
$_['entry_owner'] = '스토어 관리자';
$_['entry_address'] = '상점주소';
$_['entry_geocode'] = '위도 및 경도 좌표';
$_['entry_email'] = '이메일 주소';
$_['entry_telephone'] = '전화';
$_['entry_image'] = '이미지';
$_['entry_open'] = '영업시간';
$_['entry_comment'] = '비고';
$_['entry_location'] = '상점 주소';
$_['entry_country'] = '국가';
$_['entry_zone'] = '군 및 도시';
$_['entry_language'] = '프런트 데스크 언어';
$_['entry_currency'] = '통화 설정';
$_['entry_product_description_length'] = '목록 상품 설명 단어 제한';
$_['entry_pagination'] = '페이지당 기본 항목 수';
$_['entry_product_count'] = '분류된 상품수 통계';
$_['entry_cookie'] = '쿠키 개인정보 보호정책';
$_['entry_gdpr'] = 'GDPR 개인정보 보호정책';
$_['entry_tax'] = '세금 포함 가격 표시';
$_['entry_tax_default'] = '매장 위치 세율 사용';
$_['entry_tax_customer'] = '회원의 지방세율을 사용합니다';
$_['entry_customer_group'] = '회원등급';
$_['entry_customer_group_display'] = '회원등급';
$_['entry_customer_price'] = '로그인 후 가격 보기';
$_['entry_account'] = '계정 용어';
$_['entry_cart_weight'] = '장바구니에 담긴 무게 표시';
$_['entry_checkout_guest'] = '비회원 결제';
$_['entry_checkout'] = '체크아웃 약관';
$_['entry_stock_display'] = '재고 표시';
$_['entry_stock_checkout'] = '재고 체크아웃';
$_['entry_logo'] = '스토어 아이콘';
$_['entry_image_category'] = '카테고리 이미지 크기(너비 x 높이)';
$_['entry_image_thumb'] = '제품 썸네일 크기(너비 x 높이)';
$_['entry_image_popup'] = '상품 큰 이미지 크기(가로x세로)';
$_['entry_image_product'] = '상품 목록 썸네일 크기(너비 x 높이)';
$_['entry_image_additional'] = '상품 페이지 추가 이미지 썸네일 크기(너비x높이)';
$_['entry_image_관련'] = '관련 상품 썸네일 크기(너비x높이)';
$_['entry_image_compare'] = '제품 썸네일 크기 비교(너비 x 높이)';
$_['entry_image_wishlist'] = '제품 썸네일 크기에 중점을 둡니다. 크기(너비 x 높이)';
$_['entry_image_cart'] = '장바구니 썸네일 크기(너비 x 높이)';
$_['entry_image_location'] = '썸네일 크기 저장(너비 x 높이)';
$_['entry_width'] = '너비';
$_['entry_height'] = '높이';

// Help
$_['help_url'] = '상점의 전체 URL을 입력하세요. 끝에 \'/\'를 추가하세요. 예: https://www.yourdomain.com/path/<br /><br />URL 또는 하위 URL을 사용하세요. ';
$_['help_geocode'] = '상점 주소의 위도와 경도 좌표를 입력하세요. ';
$_['help_open'] = '귀하의 매장 영업시간입니다. ';
$_['help_comment'] = '회원에게 알리고 싶은 지침은 다음과 같습니다. 예를 들어 상점에서는 수표를 받지 않습니다. ';
$_['help_location'] = '문의 양식에 표시하려는 다른 창고 주소가 있습니다. ';
$_['help_currency'] = '기본 통화를 변경하고 브라우저 캐시에 있는 기존 쿠키를 삭제하세요. ';
$_['help_pagination'] = '각 페이지에 표시되는 항목(예: 제품, 카테고리) 수 결정';
$_['help_product_description_length'] = '목록 모드에서는 제품에 대한 간략한 설명 글자 수 제한(카테고리, 특별 행사 등)';
$_['help_cookie'] = 'EU 법률의 일부로 쿠키 정책을 표시합니다.';
$_['help_gdpr'] = '고객이 계정 삭제를 요청하는 기능과 같은 GDPR 기능을 활성화합니다. ';
$_['help_tax_default'] = '비등록회원은 매장의 지방세율을 사용합니다. 매장의 현지 세율을 사용하여 세금을 계산할 수 있습니다. ';
$_['help_tax_customer'] = '등록회원은 회원의 지방세율을 사용합니다. 매장의 현지 세율을 사용하여 세금을 계산할 수 있습니다. ';
$_['help_customer_group'] = '기본 회원등급입니다. ';
$_['help_customer_group_display'] = '새 회원 등록 시 선택할 수 있는 회원 등급을 표시합니다. ';
$_['help_customer_price'] = '가격은 회원이 로그인한 후에만 표시될 수 있습니다. ';
$_['help_account'] = '등록 약관. ';
$_['help_checkout_guest'] = '등록되지 않은 회원이 직접 결제할 수 있도록 허용합니다. 이 거래는 다운로드 가능한 제품에는 적용되지 않습니다. ';
$_['help_checkout'] = '체크아웃 약관. ';
$_['help_stock_display'] = '제품 페이지에 재고 수량을 표시합니다. ';
$_['help_stock_checkout'] = '회원이 주문한 상품이 품절된 경우에도 결제가 ​​가능합니다. ';
$_['help_product_count'] = '메인 메뉴에는 하위 카테고리의 제품 수가 표시됩니다. 하위 카테고리가 너무 많으면 성능에 어느 정도 영향을 미칠 수 있습니다!';

// Error
$_['error_warning'] = '경고: 입력한 데이터를 확인하세요! ';
$_['error_permission'] = '경고: 스토어 설정을 변경할 권한이 없습니다! ';
$_['error_url'] = '상점 URL이 유효하지 않습니다! ';
$_['error_meta_title'] = '제목은 3~32단어여야 합니다! ';
$_['error_name'] = '상점 이름은 3~32자여야 합니다! ';
$_['error_owner'] = '스토어 관리자 이름은 3~64자여야 합니다!';
$_['error_address'] = '상점 주소는 10~256자여야 합니다!';
$_['error_email'] = '이메일 주소가 올바르지 않습니다!';
$_['error_telephone'] = '전화번호는 3~32자여야 합니다!';
$_['error_product_description_length'] = '상품 설명 길이 제한을 입력해야 합니다!';
$_['error_pagination'] = '각 페이지에 몇 개의 항목을 입력해야 합니까!';
$_['error_customer_group_display'] = '이 기능을 사용하려면 기본 회원 등급에 가입해야 합니다!';
$_['error_default'] = '경고: 기본 저장소는 삭제할 수 없습니다! ';
$_['error_store'] = '경고: 이 상점은 이미 %s개의 주문이 있기 때문에 삭제할 수 없습니다! ';
$_['error_image_thumb'] = '상품 페이지 썸네일 크기를 입력해야 합니다!';
$_['error_image_popup'] = '상품페이지의 큰 이미지 사이즈를 입력하셔야 합니다!';
$_['error_image_product'] = '상품 목록 썸네일 크기를 입력해야 합니다!';
$_['error_image_category'] = '상품 카테고리 목록의 썸네일 크기를 입력해야 합니다!';
$_['error_image_additional'] = '제품 추가 이미지 썸네일 크기를 입력해야 합니다!';
$_['error_image_related'] = '관련 상품 썸네일 크기를 입력해야 합니다!';
$_['error_image_compare'] = '비교 제품 썸네일 크기를 입력해야 합니다!';
$_['error_image_wishlist'] = '해당 상품의 썸네일 크기를 입력해야 합니다!';
$_['error_image_cart'] = '장바구니 상품 썸네일 크기를 입력해야 합니다!';
$_['error_image_location'] = '스토어 썸네일 크기를 입력해야 합니다!';