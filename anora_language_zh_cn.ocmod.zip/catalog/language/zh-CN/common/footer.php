<?php
// Text
$_['text_information']  = '商店信息';
$_['text_service']      = '会员服务';
$_['text_extra']        = '其他信息';
$_['text_contact']      = '联系我们';
$_['text_return']       = '商品退换';
$_['text_sitemap']      = '网站导览';
$_['text_gdpr']         = 'GDPR';
$_['text_manufacturer'] = '品牌导览';
$_['text_voucher']      = '购物礼券';
$_['text_affiliate']    = '推荐计划';
$_['text_special']      = '特价商品';
$_['text_account']      = '会员中心';
$_['text_order']        = '我的订单';
$_['text_wishlist']     = '追踪清单';
$_['text_newsletter']   = '订阅电子报';
$_['text_powered']      = '%s &copy; %s - Powered By <a href="https://www.opencart.com">OpenCart</a>';