<?php
// 제목
$_['heading_title'] = '이메일 알림';

//텍스트
$_['text_mail'] = '회원에게 이메일 알림 보내기';
$_['text_success'] = '이메일이 성공적으로 전송되었습니다! ';
$_['text_sent'] = '이메일이 %s / %s 수신자에게 성공적으로 전송되었습니다! ';
$_['text_default'] = '기본값';
$_['text_newsletter'] = '뉴스레터 구독자';
$_['text_customer_all'] = '모든 회원';
$_['text_customer_group'] = '회원등급 지정';
$_['text_customer'] = '지정된 구성원';
$_['text_affiliate_all'] = '추천회원 전원';
$_['text_affiliate'] = '추천 회원 지정';
$_['text_product'] = '상품 구매자 지정';

// 항목
$_['entry_store'] = '발송인';
$_['entry_to'] = '개체 보내기';
$_['entry_customer_group'] = '회원등급';
$_['entry_customer'] = '지정된 구성원';
$_['entry_affiliate'] = '추천회원';
$_['entry_product'] = '지정상품';
$_['entry_subject'] = '이메일 제목';
$_['entry_message'] = '메일 내용';

// 돕다
$_['help_customer'] = '(자동완성)';
$_['help_affiliate'] = '(자동완성)';
$_['help_product'] = '다음 제품을 구매한 회원에게만 발송됩니다. (자동완성)';

// 오류
$_['error_permission'] = '경고: 이메일 알림을 보낼 권한이 없습니다! ';
$_['error_subject'] = '이메일 알림 제목을 반드시 입력해야 합니다! ';
$_['error_message'] = '이메일 알림 메시지의 내용을 입력해야 합니다! ';
$_['error_email'] = '이메일을 반드시 작성해야 합니다!';