<?php
// Text
$_['text_subject']   = '%s - 您的会员帐号已被拒绝！';
$_['text_welcome']   = '欢迎并感谢您加入 %s！';
$_['text_denied']    = '很遗憾您的申请被拒绝了，若需要更进一步信息请联系网站管理员:';
$_['text_thanks']    = '谢谢';

// Button
$_['button_contact'] = '联系我们';