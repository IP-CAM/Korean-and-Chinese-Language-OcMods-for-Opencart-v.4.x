<?php
// Text
$_['text_currency'] = '币别';