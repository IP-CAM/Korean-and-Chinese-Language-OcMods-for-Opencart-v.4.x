<?php
// Heading
$_['heading_title']      = '订阅状态';

// Text
$_['text_success']       = '成功: 订阅状态已更新!';
$_['text_list']          = '订阅状态清单';
$_['text_add']           = '添加订阅状态';
$_['text_edit']          = '编辑订阅状态';

// Column
$_['column_name']        = '订阅状态名称';
$_['column_action']      = '操作';

// Entry
$_['entry_name']         = '订阅状态名称';

// Error
$_['error_permission']   = '警告: 您没有权限编辑订阅状态!';
$_['error_name']         = '订阅状态名称必须是 3 到 32 个字!';
$_['error_default']      = '警告: 无法删除此订阅状态，因为此项订阅状态已被设置为默认的订阅状态!';
$_['error_subscription'] = '警告: 无法删除此订阅状态，因为此项订阅状态已被指定给 %s 位订阅者!';