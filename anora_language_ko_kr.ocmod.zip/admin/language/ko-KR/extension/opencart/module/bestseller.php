<?php
// 제목
$_['heading_title'] = '인기 판매 품목';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 인기 상품 모듈 설정이 업데이트되었습니다! ';
$_['text_next'] = '성공: %s / %s 인기 상품이 업데이트되었습니다!';
$_['text_edit'] = '인기 판매 제품 모듈 편집';
$_['text_horizontal'] = '가로';
$_['text_vertical'] = '세로형';
$_['text_report'] = '신고';

//열
$_['column_product'] = '제품';
$_['column_total'] = '조각 개수';

// 항목
$_['entry_name'] = '모듈 이름';
$_['entry_axis'] = '배열 방향';
$_['entry_limit'] = '아이템 수량 제한';
$_['entry_width'] = '그림 너비';
$_['entry_height'] = '사진 높이';
$_['entry_status'] = '상태';

// 버튼
$_['button_sync'] = '인기 판매 품목 목록 생성';

// 오류
$_['error_permission'] = '경고: 인기 제품 모듈을 수정할 권한이 없습니다! ';
$_['error_name'] = '모듈 이름은 3~64자 사이여야 합니다!';
$_['error_width'] = '폭을 입력해야 합니다!';
$_['error_height'] = '키를 입력해야 합니다!';