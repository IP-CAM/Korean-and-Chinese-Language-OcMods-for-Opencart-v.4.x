<?php
// Heading
$_['heading_title']    = '简体中文';

// Text
$_['text_extension']   = '扩展模块';
$_['text_success']     = '成功: 简体中文语系已更新!';
$_['text_edit']        = '编辑简体中文';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 您没有权限编辑简体中文!';
