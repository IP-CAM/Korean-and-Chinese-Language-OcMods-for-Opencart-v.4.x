<?php
// Heading 
$_['heading_title'] = '계정 편집';

//텍스트
$_['text_account'] = '내 계정';
$_['text_edit'] = '계정 편집';
$_['text_your_details'] = '기본 개인 데이터';
$_['text_success'] = '성공: 기본 계정 데이터가 업데이트되었습니다.';

// 항목
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_email'] = '이메일';
$_['entry_telephone'] = '휴대폰번호';

// 오류
$_['error_token'] = '경고: 키가 만료되었습니다!';
$_['error_exists'] = '경고: 이 이메일은 등록되었습니다. 다른 이메일을 변경하세요! ';
$_['error_firstname'] = '이름은 1~32자여야 합니다! ';
$_['error_lastname'] = '성은 1~32자여야 합니다! ';
$_['error_email'] = '잘못된 이메일입니다! ';
$_['error_telephone'] = '휴대폰 번호는 3~32자여야 합니다! ';
$_['error_custom_field'] = '%s을(를) 입력해야 합니다! ';
$_['error_regex'] = '%s은(는) 유효한 값이 아닙니다!';