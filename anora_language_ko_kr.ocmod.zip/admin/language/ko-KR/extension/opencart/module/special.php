<?php
// 제목
$_['heading_title'] = '특별 제안';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 특별 제안 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '스페셜 편집';
$_['text_horizontal'] = '수평';
$_['text_vertical'] = '세로형';

// 항목
$_['entry_name'] = '모듈 이름';
$_['entry_axis'] = '배열 방향';
$_['entry_limit'] = '아이템 수량 제한';
$_['entry_width'] = '그림 너비';
$_['entry_height'] = '사진 높이';
$_['entry_status'] = '상태';

// 오류
$_['error_permission'] = '경고: 스페셜 모듈을 수정할 권한이 없습니다! ';
$_['error_name'] = '모듈 이름은 3~64자여야 합니다!';
$_['error_width'] = '그림 너비를 입력해야 합니다!';
$_['error_height'] = '사진 높이를 입력해야 합니다!';