<?php
// 제목
$_['heading_title'] = '개발자 설정';

//텍스트
$_['text_success'] = '성공: 개발자 설정이 업데이트되었습니다!';
$_['text_theme'] = '유형';
$_['text_sass'] = 'SASS';
$_['text_cache'] = '성공: %s 캐시를 지웠습니다!';

//열
$_['column_comComponent'] = '구성요소';
$_['column_action'] = '액션';

// 항목
$_['entry_theme'] = '유형';
$_['entry_sass'] = 'SASS';
$_['entry_cache'] = '캐시';

// 버튼
$_['button_on'] = '활성화';
$_['button_off'] = '비활성화';

// 오류
$_['error_permission'] = '경고: 개발자 설정을 수정할 권한이 없습니다!';