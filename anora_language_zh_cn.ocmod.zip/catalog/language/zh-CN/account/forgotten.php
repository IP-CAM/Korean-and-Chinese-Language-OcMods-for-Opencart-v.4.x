<?php
// Heading 
$_['heading_title']      = '忘记密码?';
$_['heading_reset']      = '重设密码';

// Text
$_['text_account']       = '我的帐号';
$_['text_forgotten']     = '忘记密码';
$_['text_your_email']    = 'Email 信箱';
$_['text_email']         = '请输入您注册帐号时填写的 Email 信箱，并点击继续以发送新密码到您的 Email 信箱！';
$_['text_password']      = '请输入新密码';
$_['text_success']       = '成功: 密码已更新';

// Entry
$_['entry_email']        = 'Email 信箱';
$_['entry_new_password'] = '新密码';
$_['entry_password']     = '新密码';
$_['entry_confirm']      = '确认密码';

// Error
$_['error_email']        = '警告: Email 信箱不在系统的记录中，请重试！';
$_['error_not_found']    = '警告: EMail 信箱不在系统的记录中!';
$_['error_password']     = '密码长度应该是 4 到 20 个字!';
$_['error_confirm']      = '密码与确认密码不相符!';
$_['error_code']         = '密码重置码不正确!';
