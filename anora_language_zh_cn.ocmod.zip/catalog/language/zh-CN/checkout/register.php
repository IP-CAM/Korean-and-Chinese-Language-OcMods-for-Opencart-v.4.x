<?php
// Heading
$_['heading_title']           = '会员数据';

// Text
$_['text_login']              = '如果您有会员帐号，请先 <a href="%s"><strong>登录会员</strong></a>.';
$_['text_register']           = '注册帐号';
$_['text_guest']              = '直接结帐';
$_['text_payment_address']    = '会员地址';
$_['text_shipping_address']   = '运送地址';
$_['text_your_password']      = '密码';
$_['text_agree']              = '我已经阅读并同意 <a href="%s" class="modal-link"><b>%s</b></a>';
$_['text_success_add']        = '成功: 会员帐号已创建!';
$_['text_success_guest']      = '成功: 访客帐号数据已保存!';
$_['text_success_edit']       = '成功: 会员帐号数据已更新。';

// Entry
$_['entry_customer_group']    = '帐号群组';
$_['entry_firstname']         = '名字';
$_['entry_lastname']          = '姓氏';
$_['entry_email']             = 'E-Mail';
$_['entry_telephone']         = '手机号码';
$_['entry_password']          = '密码';
$_['entry_confirm']           = '确认密码';
$_['entry_company']           = '公司名称';
$_['entry_address_1']         = '地址';
$_['entry_address_2']         = '地址 2';
$_['entry_postcode']          = '邮递区号';
$_['entry_city']              = '乡镇市区';
$_['entry_country']           = '国家';
$_['entry_zone']              = '县市/地区';
$_['entry_match']             = '我的运送地址和会员地址相同。';
$_['entry_newsletter']        = '我要订阅 %s 电子报。';

// Error
$_['error_guest']             = '警告: 必须先注册会员才能进行结帐!';
$_['error_firstname']         = '名字必须是 1 到 32 个字!';
$_['error_lastname']          = '姓氏必须是 1 到 32 个字!';
$_['error_customer_group']    = '会员等级无效!';
$_['error_customer_approval'] = '警告: 您的会员等级需要等待审核，不能与访客帐号一起使用。';
$_['error_email']             = 'E-Mail 帐号格式有误!';
$_['error_exists']            = '警告: E-Mail 帐号已经注册过会员!';
$_['error_telephone']         = '手机号码必须是 3 到 32 个字!';
$_['error_password']          = '密码必须是 4 到 20 个字!';
$_['error_confirm']           = '密码与确认密码不相符!';
$_['error_address_1']         = '地址必须是 3 到 128 个字!';
$_['error_city']              = '乡镇市区必须是 2 到 128 个字!';
$_['error_postcode']          = '邮递区号必须是 2 到 10 个字!';
$_['error_country']           = '请选择一个国家别!';
$_['error_zone']              = '请选择县市/地区!';
$_['error_agree']             = '警告: 你必须同意 %s!';
$_['error_custom_field']      = '%s 字段必须输入!';
$_['error_regex']             = '%s 不是有效的值!';
