<?php
// 제목
$_['heading_title'] = '백업/복원';

//텍스트
$_['text_success'] = '성공: 데이터베이스 가져오기가 완료되었습니다! ';

$_['text_backup'] = '백업 테이블 %s 레코드를 %s에서 %s로';
$_['text_restore'] = '%s / %s 복원';
$_['text_option'] = '백업 옵션';
$_['text_history'] = '백업 기록';
$_['text_progress'] = '진행상황';
$_['text_import'] = '상대적으로 큰 백업 파일을 복원하려면 먼저 백업 파일을 <strong>~/storage/backup/</strong> 디렉터리에 FTP로 보내는 것이 좋습니다.';

//열
$_['column_filename'] = '문서 이름';
$_['column_size'] = '문서 크기';
$_['column_date_added'] = '날짜 추가';
$_['column_action'] = '관리';

// 항목
$_['entry_progress'] = '진행상황';
$_['entry_export'] = '테이블 선택';

// 오류
$_['error_permission'] = '경고: 백업/복원 변경 권한이 없습니다! ';
$_['error_export'] = '경고: 내보낼 데이터 테이블을 하나 이상 선택해야 합니다! ';
$_['error_table'] = '%s 테이블은 나열되는 것이 허용되지 않습니다!';
$_['error_file'] = '문서를 찾을 수 없습니다!';
$_['error_directory'] = '디렉토리를 찾을 수 없습니다!';
$_['error_not_found'] = '오류: %s 문서를 찾을 수 없습니다!';
$_['error_headers_sent'] = '오류: 헤더가 이미 전송되었습니다!';
$_['error_upload_size'] = '업로드된 문서 크기는 %s보다 클 수 없습니다!';