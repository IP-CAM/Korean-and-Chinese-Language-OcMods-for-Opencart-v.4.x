<?php
// Heading 
$_['heading_title'] = '계정 로그아웃';

//텍스트
$_['text_message'] = '<p>귀하는 계정에서 로그아웃했으므로 컴퓨터를 떠나도 안전합니다. </p>';
$_['text_account'] = '내 계정';
$_['text_logout'] = '로그아웃';