<?php
// Heading
$_['heading_title']     = '商品特性';

// Text
$_['text_success']      = '成功: 商品特性设置已更新！';
$_['text_list']         = '商品特性清单';
$_['text_add']          = '添加商品特性';
$_['text_edit']         = '编辑商品特性';
$_['text_group']        = '商品特性群组';
$_['text_value']        = '商品特性值';

// Column
$_['column_group']      = '商品特性群组';
$_['column_sort_order'] = '显示排序';
$_['column_action']     = '管理';

// Entry
$_['entry_group']       = '商品特性群组名称';
$_['entry_name']        = '商品特性名称';
$_['entry_sort_order']  = '显示排序';

// Error
$_['error_warning']     = '警告: 请确实检查表单字段填写的内容!';
$_['error_permission']  = '警告: 您没有权限修改商品特性！';
$_['error_group']       = '商品特性群组名称必须是 1 到 64 字！';
$_['error_name']        = '商品特性名称必须是 1 到 64 字！';
$_['error_values']      = '警告: 商品特性值必须输入!';