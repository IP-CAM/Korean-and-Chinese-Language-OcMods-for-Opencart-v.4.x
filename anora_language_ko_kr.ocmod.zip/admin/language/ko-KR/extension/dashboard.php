<?php
// 제목
$_['heading_title'] = '정보 개요';

//텍스트
$_['text_success'] = '성공: 정보 개요 모듈 설정이 업데이트되었습니다!';
$_['text_list'] = '정보 개요 모듈 목록';

//열
$_['column_name'] = '정보 개요 이름';
$_['column_width'] = '너비';
$_['column_status'] = '상태';
$_['column_sort_order'] = '정렬 표시';
$_['column_action'] = '액션';

// 오류
$_['error_permission'] = '경고: 정보 개요 모듈을 편집할 수 있는 권한이 없습니다!';
$_['error_extension'] = '경고: 확장 모듈이 존재하지 않습니다!';