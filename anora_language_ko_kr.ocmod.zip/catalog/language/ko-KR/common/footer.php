<?php
//텍스트
$_['text_information'] = '상점정보';
$_['text_service'] = '회원 서비스';
$_['text_extra'] = '기타 정보';
$_['text_contact'] = '연락처';
$_['text_return'] = '상품반품';
$_['text_sitemap'] = '웹사이트 탐색';
$_['text_gdpr'] = 'GDPR';
$_['text_manufacturer'] = '브랜드 탐색';
$_['text_voucher'] = '쇼핑상품권';
$_['text_affiliate'] = '추천 프로그램';
$_['text_special'] = '특별 제안';
$_['text_account'] = '회원센터';
$_['text_order'] = '내 주문';
$_['text_wishlist'] = '추적 목록';
$_['text_newsletter'] = '뉴스레터 구독';
$_['text_powered'] = '%s &copy; %s - <a href="https://www.opencart.com">OpenCart</a> 제공';