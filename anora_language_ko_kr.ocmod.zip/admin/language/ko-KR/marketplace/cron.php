<?php
// 제목
$_['heading_title'] = '작업 일정(크론 작업)';

//텍스트
$_['text_success'] = '성공: 작업 일정 설정이 업데이트되었습니다!';
$_['text_instruction'] = '작업 스케줄링 소개';
$_['text_list'] = '작업 일정 목록';
$_['text_cron_1'] = '작업 스케줄러는 정기적으로 실행되는 작업 일정입니다. 작업 스케줄러 작업을 사용하도록 서버를 설정하려면 <a href="http://docs.opencart.com/ URL을 읽으세요. 확장/ cron/" target="_blank" class="alert-link">opencart 문서</a> 웹페이지.';
$_['text_cron_2'] = '매시간 실행되도록 작업 일정을 설정해야 합니다. ';
$_['text_info'] = '작업 일정 정보';
$_['text_hour'] = '시간';
$_['text_day'] = '요일';
$_['text_month'] = '월';

//열
$_['column_code'] = '작업 일정 코드';
$_['column_cycle'] = '주기';
$_['column_date_added'] = '날짜 추가';
$_['column_date_modified'] = '수정된 날짜';
$_['column_action'] = '액션';

// 항목
$_['entry_cron'] = '작업 예약 URL';
$_['entry_description'] = '작업 일정 설명';

// 오류
$_['error_permission'] = '경고: 작업 일정을 편집할 수 있는 권한이 없습니다!';