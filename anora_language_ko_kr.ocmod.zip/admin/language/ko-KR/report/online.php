<?php
// 제목
$_['heading_title'] = '온라인 방문자';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 온라인 방문자 설정이 업데이트되었습니다!';
$_['text_list'] = '온라인 방문자 목록';
$_['text_filter'] = '방문자 필터';
$_['text_guest'] = '손님';

//열
$_['column_ip'] = 'IP';
$_['column_customer'] = '고객';
$_['column_url'] = '마지막으로 본 페이지';
$_['column_referer'] = 'from';
$_['column_date_added'] = '시간';
$_['column_action'] = '관리';

// 항목
$_['entry_ip'] = 'IP';
$_['entry_customer'] = '고객';

// 오류
$_['error_permission'] = '경고: 온라인 방문자를 편집할 수 있는 권한이 없습니다!';