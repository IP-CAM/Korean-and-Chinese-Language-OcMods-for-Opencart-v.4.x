<?php
// 제목
$_['heading_title'] = '계정 등록';

//텍스트
$_['text_account'] = '내 계정';
$_['text_register'] = '계정 등록';
$_['text_account_already'] = '새 회원이시라면 아래 양식을 작성하여 등록해 주십시오. 이미 이 사이트의 회원이시라면 <a href="%s">로그인</a 하시기 바랍니다 >. ';
$_['text_your_details'] = '개인정보';
$_['text_newsletter'] = '뉴스레터 구독';
$_['text_your_password'] = '계정 비밀번호';
$_['text_agree'] = '<a href="%s" class="agree"><b>%s</b></a>를 읽었으며 이에 동의합니다.';

// 항목
$_['entry_customer_group'] = '회원등급';
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_email'] = '이메일 편지함';
$_['entry_telephone'] = '연락처 번호';
$_['entry_newsletter'] = '뉴스레터 구독';
$_['entry_password'] = '비밀번호';
$_['entry_confirm'] = '비밀번호 확인';

// 오류
$_['error_token'] = '경고: 키가 만료되었습니다!';
$_['error_exists'] = '경고: 이 이메일 주소는 등록되었습니다. 다른 이메일 주소로 변경하세요! ';
$_['error_customer_group'] = '잘못된 회원등급!';
$_['error_firstname'] = '이름은 1~32자여야 합니다! ';
$_['error_lastname'] = '성은 1~32자여야 합니다! ';
$_['error_email'] = '잘못된 이메일입니다! ';
$_['error_telephone'] = '전화번호는 3~32자여야 합니다! ';
$_['error_custom_field'] = '%s을(를) 입력해야 합니다! ';
$_['error_regex'] = '%s이(가) 틀렸습니다!';
$_['error_password'] = '비밀번호는 4~20자 사이여야 합니다! ';
$_['error_agree'] = '경고: %s 회원 약관에 동의하지 않았습니다! ';