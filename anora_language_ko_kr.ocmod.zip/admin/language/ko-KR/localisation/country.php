<?php
// 제목
$_['heading_title'] = '국가관리';

//텍스트
$_['text_success'] = '성공: 업데이트 국가 관리 설정이 업데이트되었습니다! ';
$_['text_list'] = '국가 목록';
$_['text_add'] = '국가 추가';
$_['text_edit'] = '국가 수정';
$_['text_filter'] = '필터';

//열
$_['column_name'] = '국가명';
$_['column_iso_code_2'] = 'ISO 코드(2)';
$_['column_iso_code_3'] = 'ISO 코드(3)';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '국가명';
$_['entry_iso_code_2'] = 'ISO 코드(2)';
$_['entry_iso_code_3'] = 'ISO 코드(3)';
$_['entry_address_format'] = '주소 형식';
$_['entry_postcode_required'] = '우편번호 필요';
$_['entry_status'] = '상태';

// 오류
$_['error_permission'] = '경고: 국가 설정을 변경할 권한이 없습니다! ';
$_['error_name'] = '경고: 국가 이름은 1~128자 사이여야 합니다! ';
$_['error_default'] = '경고: 이 국가는 스토어의 기본 국가로 설정되어 있으므로 삭제할 수 없습니다! ';
$_['error_store'] = '경고: 이 국가는 이미 %s 상점에 설정되어 있으므로 삭제할 수 없습니다! ';
$_['error_address'] = '경고: 이 국가는 %s 공통 주소 레코드에 이미 설정되어 있으므로 삭제할 수 없습니다! ';
$_['error_zone'] = '경고: 이 국가는 %s개 카운티 및 도시로 설정되어 있으므로 삭제할 수 없습니다! ';
$_['error_zone_to_geo_zone'] = '경고: 이 국가는 이미 %s 지역으로 설정되어 있으므로 삭제할 수 없습니다! ';