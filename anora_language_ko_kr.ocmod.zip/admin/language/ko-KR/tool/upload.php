<?php
// 제목
$_['heading_title'] = '문서 업로드';

//텍스트
$_['text_success'] = '성공: 문서 업로드 설정이 업데이트되었습니다! ';
$_['text_list'] = '문서 목록 업로드';
$_['text_filter'] = '필터';

//열
$_['column_name'] = '업로드 문서 이름';
$_['column_code'] = '코드';
$_['column_date_added'] = '날짜 추가';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '업로드 문서 이름';
$_['entry_filename'] = '문서 이름';
$_['entry_date_from'] = '날짜 추가(시작)';
$_['entry_date_to'] = '날짜 추가(~)';

// 오류
$_['error_permission'] = '경고: 문서를 업로드할 권한이 없습니다! ';
$_['error_not_found'] = '오류: %s 문서를 찾을 수 없습니다!';
$_['error_headers_sent'] = '오류: 헤더가 이미 전송되었습니다!';
$_['error_upload'] = '문서를 업로드할 수 없습니다!';
$_['error_filename'] = '문서 이름은 3~128자여야 합니다!';
$_['error_file_type'] = '잘못된 문서 형식입니다!';