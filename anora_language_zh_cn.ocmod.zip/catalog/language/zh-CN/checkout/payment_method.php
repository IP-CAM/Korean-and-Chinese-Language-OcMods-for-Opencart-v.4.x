<?php
// Heading
$_['heading_title']          = '付款方式';

// Text
$_['text_payment_method']    = '付款方式选项';
$_['text_payment']           = '请选择付款方式';
$_['text_comments']          = '订单备注';
$_['text_agree']             = '我已阅读并同意 <a href="%s" class="modal-link"><b>%s</b></a>';
$_['text_success']           = '成功: 付款方式已更新!';
$_['text_comment']           = '成功: 订单备注已添加!';

// Entry
$_['entry_payment_method']   = '选择付款方式...';

// Error
$_['error_customer']         = '必须有会员数据!';
$_['error_payment_address']  = '警告: 必须有会员地址!';
$_['error_shipping_address'] = '必须有运送地址!';
$_['error_shipping_method']  = '必须选择运送方式!';
$_['error_payment_method']   = '警告: 必须选择付款方式!';
$_['error_no_payment']       = '警告: 没有可用的付款方式，请 <a href="%s">联系客服人员</a> 协助!';