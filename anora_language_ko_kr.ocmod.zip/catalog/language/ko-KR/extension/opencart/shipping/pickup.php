<?php
// 제목
$_['heading_title'] = '매장픽업';

//텍스트
$_['text_description'] = '상점에서 상품을 수령하세요';