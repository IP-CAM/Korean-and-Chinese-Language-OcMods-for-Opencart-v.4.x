<?php
// 제목
$_['heading_title'] = '마케팅 캠페인';

//텍스트
$_['text_success'] = '성공: 캠페인 관리 설정이 업데이트되었습니다! ';
$_['text_list'] = '마케팅 활동 목록';
$_['text_add'] = '마케팅 활동 추가';
$_['text_edit'] = '마케팅 캠페인 편집';
$_['text_filter'] = '활동 필터';
$_['text_history'] = '활동기록';
$_['text_history_add'] = '기록 추가';
$_['text_report'] = '통계 보고서';

//열
$_['column_name'] = '활동 이름';
$_['column_code'] = '추적코드';
$_['column_clicks'] = '조회수';
$_['column_orders'] = '주문수';
$_['column_ip'] = 'IP';
$_['column_account'] = '계정';
$_['column_store'] = '저장';
$_['column_country'] = '국가';
$_['column_date_added'] = '날짜 추가';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '활동 이름';
$_['entry_description'] = '활동 설명';
$_['entry_code'] = '추적코드';
$_['entry_example'] = '링크 예시';
$_['entry_date_from'] = '날짜 추가(시작)';
$_['entry_date_to'] = '날짜 추가(~)';

// 돕다
$_['help_code'] = '추적 코드는 마케팅 캠페인에 사용됩니다. ';
$_['help_example'] = '시스템이 추천자를 추적할 수 있도록 URL 끝에 추적 코드를 추가하세요. ';

// 오류
$_['error_permission'] = '경고: 캠페인을 수정할 권한이 없습니다!';
$_['error_name'] = '활동 이름은 1~32자여야 합니다!';
$_['error_code'] = '추적코드를 입력해야 합니다!';
$_['error_exists'] = '이 추적 코드는 다른 마케팅 캠페인에서 사용되었습니다!';