<?php
// Text
$_['text_subject']  = '%s - 红利点数';
$_['text_received'] = '您获得了 %s 点的红利点数!';
$_['text_total']    = '您目前累计的红利点数为 %s 点';