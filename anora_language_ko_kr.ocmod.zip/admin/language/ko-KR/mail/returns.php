<?php
//텍스트
$_['text_subject'] = '%s - 상태 업데이트 %s 반환';
$_['text_return_id'] = '반품번호(ID):';
$_['text_date_added'] = '귀국 날짜:';
$_['text_return_status'] = '귀하의 반품 제품이 다음 상태로 업데이트되었습니다:';
$_['text_comment'] = '귀하의 반품 및 교환 사항:';
$_['text_footer'] = '질문이 있으시면 이 이메일에 회신해 주십시오. ';