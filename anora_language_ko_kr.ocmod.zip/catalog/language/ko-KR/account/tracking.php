<?php
// 제목
$_['heading_title'] = '추천 추적';

//텍스트
$_['text_account'] = '내 계정';
$_['text_description'] = '추천 보너스를 받으려면 추적 코드를 URL에 추가해야 합니다. 아래 도구를 사용하여 %s 웹사이트에 대한 추적 링크를 생성할 수 있습니다. ';

// 항목
$_['entry_code'] = '추천 추적 코드';
$_['entry_generator'] = '추적링크 생성';
$_['entry_link'] = '추적링크';

// 돕다
$_['help_generator'] = '추적링크를 생성하려는 제품을 입력하세요';