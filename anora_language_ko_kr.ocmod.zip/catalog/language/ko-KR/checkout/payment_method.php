<?php
// Heading
$_['heading_title']          = '결제수단';

// Text
$_['text_payment_method']    = '결제수단 옵션';
$_['text_payment']           = '결제수단을 선택해주세요';
$_['text_comments']          = '주문 메모';
$_['text_agree']             = '<a href="%s" class="modal-link"><b>%s</b></a>를 읽었으며 이에 동의합니다.';
$_['text_success'] = '성공: 결제수단이 업데이트되었습니다!';
$_['text_comment'] = '성공: 주문 댓글이 추가되었습니다!';

// Entry
$_['entry_payment_method']   = '결제수단 선택...';

// Error
$_['error_customer']         = '회원정보가 있어야 합니다!';
$_['error_payment_address']  = '경고: 회원 주소가 필요합니다!';
$_['error_shipping_address'] = '배송지 주소가 있어야 합니다!';
$_['error_shipping_method']  = '배송 방법을 선택해야 합니다!';
$_['error_payment_method']   = '경고: 결제 방법을 선택해야 합니다!';
$_['error_no_payment']       = '경고: 사용 가능한 결제 방법이 없습니다. 도움이 필요하면 <a href="%s">고객 서비스에 문의</a>하세요!';