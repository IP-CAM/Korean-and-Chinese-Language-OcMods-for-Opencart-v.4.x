<?php
// 제목
$_['heading_title'] = '보너스 포인트';

//열
$_['column_date_add'] = '날짜 추가';
$_['column_description'] = '설명';
$_['column_points'] = '보너스 포인트';

//텍스트
$_['text_account'] = '내 계정';
$_['text_reward'] = '보너스 포인트';
$_['text_total'] = '누적된 보너스 포인트:';
$_['text_no_results'] = '아직 보너스 포인트가 없습니다! ';