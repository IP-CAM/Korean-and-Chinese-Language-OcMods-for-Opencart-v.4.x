<?php
// Heading 
$_['heading_title']     = '会员中心';

// Text
$_['text_register']     = '会员注册';
$_['text_login']        = '会员登录';
$_['text_logout']       = '会员注销';
$_['text_forgotten']    = '忘记密码';
$_['text_account']      = '我的帐号';
$_['text_edit']         = '编辑帐号';
$_['text_password']     = '变更密码';
$_['text_address']      = '常用地址';
$_['text_wishlist']     = '追踪清单';
$_['text_order']        = '我的订单';
$_['text_download']     = '我的下载';
$_['text_reward']       = '我的点数';
$_['text_return']       = '商品退换';
$_['text_transaction']  = '购物金';
$_['text_newsletter']   = '订阅电子报';
$_['text_subscription'] = '我的订阅';