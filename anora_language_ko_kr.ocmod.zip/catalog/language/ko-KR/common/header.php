<?php
//텍스트
$_['text_wishlist'] = '추적 목록(%s)';
$_['text_shopping_cart'] = '장바구니';
$_['text_account'] = '회원센터';
$_['text_register'] = '회원가입';
$_['text_login'] = '회원 로그인';
$_['text_order'] = '내 주문';
$_['text_transaction'] = '쇼핑 크레딧';
$_['text_download'] = '내 다운로드';
$_['text_logout'] = '회원 로그아웃';
$_['text_checkout'] = '결제';