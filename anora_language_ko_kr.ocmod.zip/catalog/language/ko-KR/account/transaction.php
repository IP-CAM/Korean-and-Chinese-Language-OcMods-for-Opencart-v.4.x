<?php
// 제목
$_['heading_title'] = '쇼핑 크레딧';

//열
$_['column_date_add'] = '날짜 추가';
$_['column_description'] = '설명';
$_['column_amount'] = '총계(%s)';

//텍스트
$_['text_account'] = '내 계정';
$_['text_transaction'] = '쇼핑 크레딧';
$_['text_total'] = '쇼핑 크레딧 잔액:';
$_['text_no_results'] = '현재 쇼핑 크레딧이 없습니다! ';