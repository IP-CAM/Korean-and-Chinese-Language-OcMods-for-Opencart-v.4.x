<?php
// Heading
$_['heading_title'] = '您要开启的页面不存在！';

// Text
$_['text_error']    = '您要开启的页面不存在！';