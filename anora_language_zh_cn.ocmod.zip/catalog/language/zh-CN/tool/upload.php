<?php
// Text
$_['text_upload']     = '文件已经成功上传！';

// Error
$_['error_filename']  = '文件名称必须是 3 到 64 个字！';
$_['error_file_type'] = '无效的文件类型！';
$_['error_upload']    = '必须上传文件！';