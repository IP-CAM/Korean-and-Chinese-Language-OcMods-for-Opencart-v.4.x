<?php
// 제목
$_['heading_title'] = '행정구역 관리';

//텍스트
$_['text_success'] = '성공: 행정 구역 데이터 설정이 업데이트되었습니다! ';
$_['text_list'] = '행정구역 목록';
$_['text_add'] = '행정구역 추가';
$_['text_edit'] = '행정구역 편집';
$_['text_filter'] = '필터';

//열
$_['column_name'] = '행정구역명';
$_['column_code'] = '행정지역번호';
$_['column_country'] = '국가명';
$_['column_action'] = '액션';

// 항목
$_['entry_name'] = '행정구역명';
$_['entry_code'] = '행정지역번호';
$_['entry_country'] = '국가';
$_['entry_status'] = '상태';

// 오류
$_['error_permission'] = '경고: 행정구역 설정을 변경할 수 있는 권한이 없습니다.';
$_['error_name'] = '경고: 구역 이름은 3~128자여야 합니다! ';
$_['error_default'] = '경고: 이 자치구는 상점의 기본 자치구이므로 삭제할 수 없습니다! ';
$_['error_store'] = '경고: 이 자치구는 %s 상점에서 이미 사용하고 있기 때문에 삭제할 수 없습니다! ';
$_['error_address'] = '경고: %s 주소록 기록이 이미 사용 중이므로 이 관리 영역을 삭제할 수 없습니다! ';
$_['error_zone_to_geo_zone'] = '경고: %s 구역이 이미 사용 중이므로 이 구역을 삭제할 수 없습니다! ';