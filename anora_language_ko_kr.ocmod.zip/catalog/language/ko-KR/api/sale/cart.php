<?php
//텍스트
$_['text_success'] = '성공: 장바구니가 업데이트되었습니다! ';
$_['text_subscription'] = '구독 계획';
$_['text_subscription_trial'] = '%s 매 %d %s(s)마다 %d 결제 후 ';
$_['text_subscription_duration'] = '%s 매 %d %s(s)마다 %d 결제';
$_['text_subscription_cancel'] = '취소될 때까지 %s마다 %d %s(s)';
$_['text_day'] = '요일';
$_['text_week'] = '주';
$_['text_semi_month'] = '반달';
$_['text_month'] = '월';
$_['text_year'] = '연도';
$_['text_for'] = '%s %s 상품권';

// 오류
$_['error_stock'] = '*** 표시가 있는 품목은 수량이 부족하거나 재고가 없음을 나타냅니다! ';
$_['error_minimum'] = '%s 최소 구매 수량은 %s 개입니다! ';
$_['error_store'] = '이 제품은 더 이상 구매할 수 없습니다! ';
$_['error_required'] = '%s을(를) 입력해야 합니다!';
$_['error_product'] = '경고: 제품을 찾을 수 없습니다!';
$_['error_subscription'] = '구독 요금제를 선택하세요!';