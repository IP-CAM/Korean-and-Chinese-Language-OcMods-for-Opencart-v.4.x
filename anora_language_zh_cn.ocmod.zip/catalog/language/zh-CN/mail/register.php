<?php
// Text
$_['text_subject']        = '%s - 感谢您的注册';
$_['text_welcome']        = '欢迎并感谢您加入 %s!';
$_['text_login']          = '您的帐号现已经创建，您可以到我们的网站或以下URL使用您的电子邮件和密码登录网站:';
$_['text_approval']       = '您的帐号必须先通过审核才能登录，通过审核后，您可以到我们的网站或以下URL使用您的电子邮件和密码登录网站:';
$_['text_service']        = '登录后，您能够查看订单状态、查看订购记录、和更多的管理项目。';
$_['text_thanks']         = '谢谢,';
$_['text_new_customer']   = '新会员';
$_['text_signup']         = '有一位新会员注册:';
$_['text_customer_group'] = '会员等级:';
$_['text_firstname']      = '名字:';
$_['text_lastname']       = '姓氏:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = '电话:';

// Button
$_['button_login']        = '登录';
