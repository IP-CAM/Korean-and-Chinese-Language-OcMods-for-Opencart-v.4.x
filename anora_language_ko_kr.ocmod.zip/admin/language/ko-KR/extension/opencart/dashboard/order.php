<?php
// 제목
$_['heading_title'] = '총 주문수';

//텍스트
$_['text_extension'] = '확장 기능';
$_['text_success'] = '성공: 정보 개요의 총 주문 번호 설정이 업데이트되었습니다!';
$_['text_edit'] = '정보 편집 개요에 대한 총 주문 수';
$_['text_view'] = '세부정보 보기...';

// 항목
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';
$_['entry_width'] = '너비';

// 오류
$_['error_permission'] = '경고: 정보 개요에서 총 주문 수를 수정할 권한이 없습니다!';