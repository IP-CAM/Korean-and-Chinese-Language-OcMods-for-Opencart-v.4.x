<?php
// Heading
$_['heading_title']     = '运送模块';

// Text
$_['text_success']      = '成功: 运送模块设置已更新!';
$_['text_list']         = '运送模块清单';

// Column
$_['column_name']       = '运送模块名称';
$_['column_status']     = '状态';
$_['column_sort_order'] = '显示排序';
$_['column_action']     = '操作';

// Error
$_['error_permission']  = '警告: 您没有权限编辑运送模块!';
$_['error_extension']   = '警告: 扩展模块不存在!';