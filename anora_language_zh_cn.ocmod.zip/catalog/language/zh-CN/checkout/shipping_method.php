<?php
// Heading
$_['heading_title']          = '运送方式';

// Text
$_['text_shipping_method']   = '运送方式选项';
$_['text_shipping']          = '请选择合适的运送方式';
$_['text_success']           = '运送方式已套用!';

// Entry
$_['entry_shipping_method']  = '选择运送方式...';

// Error
$_['error_customer']         = '必须有客户数据!';
$_['error_payment_address']  = '警告: 必须有会员地址!';
$_['error_shipping_address'] = '警告: 必须有运送地址!';
$_['error_shipping_method']  = '警告: 必须选择运送方式!';
$_['error_no_shipping']      = '警告: 没有可用的运送方式，请 <a href="%s">联系客服人员</a> 协助!';
