<?php
// Heading
$_['heading_title']    = '语系模块';

// Text
$_['text_success']     = '成功: 语系模块已更新!';
$_['text_list']        = '语系清单';

// Column
$_['column_name']      = '语系名称';
$_['column_status']    = '状态';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您没有权限编辑语系模块!';
$_['error_extension']  = '警告: 语系模块不存在!';