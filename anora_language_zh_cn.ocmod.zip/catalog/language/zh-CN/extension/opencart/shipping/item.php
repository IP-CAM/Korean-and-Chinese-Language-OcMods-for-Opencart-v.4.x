<?php
// Heading
$_['heading_title']    = '按件计费';

// Text
$_['text_description'] = '按件数计算运费';