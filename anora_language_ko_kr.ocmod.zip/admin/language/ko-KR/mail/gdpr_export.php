<?php
// 텍스트
$_['text_subject'] = '%s - GDPR 내보내기 요청이 완료되었습니다!';
$_['text_request'] = '개인 데이터 내보내기';
$_['text_hello'] = '안녕하세요 <strong>%s</strong>,';
$_['text_user'] = '사용자';
$_['text_gdpr'] = '귀하의 GDPR 데이터 요청이 이제 완료되었습니다. 아래에서 귀하의 GDPR 데이터를 찾을 수 있습니다.';
$_['text_account'] = '계정';
$_['text_customer'] = '개인정보';
$_['text_address'] = '주소';
$_['text_addresses'] = '주소';
$_['text_name'] = '고객 이름';
$_['text_recipient'] = '수신자';
$_['text_email'] = '이메일';
$_['text_telephone'] = '전화';
$_['text_company'] = '회사';
$_['text_address_1'] = '주소 1';
$_['text_address_2'] = '주소 2';
$_['text_postcode'] = '우편번호';
$_['text_city'] = '도시';
$_['text_country'] = '국가';
$_['text_zone'] = '지역 / 주';
$_['text_history'] = '로그인 기록';
$_['text_ip'] = 'IP';
$_['text_date_added'] = '추가된 날짜';
$_['text_thanks'] = '감사합니다';