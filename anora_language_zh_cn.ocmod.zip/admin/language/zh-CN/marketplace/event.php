<?php
// Heading
$_['heading_title']     = '事件功能管理';

// Text
$_['text_success']      = '成功: 事件功能模块设置已更新!';
$_['text_list']         = '事件功能清单';
$_['text_event']        = '扩充机制是使用事件功能模块来覆盖商店的默认功能。 如果您遇到问题，可以在此处停用或启用事件功能模块。';
$_['text_info']         = '事件功能信息';

// Column
$_['column_code']       = '事件功能代码';
$_['column_sort_order'] = '排序';
$_['column_action']     = '操作';

// Entry
$_['entry_description'] = '说明';
$_['entry_trigger']     = '触发时机';
$_['entry_action']      = '操作';

// Error
$_['error_permission']  = '警告: 您没有权限编辑事件功能模块!';
