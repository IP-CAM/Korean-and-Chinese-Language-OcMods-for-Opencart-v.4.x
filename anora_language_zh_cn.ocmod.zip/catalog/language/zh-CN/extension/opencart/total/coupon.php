<?php
// Heading
$_['heading_title'] = '使用折价券';

// Text
$_['text_coupon']   = '折价券 (%s)';
$_['text_success']  = '成功: 折价券已被套用!';
$_['text_remove']   = '成功: 折价券已被移除!';

// Entry
$_['entry_coupon']  = '折价券代码';

// Error
$_['error_coupon']  = '警告: 折价券代码可能是无效、过期、或超过它的使用限制!';
$_['error_status']  = '警告: 商店的折价券功能未启用!';