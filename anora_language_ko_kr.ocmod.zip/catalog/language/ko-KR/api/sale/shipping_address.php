<?php
//텍스트
$_['text_success'] = '성공: 배송주소가 설정되었습니다!';

// 오류
$_['error_firstname'] = '이름은 1~32자여야 합니다! ';
$_['error_lastname'] = '성은 1~32자여야 합니다! ';
$_['error_address_1'] = '주소는 ​​3~128 단어여야 합니다! ';
$_['error_city'] = '도시와 도시는 3~128자여야 합니다! ';
$_['error_postcode'] = '우편번호는 2~10자여야 합니다! ';
$_['error_country'] = '국가를 선택하세요! ';
$_['error_zone'] = '국가/지역을 선택하세요! ';
$_['error_custom_field'] = '%s을(를) 입력해야 합니다!';
$_['error_regex'] = '%s은(는) 유효한 값이 아닙니다!';
$_['error_shipping'] = '경고: 배송할 항목이 없습니다.';