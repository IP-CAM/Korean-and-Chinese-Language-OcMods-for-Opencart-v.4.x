<?php
// Text
$_['text_success']  = '成功: 红利点数支付已套用!';
$_['text_remove']   = '成功: 红利点数支付已移除!';

// Error
$_['error_reward']  = '警告: 请输入要支付的红利点数!';
$_['error_points']  = '警告: 您的红利点数不足 %s 点!';
$_['error_maximum'] = '警告: 您最多能使用的红利点数是 %s 点!';