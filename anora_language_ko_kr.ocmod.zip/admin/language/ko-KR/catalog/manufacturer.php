<?php
// 제목
$_['heading_title'] = '브랜드/라벨';

//텍스트
$_['text_success'] = '성공: 브랜드/브랜드 데이터 설정이 업데이트되었습니다! ';
$_['text_list'] = '브랜드/브랜드 목록';
$_['text_add'] = '브랜드/브랜드 추가';
$_['text_edit'] = '브랜드/라벨 편집';
$_['text_default'] = '기본값';
$_['text_keyword'] = '공백을 사용하지 말고, 공백을 대체하려면 -를 사용하고, 정적 URL(SEO URL)이 반복되지 않도록 하세요. ';

//열
$_['column_name'] = '브랜드/브랜드 이름';
$_['column_sort_order'] = '정렬 표시';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '브랜드/브랜드 이름';
$_['entry_store'] = '스토어';
$_['entry_keyword'] = '정적 URL';
$_['entry_image'] = '아이콘';
$_['entry_sort_order'] = '정렬 표시';
$_['entry_layout'] = '템플릿 지정';

// 오류
$_['error_warning'] = '경고: 양식 필드에 작성된 내용을 확인하십시오!';
$_['error_permission'] = '경고: 브랜드/브랜드 데이터를 변경할 권한이 없습니다! ';
$_['error_name'] = '브랜드/브랜드 이름은 1~64자 사이여야 합니다! ';
$_['error_keyword'] = '고정 URL(SEO URL)은 1~64자여야 합니다!';
$_['error_keyword_exists'] = '정적 URL(SEO URL)은 반복되어서는 안됩니다!';
$_['error_keyword_character'] = '정적 URL(SEO URL)은 a-z, 0-9, - 및 _와 같은 문자만 사용할 수 있습니다!';
$_['error_product'] = '경고: 이 브랜드/브랜드는 %s 제품에 지정되어 있으므로 삭제할 수 없습니다!';