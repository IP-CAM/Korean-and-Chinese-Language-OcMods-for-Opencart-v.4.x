<?php
// Heading
$_['heading_title']                = '最新活动';

// Text
$_['text_extension']               = '扩充功能';
$_['text_success']                 = '成功: 最新活动设置已更新!';
$_['text_edit']                    = '编辑最新活动';
$_['text_activity_register']       = '<a href="customer_id=%d">%s</a> 已注册一个新帐户。';
$_['text_activity_edit']           = '<a href="customer_id=%d">%s</a> 已更新他们的帐号数据。';
$_['text_activity_password']       = '<a href="customer_id=%d">%s</a> 已更新他们的帐号密码。';
$_['text_activity_reset']          = '<a href="customer_id=%d">%s</a> 已重设他们的密码。';
$_['text_activity_login']          = '<a href="customer_id=%d">%s</a> 已登录。';
$_['text_activity_forgotten']      = '<a href="customer_id=%d">%s</a> 已请求新密码。';
$_['text_activity_address_add']    = '<a href="customer_id=%d">%s</a> 已添加一个新地址。';
$_['text_activity_address_edit']   = '<a href="customer_id=%d">%s</a> 已更新他们的地址。';
$_['text_activity_address_delete'] = '<a href="customer_id=%d">%s</a> 已删除他们的一个地址。';
$_['text_activity_return_account'] = '<a href="customer_id=%d">%s</a> 已送出了一个商品退换。';
$_['text_activity_return_guest']   = '%s 已送出一个商品退换申请。';
$_['text_activity_order_account']  = '<a href="customer_id=%d">%s</a> 已添加一笔 <a href="order_id=%d">新订单</a>。';
$_['text_activity_order_guest']    = '%s 已添加一笔 <a href="order_id=%d">新订单</a>。';
$_['text_activity_affiliate_add']  = '<a href="customer_id=%d">%s</a> 注册了一个推荐帐号。';
$_['text_activity_affiliate_edit'] = '<a href="customer_id=%d">%s</a> 更新了他们的推荐帐号';
$_['text_activity_transaction']    = '<a href="customer_id=%d">%s</a> 从一笔<a href="order_id=%d">新订单</a>收到了推荐佣金。';

// Entry
$_['entry_status']                 = '状态';
$_['entry_sort_order']             = '排序';
$_['entry_width']                  = '宽度';

// Error
$_['error_permission']             = '警告: 您没有权限修改信息总览的最新活动 !';