<?php
namespace Opencart\Admin\Model\Extension\AnoraLanguageKoKr\Language;
class Korean extends \Opencart\System\Engine\Model {
	public function install($language_id): void {

		// Address Format
		// $this->db->query("DELETE FROM `" . DB_PREFIX . "address_format` WHERE `address_format_id` = '2'");
		// $this->db->query("INSERT INTO `" . DB_PREFIX . "address_format` (`address_format_id`, `name`, `address_format`) VALUES (2, '台湾地址格式', '{lastname}{firstname}, {postcode} {zone}{city}{address_1}{address_2}')");


		// Category
		// $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_description` WHERE `language_id` = '" . (int)$language_id . "'");

		// $tc_category = [
		// 	17 => '电脑软件',
		// 	18 => '平板、笔电',
		// 	20 => '台式机',
		// 	24 => '手机、行动助理',
		// 	25 => '周边设备',
		// 	28 => '电脑屏幕',
		// 	29 => '鼠标、轨迹球',
		// 	30 => '打印机',
		// 	31 => '扫描仪',
		// 	32 => '视频设备',
		// 	33 => '数字相机',
		// 	34 => '影音播放器',
		// 	57 => '平板'
		// ];

		// foreach ($query->rows as $category) {
		// 	$cid = (int)$category['category_id'];
		// 	if (array_key_exists($cid, $tc_category)) {
		// 		$this->db->query("UPDATE `" . DB_PREFIX . "category_description` SET `name` = '" . $this->db->escape($tc_category[$cid]) . "', `meta_title` = '" . $this->db->escape($tc_category[$cid]) . "' WHERE `category_id` = '" . (int)$cid . "' AND `language_id` = '" . (int)$language_id . "'");
		// 	}
		// }


		// Currency
		// $this->db->query("UPDATE `" . DB_PREFIX . "currency` SET `title` = '" . $this->db->escape('新台币') . "', `code` = 'TWD', `symbol_left` = '$', `symbol_right` = '', `decimal_place` = '0', `value` = '1' WHERE `currency_id` = '6'");


		// Geo Zone
// 		$this->db->query("DELETE FROM `" . DB_PREFIX . "geo_zone` WHERE `geo_zone_id` = '3'");
// 		$this->db->query("DELETE FROM `" . DB_PREFIX . "geo_zone` WHERE `geo_zone_id` = '4'");
// 		$this->db->query("DELETE FROM `" . DB_PREFIX . "geo_zone` WHERE `geo_zone_id` = '5'");
// 		$this->db->query("INSERT INTO `" . DB_PREFIX . "geo_zone` (`geo_zone_id`, `name`, `description`, `date_modified`, `date_added`) VALUES
// (3, '台湾离岛', '澎湖、金门、马祖地区', '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (4, '台湾本岛', '台湾本岛', '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (5, '台湾地区', '台湾本岛+离岛', '2023-07-01 12:00:00', '2023-07-01 12:00:00')");


		// Length
		$tc_lengthes = [
			1 => '센티미터',
			2 => '밀리미터',
			3 => '인치'
		];

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "length_class_description` WHERE `language_id` = '" . (int)$language_id . "'");

		foreach ($query->rows as $length) {
			$length_class_id = (int)$length['length_class_id'];
			if (array_key_exists($length_class_id, $tc_lengthes)) {
				$this->db->query("UPDATE `" . DB_PREFIX . "length_class_description` SET `title` = '" . $this->db->escape($tc_lengthes[$length_class_id]) . "' WHERE `length_class_id` = '" . (int)$length_class_id . "' AND `language_id` = '" . (int)$language_id . "'");
			}
		}


		// Order Status
		$tc_order_statuses = [
			1 => '미처리',
			2 => '처리 중',
			3 => '출하 완료',
			4 => '미지급금',
			5 => '완료',
			7 => '취소 완료',
			10 => '결제실패',
			15 => '지불 완료',
			16 => '잘못된'
		];

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_status` WHERE `language_id` = '" . (int)$language_id . "'");

		foreach ($query->rows as $order_status) {
			$order_status_id = (int)$order_status['order_status_id'];
			if (array_key_exists($order_status_id, $tc_order_statuses)) {
				$this->db->query("UPDATE `" . DB_PREFIX . "order_status` SET `name` = '" . $this->db->escape($tc_order_statuses[$order_status_id]) . "' WHERE `order_status_id` = '" . (int)$order_status_id . "' AND `language_id` = '" . (int)$language_id . "'");
			}
		}

		// // Return Status
		$tc_return_statuses = [
			1 => '미처리', // Pending
			2 => '교환대기중', // Awaiting Products
			3 => '완료' // Complete
		];

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "return_status` WHERE `language_id` = '" . (int)$language_id . "'");

		foreach ($query->rows as $return_status) {
			$return_status_id = (int)$return_status['return_status_id'];
			if (array_key_exists($return_status_id, $tc_return_statuses)) {
				$this->db->query("UPDATE `" . DB_PREFIX . "return_status` SET `name` = '" . $this->db->escape($tc_return_statuses[$return_status_id]) . "' WHERE `return_status_id` = '" . (int)$return_status_id . "' AND `language_id` = '" . (int)$language_id . "'");
			}
		}


		// Subscription Status
		$tc_subscription_statuses = [
			1 => '대기중', // Pending
			2 => '구독중' , // Active
			3 => '만료됨' , // Expired
			4 => '일시정지됨', // Suspended
			5 => '취소됨', // Cancelled
			6 => '구독실패' , // Failed
			7 => '거부됨' // Denied
		];

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "subscription_status` WHERE `language_id` = '" . (int)$language_id . "'");

		foreach ($query->rows as $subscription_status) {
			$subscription_status_id = (int)$subscription_status['subscription_status_id'];
			if (array_key_exists($subscription_status_id, $tc_subscription_statuses)) {
				$this->db->query("UPDATE `" . DB_PREFIX . "subscription_status` SET `name` = '" . $this->db->escape($tc_subscription_statuses[$subscription_status_id]) . "' WHERE `subscription_status_id` = '" . (int)$subscription_status_id . "' AND `language_id` = '" . (int)$language_id . "'");
			}
		}


		// Stock Status
		$tc_stock_statuses = [
			5 => '매진',
			6 => '품절되어 보충 중',
			7 => '재고 있음',
			8 => '예약 필수'
		];

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "stock_status` WHERE `language_id` = '" . (int)$language_id . "'");

		foreach ($query->rows as $stock_status) {
			$stock_status_id = (int)$stock_status['stock_status_id'];
			if (array_key_exists($stock_status_id, $tc_stock_statuses)) {
				$this->db->query("UPDATE `" . DB_PREFIX . "stock_status` SET `name` = '" . $this->db->escape($tc_stock_statuses[$stock_status_id]) . "' WHERE `stock_status_id` = '" . (int)$stock_status_id . "' AND `language_id` = '" . (int)$language_id . "'");
			}
		}


		// // Tax
		// $this->db->query("DELETE FROM `" . DB_PREFIX . "tax_class` WHERE `tax_class_id` = '1'");
		// $query = $this->db->query("INSERT INTO `" . DB_PREFIX . "tax_class` (`tax_class_id`, `title`, `description`, `date_added`, `date_modified`) VALUES (1, '营业税', '(台湾)营利事业所得税', '2023-07-01 12:00:00', '2023-07-01 12:00:00')");

		// $this->db->query("DELETE FROM `" . DB_PREFIX . "tax_rate` WHERE `tax_rate_id` = '86'");
		// $query = $this->db->query("INSERT INTO `" . DB_PREFIX . "tax_rate` (`tax_rate_id`, `geo_zone_id`, `name`, `rate`, `type`, `date_added`, `date_modified`) VALUES (86, 5, '营业税 (5%)', '5.0000', 'P', '2023-07-01 12:00:00', '2023-07-01 12:00:00')");


		// Weight
		$tc_weightes = [
			1 => '킬로그램',
			2 => '그램',
			5 => '파운드',
			6 => '온스'
		];

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "weight_class_description` WHERE `language_id` = '" . (int)$language_id . "'");

		foreach ($query->rows as $weight) {
			$weight_class_id = (int)$weight['weight_class_id'];
			if (array_key_exists($weight_class_id, $tc_weightes)) {
				$this->db->query("UPDATE `" . DB_PREFIX . "weight_class_description` SET `title` = '" . $this->db->escape($tc_weightes[$weight_class_id]) . "' WHERE `weight_class_id` = '" . (int)$weight_class_id . "' AND `language_id` = '" . (int)$language_id . "'");
			}
		}


		// Zone
// 		$tc_zones = [
// 			3135 => '基隆市',
// 			3136 => '台北市',
// 			3137 => '新北市',
// 			3138 => '桃园市',
// 			3139 => '新竹市',
// 			3140 => '新竹县',
// 			3141 => '苗栗县',
// 			3142 => '台中市',
// 			3143 => '彰化县',
// 			3144 => '南投县',
// 			3145 => '云林县',
// 			3146 => '嘉义市',
// 			3147 => '嘉义县',
// 			3148 => '台南市',
// 			3149 => '高雄市',
// 			3150 => '屏东县',
// 			3151 => '台东县',
// 			3152 => '花莲县',
// 			3153 => '宜兰县',
// 			3154 => '澎湖县',
// 			3155 => '金门县',
// 			3156 => '连江县'
// 		];

// 		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE `country_id` = '206'");

// 		foreach ($query->rows as $zone) {
// 			$zone_id = (int)$zone['zone_id'];
// 			if (array_key_exists($zone_id, $tc_zones)) {
// 				$this->db->query("UPDATE `" . DB_PREFIX . "zone` SET `name` = '" . $this->db->escape($tc_zones[$zone_id]) . "' WHERE `zone_id` = '" . (int)$zone_id . "'");
// 			}
// 		}

// 		$this->db->query("DELETE FROM `" . DB_PREFIX . "zone` WHERE `zone_id` = '3157'");
// 		$this->db->query("DELETE FROM `" . DB_PREFIX . "zone` WHERE `zone_id` = '3158'");
// 		$this->db->query("DELETE FROM `" . DB_PREFIX . "zone` WHERE `zone_id` = '3159'");


// 		// Zone to Geo Zone
// 		$this->db->query("DELETE FROM `" . DB_PREFIX . "zone_to_geo_zone` WHERE `geo_zone_id` = '3'");
// 		$this->db->query("DELETE FROM `" . DB_PREFIX . "zone_to_geo_zone` WHERE `geo_zone_id` = '4'");
// 		$this->db->query("DELETE FROM `" . DB_PREFIX . "zone_to_geo_zone` WHERE `geo_zone_id` = '5'");
// 		$this->db->query("INSERT INTO `" . DB_PREFIX . "zone_to_geo_zone` (`zone_to_geo_zone_id`, `country_id`, `zone_id`, `geo_zone_id`, `date_added`, `date_modified`) VALUES
// (125, 206, 3154, 3, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (126, 206, 3155, 3, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (127, 206, 3156, 3, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (128, 206, 3135, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (129, 206, 3136, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (130, 206, 3137, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (131, 206, 3138, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (132, 206, 3139, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (133, 206, 3140, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (134, 206, 3141, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (135, 206, 3142, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (136, 206, 3143, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (137, 206, 3144, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (138, 206, 3145, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (139, 206, 3146, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (140, 206, 3147, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (141, 206, 3148, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (142, 206, 3149, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (143, 206, 3150, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (144, 206, 3151, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (145, 206, 3152, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (146, 206, 3153, 4, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (147, 206, 3135, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (148, 206, 3136, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (149, 206, 3137, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (150, 206, 3138, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (151, 206, 3139, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (152, 206, 3140, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (153, 206, 3141, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (154, 206, 3142, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (155, 206, 3143, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (156, 206, 3144, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (157, 206, 3145, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (158, 206, 3146, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (159, 206, 3147, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (160, 206, 3148, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (161, 206, 3149, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (162, 206, 3150, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (163, 206, 3151, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (164, 206, 3152, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (165, 206, 3153, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (166, 206, 3154, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (167, 206, 3155, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00'),
// (168, 206, 3156, 5, '2023-07-01 12:00:00', '2023-07-01 12:00:00')");


// 		$this->db->query("UPDATE `" . DB_PREFIX . "country` SET `name` = '台湾', `address_format_id` = '2' WHERE `country_id` = '206'");

// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '80' WHERE `code` = 'shipping_flat' AND `key` = 'shipping_flat_cost'");


// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '206' WHERE `code` = 'config' AND `key` = 'config_country_id'");
// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '3136' WHERE `code` = 'config' AND `key` = 'config_zone_id'");
// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = 'Asia/Taipei' WHERE `code` = 'config' AND `key` = 'config_timezone'");
// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = 'ko-KR' WHERE `code` = 'config' AND `key` = 'config_language'");
// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = 'ko-KR' WHERE `code` = 'config' AND `key` = 'config_language_admin'");

// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = 'TWD' WHERE `code` = 'config' AND `key` = 'config_currency'");
// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '0' WHERE `code` = 'config' AND `key` = 'config_currency_auto'");

// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '12' WHERE `code` = 'config' AND `key` = 'config_pagination'");
// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '20' WHERE `code` = 'config' AND `key` = 'config_pagination_admin'");

// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '' WHERE `code` = 'config' AND `key` = 'config_tax_default'");
// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '' WHERE `code` = 'config' AND `key` = 'config_tax_customer'");

// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '[\"2\"]' WHERE `code` = 'config' AND `key` = 'config_processing_status'");
// 		$this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '[\"3\",\"5\",\"15\"]' WHERE `code` = 'config' AND `key` = 'config_complete_status'");
	}

	public function uninstall(): void {
		//$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "product_korean`");
	}

}
