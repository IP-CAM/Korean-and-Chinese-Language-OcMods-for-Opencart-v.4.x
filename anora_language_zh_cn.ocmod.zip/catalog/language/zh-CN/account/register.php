<?php
// Heading 
$_['heading_title']        = '注册帐号';

// Text
$_['text_account']         = '我的帐号';
$_['text_register']        = '注册帐号';
$_['text_account_already'] = '如果您是新会员，请填写下面的表单进行注册，如果您已经是本站的会员，请您直接<a href="%s">登录</a>。';
$_['text_your_details']    = '个人数据';
$_['text_newsletter']      = '订阅电子报';
$_['text_your_password']   = '帐号密码';
$_['text_agree']           = '我已经阅读并同意 <a href="%s" class="agree"><b>%s</b></a>';

// Entry
$_['entry_customer_group'] = '会员等级';
$_['entry_firstname']      = '名字';
$_['entry_lastname']       = '姓氏';
$_['entry_email']          = 'Email 信箱';
$_['entry_telephone']      = '联系电话';
$_['entry_newsletter']     = '订阅电子报';
$_['entry_password']       = '密码';
$_['entry_confirm']        = '确认密码';

// Error
$_['error_token']          = '警告: 密钥已失效!';
$_['error_exists']         = '警告: 该 Email 信箱已被注册，请更换另一个 Email 信箱！';
$_['error_customer_group'] = '会员等级不正确!';
$_['error_firstname']      = '名字必须是 1 到 32 字！';
$_['error_lastname']       = '姓氏必须是 1 到 32 字！';
$_['error_email']          = '无效的 Email 信箱！';
$_['error_telephone']      = '电话号码必须是 3 到 32 个字！';
$_['error_custom_field']   = '%s 必须填写！';
$_['error_regex']          = '%s 不正确!';
$_['error_password']       = '密码必须在 4 到 20 个字！';
$_['error_agree']          = '警告:您尚未同意会员条款 %s！';