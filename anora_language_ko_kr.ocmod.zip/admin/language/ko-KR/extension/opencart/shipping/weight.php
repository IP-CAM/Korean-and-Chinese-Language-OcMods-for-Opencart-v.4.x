<?php
// 제목
$_['heading_title'] = '무게 기준';

//텍스트
$_['text_extension'] = '확장 기능';
$_['text_success'] = '성공: 중량별 지불 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '무게별 청구 편집 모듈';

// 항목
$_['entry_rate'] = '운임 설정';
$_['entry_tax_class'] = '세금 분류';
$_['entry_geo_zone'] = '해당지역';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 돕다
$_['help_rate'] = '예: 5:80, 10:120 무게: 양, 무게: 양 등. ';

// 오류
$_['error_permission'] = '경고: 중량별 지불 모듈을 편집할 수 있는 권한이 없습니다! ';