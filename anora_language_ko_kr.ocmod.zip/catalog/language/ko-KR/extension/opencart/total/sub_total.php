<?php
//텍스트
$_['text_sub_total'] = '총 항목';