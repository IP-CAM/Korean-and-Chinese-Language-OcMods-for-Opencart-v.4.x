<?php
// 제목
$_['heading_title'] = '세율 관리';

//텍스트
$_['text_success'] = '성공: 세율 설정이 업데이트되었습니다! ';
$_['text_list'] = '세율 목록';
$_['text_add'] = '세율 추가';
$_['text_edit'] = '세율 편집';
$_['text_percent'] = '% 숫자';
$_['text_amount'] = '고정 금액';

//열
$_['column_name'] = '세율명';
$_['column_rate'] = '세율';
$_['column_type'] = '범주';
$_['column_geo_zone'] = '지역';
$_['column_date_added'] = '날짜 추가';
$_['column_date_modified'] = '수정된 날짜';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '세율 이름';
$_['entry_rate'] = '세율';
$_['entry_type'] = '범주';
$_['entry_customer_group'] = '회원등급';
$_['entry_geo_zone'] = '지역';

// 오류
$_['error_permission'] = '경고: 세율 설정을 변경할 권한이 없습니다! ';
$_['error_tax_rule'] = '경고: %s 세금 범주가 이미 사용 중이므로 이 세율을 삭제할 수 없습니다! ';
$_['error_name'] = '세율 이름은 3~32자여야 합니다! ';
$_['error_rate'] = '세율 필드를 반드시 입력해야 합니다! ';