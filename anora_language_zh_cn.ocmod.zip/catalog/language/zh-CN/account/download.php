<?php
// Heading 
$_['heading_title']     = '我的下载';

// Text
$_['text_account']      = '我的帐号';
$_['text_downloads']    = '下载商品';
$_['text_no_results']   = '您没有购买过任何下载商品！';

// Column
$_['column_order_id']   = '订单编号';
$_['column_name']       = '文件名称';
$_['column_size']       = '文件大小';
$_['column_date_added'] = '添加日期';

// Error
$_['error_not_found']    = '错误: 找不到文件 %s !';
$_['error_headers_sent'] = '错误: Headers already sent out!';
