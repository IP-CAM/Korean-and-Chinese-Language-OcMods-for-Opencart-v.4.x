<?php
// 제목
$_['heading_title'] = '최신 제품';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 최신 제품 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '최신 제품 모듈 편집';
$_['text_horizontal'] = '가로';
$_['text_vertical'] = '세로형';

// 항목
$_['entry_name'] = '모듈 이름';
$_['entry_axis'] = '배열 방향';
$_['entry_limit'] = '아이템 수량 제한';
$_['entry_width'] = '그림 너비';
$_['entry_height'] = '사진 높이';
$_['entry_status'] = '상태';

// 오류
$_['error_permission'] = '경고: 최신 제품 모듈을 변경할 권한이 없습니다! ';
$_['error_name'] = '모듈 이름은 3~64자여야 합니다!';
$_['error_width'] = '그림 너비를 입력해야 합니다!';
$_['error_height'] = '사진 높이를 입력해야 합니다!';