<?php
// Heading
$_['heading_title']    = '한국인';

// Text
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 한국어가 업데이트되었습니다!';
$_['text_edit'] = '한국어 편집';

// 항목
$_['entry_status'] = '상태';

// 오류
$_['error_permission'] = '경고: 한국어 편집 권한이 없습니다!';
