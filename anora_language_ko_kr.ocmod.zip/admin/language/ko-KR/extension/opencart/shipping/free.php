<?php
// 제목
$_['heading_title'] = '무료 배송';

//텍스트
$_['text_extension'] = '확장 기능';
$_['text_success'] = '성공: 무료 배송 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '무료 배송 모듈 편집';

// 항목
$_['entry_total'] = '최소 주문금액';
$_['entry_geo_zone'] = '해당지역';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 돕다
$_['help_total'] = '무료 배송 자격을 얻기 위한 최소 주문 금액입니다. ';

// 오류
$_['error_permission'] = '경고: 무료 배송 모듈을 수정할 권한이 없습니다! ';