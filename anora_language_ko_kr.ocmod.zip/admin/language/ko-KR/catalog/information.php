<?php
// 제목
$_['heading_title'] = '페이지 관리';

//텍스트
$_['text_success'] = '성공: 상점 정보 페이지 설정이 업데이트되었습니다! ';
$_['text_list'] = '페이지 목록';
$_['text_add'] = '정보 페이지 추가';
$_['text_edit'] = '정보 페이지 편집';
$_['text_default'] = '기본값';
$_['text_keyword'] = '공백을 사용하지 말고, 공백을 대체하려면 -를 사용하고, 정적 URL(SEO URL)이 반복되지 않도록 하세요. ';

//열
$_['column_title'] = '페이지 제목';
$_['column_sort_order'] = '정렬';
$_['column_action'] = '관리';

// 항목
$_['entry_title'] = '페이지 제목';
$_['entry_description'] = '페이지 내용';
$_['entry_meta_title'] = '메타태그 제목';
$_['entry_meta_keyword'] = '메타태그 키워드';
$_['entry_meta_description'] = '메타태그 설명';
$_['entry_store'] = '스토어';
$_['entry_keyword'] = '정적 URL';
$_['entry_bottom'] = '페이지 하단';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬 표시';
$_['entry_layout'] = '템플릿 지정';

// 돕다
$_['help_bottom'] = '페이지 하단에 표시';

// 오류
$_['error_warning'] = '경고: 데이터가 올바르게 입력되지 않았습니다! ';
$_['error_permission'] = '경고: 상점 정보 페이지를 편집할 수 있는 권한이 없습니다! ';
$_['error_title'] = '페이지 제목은 1~64 단어여야 합니다! ';
$_['error_description'] = '페이지 내용 길이는 3단어 이상이어야 합니다! ';
$_['error_meta_title'] = '메타 제목은 1~255 단어여야 합니다! ';
$_['error_keyword'] = '고정 URL(SEO URL)은 1~64자여야 합니다!';
$_['error_keyword_exists'] = '정적 URL(SEO URL)은 반복되어서는 안됩니다!';
$_['error_keyword_character'] = '정적 URL(SEO URL)은 a-z, 0-9, - 및 _와 같은 문자만 사용할 수 있습니다!';
$_['error_account'] = '경고: 이 페이지는 현재 기본 스토어 멤버십 약관이므로 삭제할 수 없습니다! ';
$_['error_checkout'] = '경고: 이 페이지는 현재 기본 스토어 체크아웃 약관이므로 삭제할 수 없습니다! ';
$_['error_affiliate'] = '경고: 이 페이지는 현재 기본 상점 추천 용어이므로 삭제할 수 없습니다! ';
$_['error_return'] = '경고: 이 페이지는 현재 기본 스토어 반품 정책이므로 삭제할 수 없습니다! ';
$_['error_store'] = '경고: %s 상점이 현재 사용 중이므로 이 페이지를 삭제할 수 없습니다! ';