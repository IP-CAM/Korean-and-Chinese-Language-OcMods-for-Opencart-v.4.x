<?php
// 제목
$_['heading_title'] = 'HTML 콘텐츠';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: HTML 콘텐츠 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = 'HTML 콘텐츠 모듈 편집';

// 항목
$_['entry_name'] = '모듈 이름';
$_['entry_title'] = '제목';
$_['entry_description'] = '콘텐츠';
$_['entry_status'] = '상태';

// 오류
$_['error_permission'] = '경고: HTML 콘텐츠 모듈을 수정할 권한이 없습니다! ';
$_['error_name'] = '모듈 이름은 3~64자여야 합니다!';