<?php
// 제목
$_['heading_title'] = '제품 카테고리';

//텍스트
$_['text_success'] = '성공: 제품 카테고리 설정이 업데이트되었습니다! ';
$_['text_list'] = '제품 카테고리 목록';
$_['text_add'] = '제품 카테고리 추가';
$_['text_edit'] = '제품 카테고리 편집';
$_['text_default'] = '기본값';
$_['text_keyword'] = '공백을 사용하지 말고, 공백을 대체하려면 -를 사용하고, 정적 URL(SEO URL)이 반복되지 않도록 하세요. ';

//열
$_['column_name'] = '범주 이름';
$_['column_sort_order'] = '카테고리 정렬';
$_['column_action'] = '카테고리 편집';
	
// 항목
$_['entry_name'] = '범주 이름';
$_['entry_description'] = '범주 설명';
$_['entry_meta_title'] = '메타태그 제목';
$_['entry_meta_keyword'] = '메타태그 키워드';
$_['entry_meta_description'] = '메타태그 설명';
$_['entry_store'] = '해당 매장';
$_['entry_keyword'] = '고정 URL(SEO URL)';
$_['entry_parent'] = '상위 분류';
$_['entry_filter'] = '제품 특성';
$_['entry_image'] = '분류 이미지';
$_['entry_top'] = '탐색 표시줄 표시';
$_['entry_column'] = '열 표시';
$_['entry_sort_order'] = '정렬 표시';
$_['entry_status'] = '분류상태';
$_['entry_layout'] = '템플릿 지정(레이아웃)';

// 돕다
$_['help_parent'] = '(자동 검색)';
$_['help_filter'] = '(자동 검색)';
$_['help_top'] = '페이지 상단의 탐색 표시줄에 표시되며 최상위 카테고리에만 적용됩니다. ';
$_['help_column'] = '페이지 상단의 메인 카테고리 아래 하위 카테고리를 표시할 때 정렬할 행 수입니다. 상위 카테고리에만 적용됩니다. ';

// 오류
$_['error_warning'] = '경고: 관련 필드 데이터가 입력되지 않았습니다! ';
$_['error_permission'] = '경고: 제품 카테고리를 변경할 권한이 없습니다! ';
$_['error_name'] = '범주 이름은 1~255자여야 합니다! ';
$_['error_meta_title'] = '메타 제목은 1~255 단어여야 합니다! ';
$_['error_parent'] = '선택한 상위 카테고리는 이 카테고리의 하위 카테고리가 될 수 없습니다!';
$_['error_keyword'] = '고정 URL(SEO URL)은 1~64자여야 합니다!';
$_['error_keyword_exists'] = '정적 URL(SEO URL)은 반복되어서는 안됩니다!';
$_['error_keyword_character'] = '정적 URL(SEO URL)은 a-z, 0-9, - 및 _와 같은 문자만 사용할 수 있습니다!';