<?php
// Heading
$_['heading_title']    = '网站导览';
 
// Text
$_['text_special']     = '特价商品';
$_['text_account']     = '我的帐号';
$_['text_edit']        = '帐号信息';
$_['text_password']    = '更新密码';
$_['text_address']     = '常用地址';
$_['text_history']     = '我的订单';
$_['text_download']    = '我的下载';
$_['text_cart']        = '购物车';
$_['text_checkout']    = '结帐';
$_['text_search']      = '搜索';
$_['text_information'] = '商店信息';
$_['text_contact']     = '联系我们';