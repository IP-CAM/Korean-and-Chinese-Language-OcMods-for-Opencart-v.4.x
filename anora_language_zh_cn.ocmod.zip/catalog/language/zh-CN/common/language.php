<?php
// Text
$_['text_language'] = '语系';