<?php
// Heading
$_['heading_title']        = '币别管理';

// Text
$_['text_success']         = '成功: 币别管理设置已更新！';
$_['text_list']            = '币别清单';
$_['text_add']             = '添加币别';
$_['text_edit']            = '编辑币别';
$_['text_iso']             = '您可以在 http://www.xe.com/iso4217.php 找到完整的 ISO 货币代码及设置。';

// Column
$_['column_title']         = '币别名称';
$_['column_code']          = '代码';
$_['column_value']         = '汇率';
$_['column_status']        = 'Status';
$_['column_date_modified'] = '最后更新';
$_['column_action']        = '管理';

// Entry
$_['entry_title']          = '币别名称';
$_['entry_code']           = '代码';
$_['entry_value']          = '汇率';
$_['entry_symbol_left']    = '左侧符号';
$_['entry_symbol_right']   = '右侧符号';
$_['entry_decimal_place']  = '小数字数';
$_['entry_status']         = '状态';

// Help
$_['help_code']            = '如果这是默认币别请勿修改，</br>它必须是有效的 ISO 代码。';
$_['help_value']           = '如果这是您的默认币别，请将它设置为 1.00000。';

// Error
$_['error_permission']     = '警告: 您没有权限更改币别设置';
$_['error_extension']      = '警告: 币别模块找不到!';
$_['error_title']          = '币别名称必须是 3 到 32 个字！';
$_['error_code']           = '币别代码必须是 3 个字！';
$_['error_default']        = '警告: 该币别不能删除，因为它是商店的默认币别！';
$_['error_store']          = '警告: 该币别不能删除，因为已有 %s 个商店使用！';
$_['error_order']          = '警告: 该币别不能删除，因为已有 %s 笔订单使用！';