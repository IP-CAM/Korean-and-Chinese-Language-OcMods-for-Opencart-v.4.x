<?php
// Heading
$_['heading_title']    = '广告图片';

// Text
$_['text_extension']   = '扩展模块';
$_['text_success']     = '成功: 广告图片模块设置已更新！';
$_['text_edit']        = '编辑广告图片模块';
$_['text_slide']       = '滑进滑出';
$_['text_fade']        = '淡入淡出';

// Entry
$_['entry_name']       = '广告图片名称';
$_['entry_banner']     = '广告图片';
$_['entry_effect']     = '效果';
$_['entry_items']      = '每组 slide 图片数';
$_['entry_controls']   = '控制';
$_['entry_indicators'] = '指示器';
$_['entry_interval']   = '间格时间(ms)';
$_['entry_width']      = '宽度';
$_['entry_height']     = '高度';
$_['entry_status']     = '状态:';

// Help
$_['help_items']       = '每一组 slide 的图片数';

// Error
$_['error_permission'] = '警告: 您没有权限修改广告图片模块！';
$_['error_name']       = '广告图片名称必须在 3 到 64 个字之间 !';
$_['error_interval']   = '间隔值必须输入!';
$_['error_width']      = '宽度必须输入 !';
$_['error_height']     = '高度必须输入 !';