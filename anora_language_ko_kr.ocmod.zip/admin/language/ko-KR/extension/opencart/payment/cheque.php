<?php
// 제목
$_['heading_title'] = '결제 확인';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 결제 모듈 확인이 업데이트되었습니다!';
$_['text_edit'] = '수표 결제 수정';

// 항목
$_['entry_payable'] = '수취인';
$_['entry_order_status'] = '기본 주문 상태';
$_['entry_geo_zone'] = '해당지역';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 수표 결제를 편집할 수 있는 권한이 없습니다!';
$_['error_payable'] = '수취인을 입력해야 합니다!';