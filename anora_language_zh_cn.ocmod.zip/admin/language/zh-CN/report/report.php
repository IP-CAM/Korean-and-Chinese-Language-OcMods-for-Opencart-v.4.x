<?php
// Heading
$_['heading_title'] = '统计报表';

// Text
$_['text_success']  = '成功: 统计报表设置已更新!';
$_['text_type']     = '选择统计报表种类';
$_['text_filter']   = '条件筛选';