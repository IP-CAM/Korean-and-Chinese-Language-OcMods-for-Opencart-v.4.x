<?php
// Heading
$_['heading_title']      = '广告图片';

// Text
$_['text_success']       = '成功: 广告图片设置已更新！';
$_['text_list']          = '广告图片清单';
$_['text_add']           = '添加广告图片';
$_['text_edit']          = '编辑广告图片';
$_['text_default']       = '默认';

// Column
$_['column_name']        = '广告图片名称';
$_['column_status']      = '状态';
$_['column_action']      = '管理';

// Entry
$_['entry_name']         = '广告图片名称';
$_['entry_title']        = '标题';
$_['entry_link']         = '链接';
$_['entry_image']        = '图片';
$_['entry_status']       = '状态';
$_['entry_sort_order']   = '显示排序';

// Error
$_['error_permission']   = '警告: 您没有权限编辑广告图片！';
$_['error_name']         = '广告图片名称必须是 3 到 64 个字！';
$_['error_title']        = '广告图片标题必须是 2 到 64 个字！';