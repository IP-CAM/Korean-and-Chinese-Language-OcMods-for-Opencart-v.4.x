<?php
// 제목
$_['heading_title'] = '사기방지 IP';

// 텍스트
$_['text_extension'] = '전시 확장';
$_['text_success'] = '성공: 사기 방지 IP 模块设置已更新!';
$_['text_edit'] = '사기방지 IP 편집';
$_['text_ip_add'] = 'IP 주소 저장';
$_['text_ip_list'] = '사기 IP 주소 목록';

// 열
$_['column_ip'] = 'IP';
$_['column_total'] = '총 계정';
$_['column_date_added'] = '날짜가 지난 날짜';
$_['column_action'] = '관리';

// 항목
$_['entry_ip'] = 'IP';
$_['entry_status'] = '완료';
$_['entry_order_status'] = '주문 완료';

// 돕다
$_['help_order_status'] = '계정에 금지된 IP가 있는 고객에게는 이 주문 상태가 할당되며 자동으로 완료 상태에 도달하는 것이 허용되지 않습니다.';

// 오류
$_['error_permission'] = '경고: Anti-Fraud IP 수정 권한이 없습니다!';
$_['error_required'] = 'IP 주소가 필요합니다!';
$_['error_invalid'] = 'IP 주소가 잘못되었습니다!';