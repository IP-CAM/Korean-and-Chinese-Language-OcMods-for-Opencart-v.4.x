<?php
// 제목
$_['heading_title'] = '특별 제안';