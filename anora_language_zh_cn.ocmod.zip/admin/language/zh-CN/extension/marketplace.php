<?php
// Heading
$_['heading_title']    = '扩展模块市集(Marketplace)';

// Text
$_['text_success']     = '成功: 扩展模块市集已更新!';
$_['text_list']        = '扩展模块清单';

// Column
$_['column_name']      = '扩展模块名称';
$_['column_status']    = '状态';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您没有权限使用扩展模块市集!';
$_['error_extension']  = '警告: 扩展模块不存在!';