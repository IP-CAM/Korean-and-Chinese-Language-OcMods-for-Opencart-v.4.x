<?php
// 제목
$_['heading_title'] = '추천 제품';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 주요 제품 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '추천 제품 모듈 편집';
$_['text_horizontal'] = '가로';
$_['text_vertical'] = '세로형';

// 항목
$_['entry_name'] = '모듈 이름';
$_['entry_product'] = '특산품';
$_['entry_axis'] = '배치';
$_['entry_width'] = '그림 너비';
$_['entry_height'] = '사진 높이';
$_['entry_status'] = '상태';

// 돕다
$_['help_product'] = '(자동완성)';

// 오류
$_['error_permission'] = '경고: 추천 제품 모듈을 수정할 권한이 없습니다! ';
$_['error_name'] = '모듈 이름은 3~64자 사이여야 합니다!';
$_['error_width'] = '그림 너비를 입력해야 합니다!';
$_['error_height'] = '사진 높이를 입력해야 합니다!';