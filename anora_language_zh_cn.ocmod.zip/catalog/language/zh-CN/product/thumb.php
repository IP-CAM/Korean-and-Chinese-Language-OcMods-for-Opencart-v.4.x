<?php
// Text
$_['text_price'] = '售价:';
$_['text_tax']   = '未税:';