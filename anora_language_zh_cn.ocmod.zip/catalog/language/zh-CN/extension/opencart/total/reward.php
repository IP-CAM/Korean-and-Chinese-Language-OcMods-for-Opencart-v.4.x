<?php
// Heading
$_['heading_title'] = '使用红利点数 (%s 点)';

// Text
$_['text_reward']   = '红利点数 (%s)';
$_['text_order_id'] = '订单编号: #%s';
$_['text_success']  = '成功: 红利点数已套用!';
$_['text_remove']   = '成功: 红利点数已移除!';

// Entry
$_['entry_reward']  = '红利点数 (最多可使用 %s 点)';

// Error
$_['error_reward']  = '警告: 请输入您要支付的红利点数!';
$_['error_points']  = '警告: 您没有 %s 点的红利点数!';
$_['error_maximum'] = '警告: 最多能使用的红利点数是 %s 点!';
$_['error_status']  = '警告: 商店的红利点数功能未启用!';