<?php
// Heading
$_['heading_title'] = '내 계정';

//텍스트
$_['text_account'] = '회원센터';
$_['text_my_account'] = '내 계정';
$_['text_my_orders'] = '내 주문';
$_['text_my_affiliate'] = '추천 계정';
$_['text_my_newsletter'] = '내 구독';
$_['text_edit'] = '계정 편집';
$_['text_password'] = '비밀번호 변경';
$_['text_address'] = '공통주소';
$_['text_paid_method'] = '공통 결제 데이터';
$_['text_wishlist'] = '추적 목록';
$_['text_order'] = '내 주문';
$_['text_subscription'] = '내 구독';
$_['text_download'] = '내 다운로드';
$_['text_reward'] = '보너스 포인트';
$_['text_return'] = '상품반품';
$_['text_transaction'] = '쇼핑 크레딧';
$_['text_newsletter'] = '전자뉴스레터';
$_['text_transactions'] = '쇼핑 크레딧';
$_['text_affiliate_add'] = '추천 계정 신청';
$_['text_affiliate_edit'] = '에디터 추천 계정';
$_['text_tracking'] = '맞춤 추천 추적 코드';