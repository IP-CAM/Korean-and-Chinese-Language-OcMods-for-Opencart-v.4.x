<?php
// Text
$_['text_sub_total'] = '商品合计';