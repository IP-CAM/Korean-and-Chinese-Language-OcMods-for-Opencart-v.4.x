<?php
// 제목
$_['heading_title'] = '판매 분석';

//텍스트
$_['text_extension'] = '확장 기능';
$_['text_success'] = '성공: 정보개요 매출분석 차트 설정이 업데이트 되었습니다!';
$_['text_edit'] = '정보 개요 매출 분석 차트 편집';
$_['text_order'] = '주문수';
$_['text_customer'] = '고객 수';
$_['text_day'] = '오늘';
$_['text_week'] = '이번 주';
$_['text_month'] = '이번 달';
$_['text_year'] = '올해';

// 항목
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';
$_['entry_width'] = '너비';

// 오류
$_['error_permission'] = '경고: 정보 개요 판매 분석 차트를 수정할 수 있는 권한이 없습니다!';