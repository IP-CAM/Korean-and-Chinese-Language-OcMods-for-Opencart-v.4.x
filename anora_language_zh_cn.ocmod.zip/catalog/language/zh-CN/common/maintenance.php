<?php
// Heading
$_['heading_title']    = '网站维护';

// Text
$_['text_maintenance'] = '网站维护中';
$_['text_message']     = '<h1 style="text-align:center;">现在我们正在进行网站维护，<br/>请稍后再浏览本站。</h1>';
