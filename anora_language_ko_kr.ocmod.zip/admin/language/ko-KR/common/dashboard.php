<?php
// 제목
$_['heading_title'] = '정보 개요';