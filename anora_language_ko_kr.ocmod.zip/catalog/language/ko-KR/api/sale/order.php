<?php
// Text
$_['text_success'] ='성공: 주문이 업데이트되었습니다';
// Error
$_['error_order'] ='경고: 주문을 찾을 수 없습니다!';
$_['error_customer'] ='경고: 회원의 명세 데이터는 반드시 설정해야 합니다!';
$_['error_payment_address'] ='경고: 청구 주소를 입력해야 합니다!';
$_['error_payment_method'] ='경고: 결제 방법은 반드시 입력해야 합니다!';
$_['error_no_payment'] ='경고: 옵션 결제 옵션이 없습니다!';
$_['error_shipping_address'] ='경고: 배송 주소를 입력해야 합니다!';
$_['error_shipping_method'] ='경고: 배송 방법은 반드시 입력해야 합니다!';
$_['error_no_shipping'] ='경고: 옵션 배송 옵션이 없습니다!';
$_['error_stock'] ='경고: 상품에 * * * 표시는 수량이 부족하거나 재고가 없음을 나타냅니다!';
$_['error_minimum'] ='경고:%s 최소 구매 수량은%s건!';
$_['error_product'] ='경고: 상품이 있어야 합니다!';
$_['error_comment'] ='경고: 메모가 있어야 합니다!';