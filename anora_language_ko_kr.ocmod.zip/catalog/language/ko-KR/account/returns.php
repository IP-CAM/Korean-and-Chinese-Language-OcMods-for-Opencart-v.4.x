<?php
// 제목
$_['heading_title'] = '제품 반품';

//텍스트
$_['text_account'] = '내 계정';
$_['text_return'] = '제품 반품 데이터';
$_['text_return_detail'] = '제품 반품 내역';
$_['text_description'] = '<p>RMA 번호를 받으려면 아래 양식을 작성하십시오. </p>';
$_['text_order'] = '주문 데이터';
$_['text_product'] = '제품 데이터';
$_['text_reason'] = '반품, 교환 사유';
$_['text_message'] = '<p>귀하의 제품 반품 요청이 관련 부서로 전달되어 처리가 완료되었습니다.</p><p> 제품 반품 진행 상황은 이메일을 통해 알려드리겠습니다. </p>';
$_['text_return_id'] = '반품번호';
$_['text_orders_id'] = '주문번호';
$_['text_date_ordered'] = '주문 날짜';
$_['text_status'] = '상태';
$_['text_date_add'] = '날짜 추가';
$_['text_comment'] = '반품 및 교환 유의사항';
$_['text_history'] = '반환 기록';
$_['text_no_results'] = '현재 반품, 교환 기록이 없습니다.';
$_['text_agree'] = '나는 <a href="%s" class="agree"><b>%s</b></a> 약관을 읽었으며 이에 동의합니다. ';

//열
$_['column_return_id'] = '반품번호';
$_['column_order_id'] = '주문번호';
$_['column_status'] = '상태';
$_['column_date_add'] = '날짜 추가';
$_['column_customer'] = '회원';
$_['column_product'] = '제품명';
$_['column_model'] = '모델';
$_['column_Quantity'] = '수량';
$_['column_price'] = '판매가';
$_['column_opened'] = '열림';
$_['column_comment'] = '비고';
$_['column_reason'] = '이유';
$_['column_action'] = '관리';

// 항목
$_['entry_order_id'] = '주문번호';
$_['entry_date_ordered'] = '주문 날짜';
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_email'] = '이메일 편지함';
$_['entry_telephone'] = '전화';
$_['entry_product'] = '제품명';
$_['entry_model'] = '아이템 모델';
$_['entry_Quantity'] = '수량';
$_['entry_reason'] = '반품, 교환 사유';
$_['entry_opened'] = '열림';
$_['entry_fault_detail'] = '제품 결함 또는 기타';

// 오류
$_['text_error'] = '찾으시는 반품기록을 찾을 수 없습니다. ';
$_['error_token'] = '경고: 키가 만료되었습니다!';
$_['error_order_id'] = '주문번호를 입력해주세요. ';
$_['error_firstname'] = '이름은 1~32자여야 합니다.';
$_['error_lastname'] = '성은 1~32자여야 합니다.';
$_['error_email'] = '잘못된 이메일';
$_['error_telephone'] = '전화번호는 3~32자여야 합니다';
$_['error_product'] = '제품 이름은 3~255자여야 합니다.';
$_['error_model'] = '제품 모델은 3~64자여야 합니다.';
$_['error_reason'] = '반품 사유를 선택해주세요';
$_['error_agree'] = '경고: %s 약관에 동의해야 합니다! ';