<?php
// Heading
$_['heading_title']      = '地区管理';

// Text
$_['text_success']       = '成功: 地区设置已更新！';
$_['text_list']          = '地区清单';
$_['text_add']           = '添加地区';
$_['text_edit']          = '编辑地区';
$_['text_geo_zone']      = '地区(Geo Zones)';

// Column
$_['column_name']        = '地区名称';
$_['column_description'] = '描述';
$_['column_action']      = '管理';

// Entry
$_['entry_name']         = '地区名称';
$_['entry_description']  = '说明';
$_['entry_country']      = '国家';
$_['entry_zone']         = '县市';

// Error
$_['error_permission']   = '警告: 您没有权限编辑地区管理！';
$_['error_name']         = '地区名称必须在 3 到 32 个字！';
$_['error_description']  = '地区说明必须在 3 到 255 个字！';
$_['error_tax_rate']     = '警告: 该地区不能被删除，因为它已设置了一个或多个税别！';