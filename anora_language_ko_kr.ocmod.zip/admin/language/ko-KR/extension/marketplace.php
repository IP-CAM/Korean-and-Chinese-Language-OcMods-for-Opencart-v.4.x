<?php
// 제목
$_['heading_title'] = '확장 모듈 마켓플레이스(Marketplace)';

//텍스트
$_['text_success'] = '성공: 확장 모듈 마켓이 업데이트되었습니다!';
$_['text_list'] = '확장 모듈 목록';

//열
$_['column_name'] = '확장 모듈 이름';
$_['column_status'] = '상태';
$_['column_action'] = '액션';

// 오류
$_['error_permission'] = '경고: 확장 마켓을 사용할 수 있는 권한이 없습니다!';
$_['error_extension'] = '경고: 확장 모듈이 존재하지 않습니다!';