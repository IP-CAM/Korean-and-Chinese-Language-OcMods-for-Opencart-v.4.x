<?php
// Heading
$_['heading_title'] = '按重量计费';

// Text
$_['text_weight']   = '重量:';