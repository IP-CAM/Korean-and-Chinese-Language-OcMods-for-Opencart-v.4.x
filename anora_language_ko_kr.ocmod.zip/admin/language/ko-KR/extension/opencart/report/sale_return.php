<?php
// 제목
$_['heading_title'] = '제품 반품 보고서';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_edit'] = '제품 반품 보고서 편집';
$_['text_success'] = '성공: 상품 반품 및 교환 보고서 설정이 업데이트되었습니다!';
$_['text_filter'] = '필터';
$_['text_year'] = '연도별 통계';
$_['text_month'] = '월별 통계';
$_['text_week'] = '주별 통계';
$_['text_day'] = '요일별 통계';
$_['text_all_status'] = '모든 상태';

//열
$_['column_date_start'] = '시작일';
$_['column_date_end'] = '종료일';
$_['column_returns'] = '반품 및 교환 횟수';

// 항목
$_['entry_date_start'] = '시작일';
$_['entry_date_end'] = '종료일';
$_['entry_group'] = '그룹 표시';
$_['entry_return_status'] = '반품 상태';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 귀하는 제품 반품 보고서를 편집할 권한이 없습니다!';