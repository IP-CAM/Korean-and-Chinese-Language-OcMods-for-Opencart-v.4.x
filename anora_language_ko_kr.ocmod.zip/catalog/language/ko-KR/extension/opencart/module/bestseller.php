<?php
// 제목
$_['heading_title'] = '인기 판매 품목';