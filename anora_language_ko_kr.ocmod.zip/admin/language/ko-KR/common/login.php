<?php
// 제목
$_['heading_title'] = '백엔드 관리 시스템';

//텍스트
$_['text_heading'] = '백엔드 관리 로그인! ';
$_['text_login'] = '관리 계정과 비밀번호를 입력해주세요. ';
$_['text_forgotten'] = '비밀번호를 잊어버렸습니다';

// 항목
$_['entry_username'] = '계정 관리';
$_['entry_password'] = '관리 비밀번호';

// 버튼
$_['button_login'] = '로그인';

// 오류
$_['error_login'] = '올바른 관리 계정과 비밀번호를 입력해주세요! ';
$_['error_token'] = '시간이 지남에 따라 계정이 로그아웃되었습니다. 다시 로그인하십시오! ';