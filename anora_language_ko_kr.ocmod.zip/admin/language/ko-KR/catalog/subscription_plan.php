<?php
// 제목
$_['heading_title'] = '구독 계획';

//텍스트
$_['text_success'] = '성공: 구독 계획 데이터가 업데이트되었습니다!';
$_['text_list'] = '구독 계획 목록';
$_['text_add'] = '구독 요금제 추가';
$_['text_edit'] = '구독 계획 수정';
$_['text_subscription'] = '구독 계획';
$_['text_trial'] = '시험 계획';
$_['text_day'] = '일';
$_['text_week'] = '주';
$_['text_semi_month'] = '반달';
$_['text_month'] = '월';
$_['text_year'] = '연도';

// 항목
$_['entry_name'] = '구독 요금제 이름';
$_['entry_trial_duration'] = '체험판 구독 기간';
$_['entry_trial_cycle'] = '평가판 구독 주기 수';
$_['entry_trial_frequency'] = '체험판 구독 기간';
$_['entry_trial_status'] = '평가판 구독 상태';
$_['entry_duration'] = '구독 기간';
$_['entry_cycle'] = '주기 수';
$_['entry_frequency'] = '주기 빈도';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

//열
$_['column_name'] = '구독 계획 이름';
$_['column_sort_order'] = '정렬';
$_['column_action'] = '관리';

// 돕다
$_['help_trial_duration'] = '구독 기간은 사용자가 결제하는 횟수입니다. ';
$_['help_trial_cycle'] = '구독 금액은 빈도와 주기에 따라 계산됩니다.';
$_['help_trial_frequency'] = '빈도를 "주"로, 주기를 "2"로 사용하면 사용자에게 2주마다 비용이 청구됩니다.';
$_['help_duration'] = '기간은 사용자가 결제를 하는 횟수입니다. 취소될 때까지 결제를 원할 경우 이 값을 0으로 설정하세요.';
$_['help_cycle'] = '청구 주기를 설정하려면 주기 수와 주기 유형을 사용하세요. ';
$_['help_frequency'] = '기간을 "주"로 선택하고 주기 수를 "2"로 선택하면 2주마다 요금이 청구된다는 의미입니다. ';

// 오류
$_['error_warning'] = '경고: 양식에 오류가 있는지 주의 깊게 확인하십시오!';
$_['error_permission'] = '경고: 구독 계획을 수정할 권한이 없습니다!';
$_['error_name'] = '구독 계획 이름은 3자보다 크고 255자 이하여야 합니다!';
$_['error_trial_duration'] = '시험 기간은 0보다 커야 합니다!';
$_['error_product'] = '경고: 이 구독 계획은 현재 %s 제품에 할당되어 있으므로 삭제할 수 없습니다!';