<?php
// 제목
$_['heading_title'] = '최근 활동';

//텍스트
$_['text_extension'] = '확장 기능';
$_['text_success'] = '성공: 최신 활동 설정이 업데이트되었습니다!';
$_['text_edit'] = '최근 활동 편집';
$_['text_activity_register'] = '<a href="customer_id=%d">%s</a> 님이 새 계정을 등록했습니다. ';
$_['text_activity_edit'] = '<a href="customer_id=%d">%s</a>님이 계정 데이터를 업데이트했습니다. ';
$_['text_activity_password'] = '<a href="customer_id=%d">%s</a>님이 계정 비밀번호를 업데이트했습니다. ';
$_['text_activity_reset'] = '<a href="customer_id=%d">%s</a>님이 비밀번호를 재설정했습니다. ';
$_['text_activity_login'] = '<a href="customer_id=%d">%s</a> 님이 로그인되었습니다. ';
$_['text_activity_forgotten'] = '<a href="customer_id=%d">%s</a>님이 새 비밀번호를 요청했습니다. ';
$_['text_activity_address_add'] = '<a href="customer_id=%d">%s</a>님이 새 주소를 추가했습니다. ';
$_['text_activity_address_edit'] = '<a href="customer_id=%d">%s</a>님이 주소를 업데이트했습니다. ';
$_['text_activity_address_delete'] = '<a href="customer_id=%d">%s</a>님이 주소 중 하나를 삭제했습니다. ';
$_['text_activity_return_account'] = '<a href="customer_id=%d">%s</a>님이 교환을 위해 제품을 보냈습니다. ';
$_['text_activity_return_guest'] = '%s님이 제품 반품 요청을 보냈습니다. ';
$_['text_activity_order_account'] = '<a href="customer_id=%d">%s</a>님이 <a href="order_id=%d">새 주문</a>을 추가했습니다. ';
$_['text_activity_order_guest'] = '%s님이 <a href="order_id=%d">새 주문</a>을 추가했습니다. ';
$_['text_activity_affiliate_add'] = '<a href="customer_id=%d">%s</a> 님이 추천 계정을 등록했습니다. ';
$_['text_activity_affiliate_edit'] = '<a href="customer_id=%d">%s</a>님이 추천 계정을 업데이트했습니다.';
$_['text_activity_transaction'] = '<a href="customer_id=%d">%s</a>는 <a href="order_id=%d">새 주문</a>에서 추천 커미션을 받았습니다. ';

// 항목
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';
$_['entry_width'] = '너비';

// 오류
$_['error_permission'] = '경고: 정보 개요의 최신 활동을 수정할 권한이 없습니다!';