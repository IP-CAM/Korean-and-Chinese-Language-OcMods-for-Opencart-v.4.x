<?php
// Heading
$_['heading_title']     = '文章留言';

// Text
$_['text_success']      = '成功: 文章留言已更新!';
$_['text_list']         = '文章留言清单';
$_['text_filter']       = '筛选';

// Column
$_['column_comment']    = '留言';
$_['column_article']    = '文章';
$_['column_status']     = '状态';
$_['column_date_added'] = '添加日期';
$_['column_action']     = '操作';

// Entry
$_['entry_keyword']     = '静态网址';
$_['entry_article']     = '文章';
$_['entry_customer']    = '会员';
$_['entry_status']      = '状态';
$_['entry_date_added']  = '添加日期';

// Error
$_['error_warning']     = '警告: 请检查字段输入的错误!';
$_['error_permission']  = '警告: 您没有权限编辑文章留言!';
$_['error_keyword']     = '静态网址必须是 1 到 64 个字!';