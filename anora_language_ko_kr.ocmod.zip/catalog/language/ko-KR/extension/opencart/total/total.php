<?php
// Text
$_['text_total'] = '주문 합계';