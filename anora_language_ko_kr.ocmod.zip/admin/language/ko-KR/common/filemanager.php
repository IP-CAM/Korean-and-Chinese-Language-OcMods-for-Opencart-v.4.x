<?php
// 제목
$_['heading_title'] = '이미지 관리';
 
//텍스트
$_['text_uploaded'] = '성공: 문서 업로드! ';
$_['text_directory'] = '성공: 디렉토리가 추가되었습니다! ';
$_['text_delete'] = '성공: 문서/디렉토리가 삭제되었습니다! ';

// 항목
$_['entry_search'] = '검색..';
$_['entry_folder'] = '디렉토리 이름:';

// 오류
$_['error_permission'] = '경고: 이미지 관리 권한이 없습니다! ';
$_['error_filename'] = '경고: 문서 이름은 3~255자 사이여야 합니다! ';
$_['error_folder'] = '경고: 디렉토리 이름은 3~255자 사이여야 합니다! ';
$_['error_exists'] = '경고: 문서 이름이나 디렉토리 이름이 이미 존재합니다! ';
$_['error_directory'] = '경고: 디렉터리를 선택하세요! ';
$_['error_filesize'] = '경고: 문서 크기가 잘못되었습니다! ';
$_['error_file_type'] = '경고: 문서 유형이 잘못되었습니다! ';
$_['error_upload'] = '경고: 알 수 없는 이유로 문서 업로드에 실패했습니다! ';
$_['error_delete'] = '경고: 이 디렉토리는 삭제할 수 없습니다! ';