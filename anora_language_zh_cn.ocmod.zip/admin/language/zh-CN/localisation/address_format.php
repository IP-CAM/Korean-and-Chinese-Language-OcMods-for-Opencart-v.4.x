<?php
// Heading
$_['heading_title']           = '地址格式';

// Text
$_['text_success']            = '成功: 地址格式设置已更新!';
$_['text_list']               = '地址格式清单';
$_['text_add']                = '添加地址格式';
$_['text_edit']               = '编辑地址格式';

// Column
$_['column_name']             = '地址格式名称';
$_['column_address_format']   = '地址格式';
$_['column_action']           = '管理';

// Entry
$_['entry_name']              = '地址格式名称';
$_['entry_address_format']    = '地址格式';

// Help
$_['help_address_format']     = '名字 = {firstname}<br />姓氏 = {lastname}<br />公司 = {company}<br />地址 1 = {address_1}<br />地址 2 = {address_2}<br />乡镇市区 = {city}<br />邮递区号 = {postcode}<br />县市 = {zone}<br />县市代码 = {zone_code}<br />国别 = {country}';

// Error
$_['error_permission']        = '警告: 您没有权限编辑地址格式!';
$_['error_name']              = '地址格式名称必须是 1 到 128 个字!';
$_['error_default']           = '警告: 这组地址格式已被设置为默认地址格式，无法删除!';
$_['error_country']           = '警告: 这组地址格式已设置为 %s 个国家的地址格式，无法删除!';