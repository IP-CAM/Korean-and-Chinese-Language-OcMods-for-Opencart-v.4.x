<?php
// 제목
$_['heading_title'] = '세율 카테고리';

//텍스트
$_['text_success'] = '성공: 세율 카테고리 설정이 업데이트되었습니다! ';
$_['text_list'] = '세금목록';
$_['text_add'] = '세금 카테고리 추가';
$_['text_edit'] = '세금 카테고리 편집';
$_['text_tax_class'] = '세금 분류';
$_['text_tax_rate'] = '세율';
$_['text_shipping'] = '배송주소';
$_['text_payment'] = '청구서 수신 주소';
$_['text_store'] = '상점주소';

//열
$_['column_title'] = '세금제목';
$_['column_action'] = '관리';

// 항목
$_['entry_title'] = '세금분류 제목';
$_['entry_description'] = '세금 설명';
$_['entry_rate'] = '세율';
$_['entry_based'] = '기준';
$_['entry_geo_zone'] = '지역';
$_['entry_priority'] = '우선순위';

// 오류
$_['error_permission'] = '경고: 세율 카테고리를 변경할 권한이 없습니다! ';
$_['error_title'] = '세금 항목 제목은 3~32단어여야 합니다! ';
$_['error_description'] = '세금 설명 길이는 3~255 단어여야 합니다! ';
$_['error_product'] = '경고: %s 항목이 이미 사용 중이므로 이 세금 범주를 삭제할 수 없습니다! ';