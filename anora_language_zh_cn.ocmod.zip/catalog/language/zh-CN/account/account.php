<?php
// Heading
$_['heading_title']       = '我的帐号';

// Text
$_['text_account']        = '会员中心';
$_['text_my_account']     = '我的帐号';
$_['text_my_orders']      = '我的订单';
$_['text_my_affiliate']   = '推荐帐号';
$_['text_my_newsletter']  = '我的订阅';
$_['text_edit']           = '编辑帐号';
$_['text_password']       = '变更密码';
$_['text_address']        = '常用地址';
$_['text_payment_method'] = '常用付款数据';
$_['text_wishlist']       = '追踪清单';
$_['text_order']          = '我的订单';
$_['text_subscription']   = '我的订阅';
$_['text_download']       = '我的下载';
$_['text_reward']         = '红利点数'; 
$_['text_return']         = '商品退换'; 
$_['text_transaction']    = '购物金'; 
$_['text_newsletter']     = '电子报';
$_['text_transactions']   = '购物金';
$_['text_affiliate_add']  = '申请推荐帐号';
$_['text_affiliate_edit'] = '编辑推荐帐号';
$_['text_tracking']       = '自订推荐追踪码';