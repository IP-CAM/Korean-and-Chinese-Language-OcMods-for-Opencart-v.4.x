<?php
// Heading
$_['heading_title']        = 'API 管理';

// Text
$_['text_success']         = '成功: API 设置已更新 !';
$_['text_list']            = 'API 清单';
$_['text_add']             = '添加 API';
$_['text_edit']            = '编辑 API';
$_['text_ip']              = '您可在下方创建允许介接 API 的 IP 清单，您目前的 IP 是 %s';

// Column
$_['column_username']      = 'API Username';
$_['column_status']        = '状态';
$_['column_token']         = 'Token';
$_['column_ip']            = 'IP';
$_['column_date_added']    = '添加日期';
$_['column_date_modified'] = '修改日期';
$_['column_action']        = '管理';

// Entry
$_['entry_username']       = 'API Username';
$_['entry_key']            = 'API Key';
$_['entry_status']         = '状态';
$_['entry_ip']             = 'IP';

// Error
$_['error_permission']     = '警告: 您没有权限修改 API 管理！';
$_['error_username']       = 'API Username 必须是 3 到 20 个字！';
$_['error_key']            = 'API Key 必须是 64 到 256 个字！';
$_['error_ip']             = '您必须至少有一组 IP 加入允许的清单中!';