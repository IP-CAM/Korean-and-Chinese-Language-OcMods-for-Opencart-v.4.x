<?php
// Heading
$_['heading_title'] = '信息总览';