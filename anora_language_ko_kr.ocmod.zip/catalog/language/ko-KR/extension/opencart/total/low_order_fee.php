<?php
//텍스트
$_['text_low_order_fee'] = '소액 주문 수수료';