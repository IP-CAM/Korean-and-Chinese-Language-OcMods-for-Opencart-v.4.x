<?php
// Heading 
$_['heading_title']    = '订阅电子报';

// Text
$_['text_account']     = '我的帐号';
$_['text_newsletter']  = '电子报';
$_['text_success']     = '成功: 电子报订阅已更新！';

// Entry
$_['entry_newsletter'] = '订阅';