<?php
// Heading
$_['heading_title'] = '회원 관리';

//텍스트
$_['text_success'] = '성공: 회원 데이터 설정이 업데이트되었습니다!';
$_['text_list'] = '회원 목록';
$_['text_add'] = '회원 추가';
$_['text_edit'] = '회원 편집';
$_['text_default'] = '기본값';
$_['text_store'] = '저장';
$_['text_customer'] = '기본 데이터';
$_['text_password'] = '비밀번호';
$_['text_other'] = '기타';
$_['text_balance'] = '균형';
$_['text_address'] = '주소';
$_['text_payment_method']   = '결제 수단';
$_['text_history'] = '비고';
$_['text_history_add'] = '메모 추가';
$_['text_transaction'] = '쇼핑 크레딧';
$_['text_transaction_add'] = '쇼핑 크레딧 추가';
$_['text_reward'] = '보너스 포인트';
$_['text_reward_add'] = '보너스 포인트 추가';
$_['text_ip'] = 'IP';
$_['text_option'] = '옵션';
$_['text_login'] = '로그인 스토어';
$_['text_unlock'] = '계정 잠금 해제';
$_['text_filter'] = '회원 필터';

//열
$_['column_name'] = '회원 이름';
$_['column_email'] = '이메일';
$_['column_customer_group'] = '회원등급';
$_['column_status'] = '상태';
$_['column_date_add'] = '날짜 추가';
$_['column_comment'] = '비고';
$_['column_description'] = '설명';
$_['column_amount'] = '금액';
$_['column_points'] = '포인트';
$_['column_ip'] = 'IP';
$_['column_account'] = '계정';
$_['column_store'] = '저장';
$_['column_country'] = '국가';
$_['column_payment_method'] = '付款方式';
$_['column_image'] = '아이콘';
$_['column_type'] = '유형';
$_['column_date_expire'] = '만료일';
$_['column_action'] = '관리';

// 항목
$_['entry_store'] = '스토어';
$_['entry_customer_group'] = '회원등급';
$_['entry_firstname'] = '이름';
$_['entry_lastname'] = '성';
$_['entry_email'] = '이메일';
$_['entry_telephone'] = '휴대폰번호';
$_['entry_newsletter'] = '전자뉴스레터';
$_['entry_status'] = '계정 상태';
$_['entry_safe'] = '보안';
$_['entry_password'] = '비밀번호';
$_['entry_confirm'] = '비밀번호 확인';
$_['entry_company'] = '회사명';
$_['entry_address_1'] = '주소';
$_['entry_address_2'] = '주소 2';
$_['entry_city'] = '타운십 도시';
$_['entry_postcode'] = '우편번호';
$_['entry_country'] = '국가';
$_['entry_zone'] = '군 및 도시';
$_['entry_default'] = '기본 주소';
$_['entry_comment'] = '비고';
$_['entry_description'] = '설명';
$_['entry_amount'] = '금액';
$_['entry_points'] = '포인트';
$_['entry_name'] = '회원 이름';
$_['entry_ip'] = 'IP';
$_['entry_date_from'] = '가입 날짜(부터)';
$_['entry_date_to'] = '가입 날짜(까지)';

// 버튼
$_['button_order'] = '주문';

// 돕다
$_['help_safe'] = '사기 방지 시스템에 의해 회원이 차단되는 것을 방지하려면 '예(true)'로 설정하십시오. ';
$_['help_points'] = '점수를 차감하려면 마이너스 기호를 사용하세요';

// 오류
$_['error_warning'] = '경고: 채워진 내용을 확인하세요!';
$_['error_permission'] = '경고: 귀하는 회원정보를 수정할 수 있는 권한이 없습니다!';
$_['error_customer'] = '경고: 회원이 존재하지 않습니다!';
$_['error_exists'] = '경고: 이메일 사서함이 이미 등록되었습니다!';
$_['error_address'] = '경고: 주소 데이터가 존재하지 않습니다!';
$_['error_firstname'] = '이름은 1~32자 이상이어야 합니다!';
$_['error_lastname'] = '성 이름은 최소 1~32자 이상이어야 합니다!';
$_['error_email'] = '올바른 이메일 주소를 입력해주세요!';
$_['error_telephone'] = '휴대전화 번호는 1~32자 이상이어야 합니다!';
$_['error_password'] = '비밀번호 길이는 최소 4~20자여야 합니다!';
$_['error_confirm'] = '비밀번호와 확인 비밀번호가 일치하지 않습니다!';
$_['error_address_1'] = '주소는 ​​최소한 3~128 단어 길이여야 합니다!';
$_['error_city'] = '도시, 도시, 마을의 길이는 최소 2~128자여야 합니다!';
$_['error_postcode'] = '우편번호는 최소 2~10자 이상이어야 합니다!';
$_['error_country'] = '국가를 선택하세요!';
$_['error_zone'] = '국가나 도시를 선택하세요!';
$_['error_custom_field'] = '%s을(를) 입력해야 합니다!';
$_['error_regex'] = '%s은(는) 유효한 값이 아닙니다!';