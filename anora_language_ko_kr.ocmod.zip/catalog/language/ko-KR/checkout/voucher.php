<?php
// 제목
$_['heading_title'] = '쇼핑상품권 구매';

//텍스트
$_['text_account'] = '계정';
$_['text_voucher'] = '쇼핑상품권';
$_['text_description'] = '이 상품권은 주문 결제 후 이메일을 통해 수령인에게 발송됩니다. ';
$_['text_agree'] = '상품권은 환불되지 않음을 이해하고 이에 동의합니다.';
$_['text_message'] = '<p>상품권을 구매해주셔서 감사합니다! 주문을 완료하면 상품권 수령인에게 상품권 사용 방법에 대한 자세한 지침이 포함된 이메일이 발송됩니다. </p>';
$_['text_for'] = '%s %s 쇼핑 상품권';

// 항목
$_['entry_to_name'] = '수신자 이름';
$_['entry_to_email'] = '수신자 이메일';
$_['entry_from_name'] = '귀하의 이름';
$_['entry_from_email'] = '귀하의 이메일';
$_['entry_theme'] = '쇼핑상품권 테마';
$_['entry_message'] = '메시지 남기기';
$_['entry_amount'] = '금액';

// 돕다
$_['help_message'] = '선택적';
$_['help_amount'] = '금액은 %s에서 %s 사이여야 합니다.';

// 오류
$_['error_token'] = '경고: 잘못된 쇼핑 상품권 키!';
$_['error_voucher'] = '쇼핑 상품권을 찾을 수 없습니다!';
$_['error_to_name'] = '수신자 이름은 1~64자여야 합니다!';
$_['error_from_name'] = '이름은 1~64자 사이여야 합니다!';
$_['error_email'] = '이메일 형식이 올바르지 않습니다!';
$_['error_theme'] = '쇼핑상품권 테마를 선택해야 합니다!';
$_['error_amount'] = '금액은 %s에서 %s 사이여야 합니다!';
$_['error_agree'] = '경고: 상품권은 환불되지 않는다는 점에 동의해야 합니다!';