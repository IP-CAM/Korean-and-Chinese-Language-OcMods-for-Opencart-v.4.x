<?php
//텍스트
$_['text_success'] = '성공: 배송방법이 설정되었습니다!';

// 오류
$_['error_shipping_address'] = '경고: 배송 주소가 필요합니다!';
$_['error_shipping_method'] = '경고: 배송 방법이 필요합니다!';
$_['error_no_shipping'] = '경고: 유효한 배송 방법이 없습니다!';
$_['error_shipping'] = '경고: 배송할 제품이 없습니다';