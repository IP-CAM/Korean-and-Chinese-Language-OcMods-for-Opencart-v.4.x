<?php
// Heading 
$_['heading_title']   = '关注商品';

// Text
$_['text_account']    = '我的帐号';
$_['text_instock']    = '有现货';
$_['text_wishlist']   = '关注商品(%s)';
$_['text_login']      = '请先<a href="%s">登录</a> 或 <a href="%s">注册新帐号</a> 以便保存 <a href="%s">%s</a> 到您的 <a href="%s">关注商品</a>！';
$_['text_success']    = '成功: 您已经添加<a href="%s">%s</a> 到您的 <a href="%s">关注商品</a>！';
$_['text_remove']     = '成功: 您已经更新您的关注商品清单！';
$_['text_no_results'] = '您目前没有关注任何商品';

// Column
$_['column_image']    = '图片';
$_['column_name']     = '商品名称';
$_['column_model']    = '型号';
$_['column_stock']    = '库存';
$_['column_price']    = '售价';
$_['column_action']   = '操作';

// Error
$_['error_product']   = '警告: 找不到商品!';