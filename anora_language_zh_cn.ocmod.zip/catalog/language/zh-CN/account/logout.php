<?php
// Heading 
$_['heading_title'] = '帐号注销';

// Text
$_['text_message']  = '<p>您已注销了您的帐号，可以安全离开电脑了。</p>';
$_['text_account']  = '我的帐号';
$_['text_logout']   = '注销';