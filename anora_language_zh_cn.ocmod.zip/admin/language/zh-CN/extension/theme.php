<?php
// Heading
$_['heading_title']    = '布景主题';

// Text
$_['text_success']     = '成功: 布景主题设置已更新!';

// Column
$_['column_name']      = '布景主题名称';
$_['column_status']    = '状态';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 您没有权限编辑布景主题!';
$_['error_extension']  = '警告: 扩展模块不存在!';
