<?php
// Heading
$_['heading_title']    = '基本验证码';

// Text
$_['text_extension']   = '扩充功能';
$_['text_success']	   = '成功: 基本验证码设置已更新!';
$_['text_edit']        = '编辑基本验证码';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 您没有权限修改基本验证码!';