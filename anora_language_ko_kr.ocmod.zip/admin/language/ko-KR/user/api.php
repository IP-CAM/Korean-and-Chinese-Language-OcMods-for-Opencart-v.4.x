<?php
// 제목
$_['heading_title'] = 'API 관리';

//텍스트
$_['text_success'] = '성공: API 설정이 업데이트되었습니다!';
$_['text_list'] = 'API 목록';
$_['text_add'] = 'API 추가';
$_['text_edit'] = 'API 편집';
$_['text_ip'] = '아래 API에 연결이 허용된 IP 목록을 생성할 수 있습니다. 현재 IP는 %s입니다.';

//열
$_['column_username'] = 'API 사용자 이름';
$_['column_status'] = '상태';
$_['column_token'] = '토큰';
$_['column_ip'] = 'IP';
$_['column_date_added'] = '날짜 추가';
$_['column_date_modified'] = '수정된 날짜';
$_['column_action'] = '관리';

// 항목
$_['entry_username'] = 'API 사용자 이름';
$_['entry_key'] = 'API 키';
$_['entry_status'] = '상태';
$_['entry_ip'] = 'IP';

// 오류
$_['error_permission'] = '경고: API 관리를 수정할 권한이 없습니다! ';
$_['error_username'] = 'API 사용자 이름은 3~20자여야 합니다! ';
$_['error_key'] = 'API 키는 64~256자여야 합니다! ';
$_['error_ip'] = '허용 목록에 최소한 하나의 IP 세트가 추가되어 있어야 합니다!';