<?php
// Heading
$_['heading_title']        = '任务调度(Cron Job)';

// Text
$_['text_success']         = '成功: 任务调度设置已更新!';
$_['text_instruction']     = '任务调度介绍';
$_['text_list']            = '任务调度清单';
$_['text_cron_1']          = '任务调度是定期运行的任务计划，要设置您的服务器以使用任务调度作业，您可以阅读 url <a href="http://docs.opencart.com/extension/cron/" target="_blank" class="alert-link">opencart documentation</a> 网页.';
$_['text_cron_2']          = '您需要将任务调度设置为每小时运行一次。';
$_['text_info']            = '任务调度信息';
$_['text_hour']            = '时';
$_['text_day']             = '日';
$_['text_month']           = '月';

// Column
$_['column_code']          = '任务调度代码';
$_['column_cycle']         = '周期';
$_['column_date_added']    = '添加日期';
$_['column_date_modified'] = '修改日期';
$_['column_action']        = '操作';

// entry
$_['entry_cron']           = '任务调度 URL';
$_['entry_description']    = '任务调度说明';

// Error
$_['error_permission']     = '警告: 您没有权限编辑任务调度!';