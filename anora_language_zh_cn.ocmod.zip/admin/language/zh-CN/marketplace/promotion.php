<?php
// Text
$_['text_recommended'] = '推荐模块';
$_['text_install']     = '安装';
$_['text_uninstall']   = '卸载';
$_['text_delete']      = '移除';
