<?php
//텍스트
$_['text_recommended'] = '추천 모듈';
$_['text_install'] = '설치';
$_['text_uninstall'] = '제거';
$_['text_delete'] = '제거';