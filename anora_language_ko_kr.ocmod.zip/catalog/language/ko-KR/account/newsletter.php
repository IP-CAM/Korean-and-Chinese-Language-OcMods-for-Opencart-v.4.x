<?php
// 제목
$_['heading_title'] = '뉴스레터 구독';

//텍스트
$_['text_account'] = '내 계정';
$_['text_newsletter'] = '전자뉴스레터';
$_['text_success'] = '성공: 뉴스레터 구독이 업데이트되었습니다! ';

// 항목
$_['entry_newsletter'] = '구독';