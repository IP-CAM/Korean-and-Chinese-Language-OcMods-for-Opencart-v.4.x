<?php
// Heading
$_['heading_title']            = '重要安全性提醒!';

// Text
$_['text_install']             = '系统安装目录 (Installation directory)';
$_['text_install_description'] = '系统安装目录建议在安装完成后删除!';
$_['text_install_success']     = '成功: 系统安装目录已删除!';
$_['text_storage']             = '系统数据目录路径 (Storage path)';
$_['text_storage_description'] = '系统数据目录是用来保存比较重要的文档(例如 error.log)，建议将路径移至网站根目录以外 (例如: public_html, www 或 htdocs)。';
$_['text_storage_success']     = '成功: 系统数据目录路径已变更!';
$_['text_admin']               = '编辑 admin/config.php 文档设置';
$_['text_admin_description']   = '建议为后台管理目录变更目录名称';
$_['text_admin_success']       = '成功: 后台管理目录名称已变更!';
$_['text_path']                = '路径';

// Entry
$_['entry_path']               = '目录';
$_['entry_path_current']       = '目前路径';
$_['entry_path_new']           = '新的路径';
$_['entry_name']               = '目录名称';

// Button
$_['button_move']              = '移动';
$_['button_rename']            = '变更';

// Error
$_['error_permission']         = '警告: 您没有权限编辑安全性设置!';
$_['error_install']            = '警告: 系统安装目录不存在!';
$_['error_storage']            = '警告: 系统数据目录不存在!';
$_['error_storage_exists']     = '警告: 新的系统数据目录名称已存在!';
$_['error_admin']              = '警告: 后台管理目录不存在!';
$_['error_admin_exists']       = '警告: 新的后台管理名称已存在!';
$_['error_admin_name']         = '警告: 后台管理名称不能是 `admin` 因为它将对外开放!';
$_['error_writable']           = '警告: config.php 档及 admin/config.php 档必须是可写入!';