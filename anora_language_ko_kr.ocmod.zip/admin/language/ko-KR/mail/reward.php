<?php
//텍스트
$_['text_subject'] = '%s - 보너스 포인트';
$_['text_received'] = '%s 보너스 포인트를 받았습니다!';
$_['text_total'] = '현재 누적된 보너스 포인트는 %s 포인트입니다.';