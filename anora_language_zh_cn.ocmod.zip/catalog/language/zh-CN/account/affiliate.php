<?php
// Heading
$_['heading_title']             = '推荐帐号信息';

// Text
$_['text_account']              = '我的帐号';
$_['text_affiliate']            = '推荐帐号';
$_['text_my_affiliate']         = '我的推荐帐号';
$_['text_payment']              = '付款信息';
$_['text_cheque']               = '支票';
$_['text_paypal']               = 'PayPal';
$_['text_bank']                 = '银行转帐';
$_['text_success']              = '成功：您的推荐帐号信息已更新';
$_['text_agree']                = '我已经阅读并同意 <a href="%s" class="agree"><b>%s</b></a>';

// Entry
$_['entry_company']             = '公司名称';
$_['entry_website']             = '网站网址';
$_['entry_tax']                 = 'Tax ID';
$_['entry_payment_method']      = '付款方式';
$_['entry_cheque']              = '支票收款人姓名';
$_['entry_paypal']              = 'PayPal Email 帐号';
$_['entry_bank_name']           = '银行名称';
$_['entry_bank_branch_number']  = 'ABA/BSB number (Branch Number)';
$_['entry_bank_swift_code']     = 'SWIFT Code';
$_['entry_bank_account_name']   = '银行帐户名称';
$_['entry_bank_account_number'] = '银行帐户号码';

// Error
$_['error_token']               = '警告：密钥已失效!';
$_['error_agree']               = '警告：您必须同意 %s!';
$_['error_payment_method']      = '付款方式必须设置!';
$_['error_cheque']              = '支票收款人姓名必须输入!';
$_['error_paypal']              = 'PayPal Email 帐号不能是无效的!';
$_['error_bank_account_name']   = '银行帐户名称必须输入!';
$_['error_bank_account_number'] = '银行帐户号码必须输入!';
$_['error_custom_field']        = '%s 必须输入!';
$_['error_regex']               = '%s 不是有效的值!';