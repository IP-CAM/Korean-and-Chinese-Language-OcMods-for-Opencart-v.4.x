<?php
// 제목
$_['heading_title'] = '상점주소';

//텍스트
$_['text_success'] = '성공: 매장 주소 설정이 업데이트되었습니다! ';
$_['text_list'] = '상점 주소 목록';
$_['text_add'] = '상점 주소 추가';
$_['text_edit'] = '상점 주소 수정';
$_['text_geocode'] = '다음과 같은 이유로 위도 및 경도 좌표 설정이 실패했습니다:';

//열
$_['column_name'] = '상점 이름';
$_['column_address'] = '주소';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '상점 이름';
$_['entry_address'] = '주소';
$_['entry_geocode'] = '위도 및 경도 좌표';
$_['entry_telephone'] = '전화';
$_['entry_image'] = '이미지';
$_['entry_open'] = '영업시간';
$_['entry_comment'] = '비고';

// 돕다
$_['help_geocode'] = '상점 주소의 위도와 경도 좌표를 입력하세요. ';
$_['help_open'] = '상점의 영업시간을 입력하세요. ';
$_['help_comment'] = '이 필드는 고객에게 말하고 싶은 내용에 대해 설명하는 데 사용할 수 있습니다. 예를 들어 상점에서는 수표를 받지 않습니다. ';

// 오류
$_['error_permission'] = '경고: 상점 주소를 수정할 권한이 없습니다! ';
$_['error_name'] = '상점 이름은 3~32자여야 합니다! ';
$_['error_address'] = '주소는 ​​3~128 단어여야 합니다! ';
$_['error_telephone'] = '연락처 번호는 3~32자여야 합니다! ';