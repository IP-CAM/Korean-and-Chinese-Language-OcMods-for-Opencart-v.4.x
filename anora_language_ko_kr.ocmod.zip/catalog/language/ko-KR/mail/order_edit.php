<?php
// Text
$_['text_subject'] = '%s - 주문 업데이트 %s';
$_['text_order_id'] = '주문번호:';
$_['text_date_add'] = '주문 날짜:';
$_['text_order_status'] = '귀하의 주문이 다음 상태로 업데이트되었습니다:';
$_['text_comment'] = '주문 비고:';
$_['text_link'] = '주문을 보려면 아래 링크를 클릭하십시오:';
$_['text_footer'] = '질문이 있으시면 이 이메일에 회신해 주십시오.';