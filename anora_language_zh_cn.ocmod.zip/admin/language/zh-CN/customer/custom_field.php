<?php
// Heading
$_['heading_title']        = '自订字段';

// Text
$_['text_success']         = '成功: 自订字段设置已更新！';
$_['text_list']            = '自订字段清单';
$_['text_add']             = '添加自订字段';
$_['text_edit']            = '编辑自订字段';
$_['text_choose']          = '选择';
$_['text_select']          = '列表';
$_['text_radio']           = '单选';
$_['text_checkbox']        = '复选框';
$_['text_input']           = '文本框';
$_['text_text']            = '文本';
$_['text_textarea']        = '多行文本框';
$_['text_file']            = '文档';
$_['text_date']            = '日期';
$_['text_datetime']        = '日期 &amp; 时间';
$_['text_time']            = '时间';
$_['text_account']         = '帐号';
$_['text_address']         = '地址';
$_['text_affiliate']       = '推荐';
$_['text_regex']           = '正则表达式(Regex)';
$_['text_custom_field']    = '自订字段';
$_['text_value']           = '自订字段值';

// Column
$_['column_name']          = '字段名称';
$_['column_location']      = '位置';
$_['column_type']          = '类型';
$_['column_status']        = '状态';
$_['column_sort_order']    = '显示排序';
$_['column_action']        = '管理';

// Entry
$_['entry_name']           = '自订字段名称';
$_['entry_location']       = '位置';
$_['entry_type']           = '类型';
$_['entry_value']          = '值';
$_['entry_validation']     = '验证';
$_['entry_custom_value']   = '自订字段值名称';
$_['entry_customer_group'] = '会员等级';
$_['entry_required']       = '必填';
$_['entry_status']         = '状态';
$_['entry_sort_order']     = '显示排序';

// Help
$_['help_regex']           = '使用正则表达式，例如: /[a-zA-Z0-9_-]/';
$_['help_sort_order']      = '使用 "-" 从集合中的最后一个字段向后计数。';

// Error
$_['error_permission']     = '警告: 您没有权限修改自订字段！';
$_['error_name']           = '自订字段名称必须是 1 到 128 个字！';
$_['error_type']           = '警告: 自订字段值必须填写！';
$_['error_custom_value']   = '自订字段值名称必须是 1 到 128 个字！';