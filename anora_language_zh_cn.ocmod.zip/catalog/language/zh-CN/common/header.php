<?php
// Text
$_['text_wishlist'] 	 = '追踪清单(%s)';
$_['text_shopping_cart'] = '购物车';
$_['text_account']  	 = '会员中心';
$_['text_register']      = '会员注册';
$_['text_login']         = '会员登录';
$_['text_order']         = '我的订单';
$_['text_transaction']   = '购物金';
$_['text_download']      = '我的下载';
$_['text_logout']        = '会员注销';
$_['text_checkout'] 	 = '结帐';