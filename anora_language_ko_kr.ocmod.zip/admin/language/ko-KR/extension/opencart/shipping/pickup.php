<?php
// 제목
$_['heading_title'] = '직접 물건을 가져가세요';

//텍스트
$_['text_extension'] = '확장 기능';
$_['text_success'] = '성공: 셀프 픽업 모듈 설정이 업데이트되었습니다! ';
$_['text_edit'] = '셀프 픽업 모듈 편집';

// 항목
$_['entry_geo_zone'] = '해당지역';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 셀프 픽업 모듈을 수정할 권한이 없습니다! ';