<?php
// 제목
$_['heading_title'] = '은행 송금 또는 이체';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_success'] = '성공: 은행 송금 또는 이체 모듈 설정이 업데이트되었습니다!';
$_['text_edit'] = '은행 송금 또는 이체 수정';

// 항목
$_['entry_bank'] = '은행 송금 또는 이체 관련 데이터';
$_['entry_order_status'] = '기본 주문 상태';
$_['entry_geo_zone'] = '해당지역';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 은행 이체 또는 이체 모듈을 편집할 수 있는 권한이 없습니다!';
$_['error_bank'] = '은행 송금 또는 이체 관련 데이터를 반드시 입력해야 합니다!';