<?php
// 제목
$_['heading_title'] = '확장 모듈 시장';

//텍스트
$_['text_success'] = '성공: 확장 모듈 마켓 설정이 업데이트되었습니다!';
$_['text_list'] = '확장 모듈 목록';
$_['text_filter'] = '모듈 필터';
$_['text_search'] = '확장 모듈 또는 레이아웃 검색';
$_['text_category'] = '범주';
$_['text_all'] = '모두';
$_['text_theme'] = '장면 테마';
$_['text_marketplace'] = '확장 모듈 시장';
$_['text_language'] = '언어';
$_['text_payment'] = '결제 모듈';
$_['text_shipping'] = '배송 모듈';
$_['text_module'] = '함수 모듈';
$_['text_total'] = '전체 모듈 주문';
$_['text_feed'] = '피드 모듈';
$_['text_report'] = '보고서 모듈';
$_['text_other'] = '기타 모듈';
$_['text_free'] = '무료';
$_['text_paid'] = '결제됨';
$_['text_purchased'] = '구매함';
$_['text_recommended'] = '권장';
$_['text_date_modified'] = '업데이트 날짜';
$_['text_date_added'] = '날짜 추가';
$_['text_rated'] = '평점';
$_['text_reviews'] = '리뷰';
$_['text_compatibility'] = '호환성';
$_['text_downloaded'] = '다운로드 횟수';
$_['text_member_since'] = '가입 날짜:';
$_['text_price'] = '판매가';
$_['text_featured'] = '추천';
$_['text_partner'] = 'OpenCart 개발 파트너가 설계함';
$_['text_support'] = '12개월 무료 기술 지원';
$_['text_documentation'] = '사용 문서 포함';
$_['text_sales'] = '판매됨';
$_['text_comment'] = '질문&답변';
$_['text_download'] = '다운로드 중';
$_['text_install'] = '설치 중';
$_['text_comment_add'] = '질문';
$_['text_write'] = '질문을 입력하세요..';
$_['text_purchase'] = '신원을 확인해주세요!';
$_['text_pin'] = '비밀번호 4자리를 입력하세요. 비밀번호는 귀하의 계정을 보호하는 데 사용됩니다. ';
$_['text_secure'] = '다른 사람(모듈 제조업체 포함)에게 PIN 코드를 제공하지 마십시오. 모듈 제조업체에 설치에 대한 도움을 요청해야 하는 경우 설치하려는 모듈을 알려주십시오. ';
$_['text_name'] = '다운로드 이름';
$_['text_available'] = '설치 가능';
$_['text_action'] = '액션';
$_['text_install'] = '설치';
$_['text_uninstall'] = '제거';
$_['text_delete'] = '삭제';
$_['text_more'] = '더 많은 답글 보기...';
$_['text_refresh'] = '새로고침';

// 항목
$_['entry_pin'] = '비밀번호';

//탭
$_['tab_description'] = '기본 데이터';
$_['tab_documentation'] = '자세한 설명';
$_['tab_download'] = '문서 다운로드';
$_['tab_comment'] = '질문&답변';

// 버튼
$_['button_api'] = '확장 모듈 마켓 API';
$_['button_purchase'] = '구매';
$_['button_view_all'] = '모든 확장 모듈 보기';
$_['button_support'] = '지원 요청';
$_['button_comment'] = '질문하기';
$_['button_reply'] = '답장';
$_['button_forgot_pin'] = 'PIN 분실';

// 오류
$_['error_permission'] = '경고: 확장 모듈을 편집할 수 있는 권한이 없습니다!';
$_['error_api'] = '경고: 확장 기능을 구매하려면 확장 마켓플레이스 API 데이터를 입력해야 합니다!';
$_['error_purchase'] = '확장 모듈을 구매할 수 없습니다!';
$_['error_download'] = '확장 모듈을 다운로드할 수 없습니다!';