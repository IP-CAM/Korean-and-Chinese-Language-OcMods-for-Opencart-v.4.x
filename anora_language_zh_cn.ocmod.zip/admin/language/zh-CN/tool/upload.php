<?php
// Heading
$_['heading_title']      = '上传文档';

// Text
$_['text_success']       = '成功: 上传文档设置已更新！';
$_['text_list']          = '上传文档清单';
$_['text_filter']        = '筛选';

// Column
$_['column_name']        = '上传文档名称';
$_['column_code']   	 = '代码';
$_['column_date_added']  = '添加日期';
$_['column_action']      = '管理';

// Entry
$_['entry_name']         = '上传文档名称';
$_['entry_filename']     = '文档名称';
$_['entry_date_from']    = '添加日期(起)';
$_['entry_date_to']      = '添加日期(止)';

// Error
$_['error_permission']   = '警告: 您没有权限上传文档！';
$_['error_not_found']    = '错误: 找不到文档 %s !';
$_['error_headers_sent'] = '错误: Headers already sent out!';
$_['error_upload']       = '文档无法上传!';
$_['error_filename']     = '文档名必须是 3 到 128 个字!';
$_['error_file_type']    = '无效的文档类型!';
