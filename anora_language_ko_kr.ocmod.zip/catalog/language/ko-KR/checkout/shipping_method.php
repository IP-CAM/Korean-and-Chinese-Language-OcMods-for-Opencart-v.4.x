<?php
// Heading
$_['heading_title'] = '배송방법';

//텍스트
$_['text_shipping_method'] = '배송방법 옵션';
$_['text_shipping'] = '적절한 배송방법을 선택해주세요';
$_['text_success'] = '배송방법이 적용되었습니다!';

// 항목
$_['entry_shipping_method'] = '배송 방법을 선택하세요...';

// 오류
$_['error_customer'] = '고객 데이터가 있어야 합니다!';
$_['error_payment_address']  = '경고: 회원 주소가 필요합니다!';
$_['error_shipping_address'] = '경고: 배송 주소가 필요합니다!';
$_['error_shipping_method'] = '경고: 배송 방법을 선택해야 합니다!';
$_['error_no_shipping'] = '경고: 사용할 수 있는 배송 방법이 없습니다. 도움이 필요하면 <a href="%s">고객 서비스에 문의</a>하세요!';
