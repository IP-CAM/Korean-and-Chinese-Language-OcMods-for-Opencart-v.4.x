<?php
// 제목
$_['heading_title'] = '무게 기준';

//텍스트
$_['text_weight'] = '무게:';