<?php
// Text
$_['text_credit']   = '购物金';
$_['text_order_id'] = '订单编号: #%s';