<?php
// 제목
$_['heading_title'] = '언어 모듈';

//텍스트
$_['text_success'] = '성공: 언어 모듈이 업데이트되었습니다!';
$_['text_list'] = '언어 목록';

//열
$_['column_name'] = '언어 이름';
$_['column_status'] = '상태';
$_['column_action'] = '액션';

// 오류
$_['error_permission'] = '경고: 언어 모듈을 편집할 수 있는 권한이 없습니다!';
$_['error_extension'] = '경고: 언어 모듈이 존재하지 않습니다!';