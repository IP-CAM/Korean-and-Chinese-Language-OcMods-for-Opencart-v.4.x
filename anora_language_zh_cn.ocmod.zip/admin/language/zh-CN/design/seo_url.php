<?php
// Heading
$_['heading_title']        = '静态网址(SEO URL)';

// Text
$_['text_success']         = '成功: 静态网址(SEO URL)设置已更新!';
$_['text_list']            = '静态网址清单';
$_['text_add']             = '添加静态网址';
$_['text_edit']            = '编辑静态网址';
$_['text_filter']          = '筛选';
$_['text_default']         = '默认';

// Column
$_['column_key']           = 'Key 参数';
$_['column_value']         = 'Key 值';
$_['column_keyword']       = '静态网址名称';
$_['column_store']         = '商店';
$_['column_language']      = '语系';
$_['column_action']        = '操作';

// Entry
$_['entry_store']          = '商店';
$_['entry_language']       = '语系';
$_['entry_key']            = 'Key 参数';
$_['entry_value']          = 'Key 值';
$_['entry_keyword']        = '静态网址名称';
$_['entry_sort_order']     = '排序';

// Help
$_['help_keyword']         = '只能使用 a-z 或 0-9 以及 - 或 _ 或空白字符，不设置就维持空白。';
$_['help_sort_order']      = '静态网址名称的排序';

// Error
$_['error_permission']     = '警告: 您没有权限修改静态网址!';
$_['error_exists']         = '警告: 商店别 + 语系别 + key + value + 静态网址名称 已存在!';
$_['error_key']            = 'Key 参数必须是 1 到 64 个字!';
$_['error_value']          = 'Key 值必须是 1 到 255 个字!';
$_['error_value_exists']   = 'Key 值已经被使用!';
$_['error_keyword']        = '静态网址名称必须是 3 到 64 个字!';
$_['error_keyword_exists'] = '静态网址名称已经被使用中!';
$_['error_keyword_character'] = '静态网址名称只能使用 a-z, 0-9, - and _ 等字符!';
