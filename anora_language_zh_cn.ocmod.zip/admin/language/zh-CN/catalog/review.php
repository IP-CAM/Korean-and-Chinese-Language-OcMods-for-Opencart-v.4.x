<?php
// Heading
$_['heading_title']     = '商品评论';

// Text
$_['text_success']      = '成功: 商品评论设置已更新！';
$_['text_next']         = '成功: 您已修改了 %s / %s 项商品评论!';
$_['text_list']         = '商品评论清单';
$_['text_add']          = '添加商品评论';
$_['text_edit']         = '编辑商品评论';
$_['text_filter']       = '评论筛选';

// Column
$_['column_product']    = '商品名称';
$_['column_author']     = '评论者';
$_['column_rating']     = '评价';
$_['column_status']     = '状态';
$_['column_date_added'] = '评论日期';
$_['column_action']     = '管理';

// Entry
$_['entry_product']     = '商品';
$_['entry_author']      = '评论者';
$_['entry_rating']      = '商品评价';
$_['entry_status']      = '评论状态';
$_['entry_text']        = '评论内容';
$_['entry_date_from']   = '评论日期(起)';
$_['entry_date_to']     = '评论日期(止)';

// Help
$_['help_product']      = '(自动搜索)';

// Button
$_['button_rating']     = '同步商品评论';

// Error
$_['error_warning']     = '警告: 请确实检查表单字段填写的内容!';
$_['error_permission']  = '警告: 您没有权限编辑商品评论！';
$_['error_product']     = '您必须输入商品名称！';
$_['error_author']      = '评论者名称必须是 3 到 64 个字！';
$_['error_text']        = '评论内容必须至少 1 个字！';
$_['error_rating']      = '您必须选择评价！';