<?php
// Heading 
$_['heading_title'] = '비밀번호를 잊으셨나요?';
$_['heading_reset'] = '비밀번호 재설정';

//텍스트
$_['text_account'] = '내 계정';
$_['text_forgotten'] = '비밀번호를 잊어버렸습니다';
$_['text_your_email'] = '이메일 편지함';
$_['text_email'] = '계정 등록 시 입력한 이메일 주소를 입력하고 계속을 클릭하면 이메일 주소로 새 비밀번호가 전송됩니다! ';
$_['text_password'] = '새 비밀번호를 입력하세요';
$_['text_success'] = '성공: 비밀번호가 업데이트되었습니다';

// 항목
$_['entry_email'] = '이메일 편지함';
$_['entry_new_password'] = '새 비밀번호';
$_['entry_password'] = '새 비밀번호';
$_['entry_confirm'] = '비밀번호 확인';

// 오류
$_['error_email'] = '경고: 이메일 사서함이 시스템 기록에 없습니다. 다시 시도하십시오! ';
$_['error_not_found'] = '경고: 이메일 사서함이 시스템 기록에 없습니다!';
$_['error_password'] = '비밀번호 길이는 4~20자여야 합니다!';
$_['error_confirm'] = '비밀번호가 확인 비밀번호와 일치하지 않습니다!';
$_['error_code'] = '비밀번호 재설정 코드가 올바르지 않습니다!';