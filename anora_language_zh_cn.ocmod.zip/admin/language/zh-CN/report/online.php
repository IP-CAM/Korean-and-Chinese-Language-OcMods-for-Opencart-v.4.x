<?php
// Heading
$_['heading_title']     = '在线访客';

// Text
$_['text_extension']    = '扩展模块';
$_['text_success']      = '成功: 在线访客设置已更新!';
$_['text_list']         = '在线访客清单';
$_['text_filter']       = '访客筛选';
$_['text_guest']        = '访客';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = '客户';
$_['column_url']        = '最后浏览页面';
$_['column_referer']    = '来自';
$_['column_date_added'] = '时间';
$_['column_action']     = '管理';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = '客户';

// Error
$_['error_permission']  = '警告: 您没有权限编辑在线访客!';