<?php
// Heading
$_['heading_title'] = '扩展模块';

// Text
$_['text_success']  = '成功: 扩展模块设置已更新!';
$_['text_list']     = '扩展模块清单';
$_['text_type']     = '请选择扩展模块类别';
$_['text_filter']   = '筛选';