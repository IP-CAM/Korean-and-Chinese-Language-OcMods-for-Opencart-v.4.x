<?php
// 제목
$_['heading_title'] = '검색';
$_['heading_tag'] = '태그 - ';
 
//텍스트
$_['text_search'] = '검색기준과 일치하는 상품';
$_['text_keyword'] = '키워드';
$_['text_category'] = '모든 카테고리';
$_['text_sub_category'] = '하위 카테고리 검색';
$_['text_no_results'] = '일치하는 제품이 없습니다. ';
$_['text_compare'] = '제품 비교(%s)';
$_['text_sort'] = '정렬 기준:';
$_['text_default'] = '기본값';
$_['text_name_asc'] = '이름 (A - Z)';
$_['text_name_desc'] = '이름(Z - A)';
$_['text_price_asc'] = '가격(낮은 가격>높은 가격)';
$_['text_price_desc'] = '가격(고가>저가)';
$_['text_rating_asc'] = '평가(낮음 > 높음)';
$_['text_rating_desc'] = '평점(높음 > 낮음)';
$_['text_model_asc'] = '모델(A - Z)';
$_['text_model_desc'] = '모델(Z - A)';
$_['text_limit'] = '디스플레이:';

// 항목
$_['entry_search'] = '검색';
$_['entry_description'] = '상품상세설명 검색';