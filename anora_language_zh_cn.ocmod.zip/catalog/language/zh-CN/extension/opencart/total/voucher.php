<?php
// Heading
$_['heading_title'] = '使用购物礼券';

// Text
$_['text_voucher']  = '购物礼券(%s)';
$_['text_success']  = '成功: 购物礼券已套用!';
$_['text_remove']   = '成功: 购物礼券已移除!';

// Entry
$_['entry_voucher'] = '购物礼券代码';

// Error
$_['error_voucher'] = '警告: 购物礼券代码可能无效或余额已用完!';
$_['error_status']  = '警告: 商店并未启用礼券代码功能!';