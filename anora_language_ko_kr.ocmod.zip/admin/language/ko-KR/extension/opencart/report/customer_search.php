<?php
// 제목
$_['heading_title'] = '회원 검색 통계';

//텍스트
$_['text_extension'] = '확장 모듈';
$_['text_edit'] = '회원 검색 통계 편집';
$_['text_success'] = '성공: 회원 검색 통계 설정이 업데이트되었습니다!';
$_['text_filter'] = '필터';
$_['text_guest'] = '손님';
$_['text_customer'] = '<a href="%s">%s</a>';

//열
$_['column_keyword'] = '키워드';
$_['column_products'] = '제품 검색';
$_['column_category'] = '범주';
$_['column_customer'] = '회원';
$_['column_ip'] = 'IP';
$_['column_date_added'] = '날짜 추가';

// 항목
$_['entry_date_start'] = '시작일';
$_['entry_date_end'] = '종료일';
$_['entry_keyword'] = '키워드';
$_['entry_customer'] = '회원';
$_['entry_ip'] = 'IP';
$_['entry_status'] = '상태';
$_['entry_sort_order'] = '정렬';

// 오류
$_['error_permission'] = '경고: 회원 검색 통계를 편집할 수 있는 권한이 없습니다!';