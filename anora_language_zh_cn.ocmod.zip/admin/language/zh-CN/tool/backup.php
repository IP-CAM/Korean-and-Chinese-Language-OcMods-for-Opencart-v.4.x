<?php
// Heading
$_['heading_title']     = '备份 / 还原';

// Text
$_['text_success']      = '成功: 数据库导入已完成！';

$_['text_backup']        = '备份 table %s 第 %s 笔到第 %s 笔纪录';
$_['text_restore']       = '还原 %s / %s';
$_['text_option']        = '备份选项';
$_['text_history']       = '备份纪录';
$_['text_progress']      = '进度';
$_['text_import']        = '如果要还原比较大的备份档，建议先将备份文档 FTP 到 <strong>~/storage/backup/</strong> 目录';

// Column
$_['column_filename']    = '文档名称';
$_['column_size']        = '文档大小';
$_['column_date_added']  = '添加日期';
$_['column_action']      = '管理';

// Entry
$_['entry_progress']     = '进度';
$_['entry_export']       = '选择 Table';

// Error
$_['error_permission']   = '警告: 您没有权限变更备份 / 还原！';
$_['error_export']       = '警告: 您至少需要选择一个数据表以进行导出！';
$_['error_table']        = 'Table %s 不允许被列出!';
$_['error_file']         = '找不到文档!';
$_['error_directory']    = '找不到目录!';
$_['error_not_found']    = '错误: 找不到文档 %s !';
$_['error_headers_sent'] = '错误: Headers already sent out!';
$_['error_upload_size']  = '上传文档大小不得大于 %s!';
