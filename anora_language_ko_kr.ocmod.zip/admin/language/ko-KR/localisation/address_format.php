<?php
// 제목
$_['heading_title'] = '주소 형식';

//텍스트
$_['text_success'] = '성공: 주소 형식이 업데이트되었습니다!';
$_['text_list'] = '주소 형식 목록';
$_['text_add'] = '주소 형식 추가';
$_['text_edit'] = '주소 형식 편집';

//열
$_['column_name'] = '주소 형식 이름';
$_['column_address_format'] = '주소 형식';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '주소 형식 이름';
$_['entry_address_format'] = '주소 형식';

// 돕다
$_['help_address_format'] = '이름 = {firstname}<br />성 = {lastname}<br />회사 = {company}<br />주소 1 = {address_1}<br />주소 2 = { address_2}<br />군 및 도시 = {city}<br />우편번호 = {postcode}<br />군 및 도시 = {zone}<br />군 및 도시 코드 = {zone_code}<br />국가 = {국가}';

// 오류
$_['error_permission'] = '경고: 주소 형식을 편집할 권한이 없습니다!';
$_['error_name'] = '주소 형식 이름은 1~128자여야 합니다!';
$_['error_default'] = '경고: 이 주소 형식 집합은 기본 주소 형식으로 설정되어 삭제할 수 없습니다!';
$_['error_country'] = '경고: 이 주소 형식 집합은 %s 국가의 주소 형식으로 설정되었으므로 삭제할 수 없습니다!';