<?php
// 제목
$_['heading_title'] = '회원등급';

//텍스트
$_['text_success'] = '성공: 회원 등급 설정이 업데이트되었습니다!';
$_['text_list'] = '회원 등급 목록';
$_['text_add'] = '회원등급 추가';
$_['text_edit'] = '회원등급 수정';

//열
$_['column_name'] = '회원 등급 이름';
$_['column_sort_order'] = '정렬 표시';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '회원 등급 이름';
$_['entry_description'] = '회원 등급 설명';
$_['entry_approval'] = '신입회원 검토';
$_['entry_sort_order'] = '정렬 표시';

// 돕다
$_['help_approval'] = '회원은 로그인하기 전에 관리자의 승인을 받아야 합니다. ';

// 오류
$_['error_permission'] = '경고: 회원 등급을 수정할 권한이 없습니다!';
$_['error_name'] = '회원 등급 이름은 3~32자여야 합니다!';
$_['error_default'] = '경고: 이 회원등급은 스토어의 기본 회원등급이므로 삭제할 수 없습니다!';
$_['error_store'] = '경고: 이 회원 등급은 현재 %s 상점에서 사용 중이므로 삭제할 수 없습니다!';
$_['error_customer'] = '경고: 이 회원 등급은 현재 %s 회원이 사용하고 있기 때문에 삭제할 수 없습니다!';