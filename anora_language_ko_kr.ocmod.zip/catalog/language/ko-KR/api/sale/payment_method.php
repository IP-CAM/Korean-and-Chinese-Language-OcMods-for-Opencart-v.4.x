<?php
// Text
$_['text_success'] = '성공: 결제 방법이 사용되었습니다!';

// Error
$_['error_payment_address'] = '경고: 회원 주소가 있어야 합니다!';
$_['error_payment_method'] = '경고: 결제 방법이 있어야 합니다!';
$_['error_no_payment'] = '경고: 사용 가능한 상품 옵션이 없습니다!';
$_['error_product'] = '경고: 상품이 있어야 합니다!'