<?php
//텍스트
$_['text_success'] = '성공: 통화가 변경되었습니다!';

// 오류
$_['error_currency'] = '경고: 잘못된 통화 코드!';