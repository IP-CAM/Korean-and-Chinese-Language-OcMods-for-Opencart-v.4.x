<?php
// Text
$_['text_success'] = '成功: 折价券折扣已套用！';
$_['text_remove']  = '成功: 折价券折扣已移除!';

// Error
$_['error_coupon'] = '警告: 折价券无效，过期或已超过使用限制！';