<?php
// 제목
$_['heading_title'] = '확장 모듈';

//텍스트
$_['text_success'] = '성공: 확장 모듈 설정이 업데이트되었습니다!';
$_['text_list'] = '확장 모듈 목록';
$_['text_type'] = '확장 모듈 카테고리를 선택하세요';
$_['text_filter'] = '필터';