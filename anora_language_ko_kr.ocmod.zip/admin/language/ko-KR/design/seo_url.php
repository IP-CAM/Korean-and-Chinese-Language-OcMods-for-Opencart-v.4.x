<?php
// 제목
$_['heading_title'] = '고정 URL(SEO URL)';

//텍스트
$_['text_success'] = '성공: 고정 URL(SEO URL) 설정이 업데이트되었습니다!';
$_['text_list'] = '정적 URL 목록';
$_['text_add'] = '정적 URL 추가';
$_['text_edit'] = '정적 URL 편집';
$_['text_filter'] = '필터';
$_['text_default'] = '기본값';

//열
$_['column_key'] = '주요 매개변수';
$_['column_value'] = '키 값';
$_['column_keyword'] = '정적 URL 이름';
$_['column_store'] = '저장';
$_['column_language'] = '언어';
$_['column_action'] = '액션';

// 항목
$_['entry_store'] = '스토어';
$_['entry_language'] = '언어';
$_['entry_key'] = '주요 매개변수';
$_['entry_value'] = '키 값';
$_['entry_keyword'] = '정적 URL 이름';
$_['entry_sort_order'] = '정렬';

// 돕다
$_['help_keyword'] = 'a-z 또는 0-9 및 -, _ 또는 공백 문자만 사용할 수 있으며, 설정하지 않으면 공백으로 유지됩니다. ';
$_['help_sort_order'] = '정적 URL 이름 정렬';

// 오류
$_['error_permission'] = '경고: 정적 URL을 수정할 권한이 없습니다!';
$_['error_exists'] = '경고: 상점 유형 + 언어 유형 + 키 + 값 + 정적 URL 이름이 이미 존재합니다!';
$_['error_key'] = '키 매개변수는 1~64 단어여야 합니다!';
$_['error_value'] = '키 값은 1~255 단어여야 합니다!';
$_['error_value_exists'] = '키 값이 사용되었습니다!';
$_['error_keyword'] = '고정 URL 이름은 3~64자여야 합니다!';
$_['error_keyword_exists'] = '정적 URL 이름이 이미 사용 중입니다!';
$_['error_keyword_character'] = '정적 URL 이름은 a-z, 0-9, - 및 _와 같은 문자만 사용할 수 있습니다!';