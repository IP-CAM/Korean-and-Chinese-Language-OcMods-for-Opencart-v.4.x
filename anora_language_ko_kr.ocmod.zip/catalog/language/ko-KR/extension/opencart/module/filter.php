<?php
// 제목
$_['heading_title'] = '제품 특성 필터링';