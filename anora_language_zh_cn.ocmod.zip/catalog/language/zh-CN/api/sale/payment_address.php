<?php
// Text
$_['text_success']       = '成功: 会员地址已设置!';

// Error
$_['error_firstname']    = '名字必须是 1 到 32 个字！';
$_['error_lastname']     = '姓氏必须是 1 到 32 个字！';
$_['error_address_1']    = '地址必须是 3 到 128 个字！';
$_['error_city']         = '乡镇市区必须是 3 到 128 个字！';
$_['error_postcode']     = '邮递区号必须是 2 到 10 个字！';
$_['error_country']      = '请选择一个国家！';
$_['error_zone']         = '请选择一个县市/地区！';
$_['error_custom_field'] = '%s 必须输入!';
$_['error_regex']        = '%s 不是有效值!';