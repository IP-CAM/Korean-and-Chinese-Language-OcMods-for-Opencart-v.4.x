<?php
// Text
$_['text_total'] = '订单总计';