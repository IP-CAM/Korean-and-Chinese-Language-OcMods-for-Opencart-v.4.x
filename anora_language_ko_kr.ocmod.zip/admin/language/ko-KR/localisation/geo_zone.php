<?php
// 제목
$_['heading_title'] = '지역 관리';

//텍스트
$_['text_success'] = '성공: 지역 설정이 업데이트되었습니다! ';
$_['text_list'] = '지역 목록';
$_['text_add'] = '지역 추가';
$_['text_edit'] = '지역 편집';
$_['text_geo_zone'] = '지역 구역';

//열
$_['column_name'] = '지역명';
$_['column_description'] = '설명';
$_['column_action'] = '관리';

// 항목
$_['entry_name'] = '지역명';
$_['entry_description'] = '설명';
$_['entry_country'] = '국가';
$_['entry_zone'] = '군 및 도시';

// 오류
$_['error_permission'] = '경고: 지역 관리 편집 권한이 없습니다! ';
$_['error_name'] = '지역 이름은 3~32자 사이여야 합니다! ';
$_['error_description'] = '지역 설명은 3~255 단어 사이여야 합니다! ';
$_['error_tax_rate'] = '경고: 이 지역에는 하나 이상의 세율이 설정되어 있으므로 삭제할 수 없습니다! ';