<?php
// Heading
$_['heading_title']    = '银行汇款/转帐';

// Text
$_['text_instruction'] = '银行汇款/转帐说明';
$_['text_description'] = '请将订单金额汇款或转帐到以下银行帐户。';
$_['text_payment']     = '确认付款后我们将依订单出货给您。';