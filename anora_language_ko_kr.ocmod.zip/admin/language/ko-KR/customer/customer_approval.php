<?php
// 제목
$_['heading_title'] = '회원 리뷰';

//텍스트
$_['text_success'] = '성공: 회원 리뷰 설정이 업데이트되었습니다!';
$_['text_list'] = '회원 리뷰 목록';
$_['text_default'] = '기본값';
$_['text_customer'] = '쇼핑회원 계정';
$_['text_affiliate'] = '추천 회원 계정';
$_['text_filter'] = '필터';
$_['text_approve'] = '승인';
$_['text_deny'] = '거부';

//열
$_['column_customer'] = '회원 이름';
$_['column_email'] = '이메일';
$_['column_customer_group'] = '회원등급';
$_['column_type'] = '계좌번호';
$_['column_date_add'] = '추가된 날짜';
$_['column_action'] = '액션';

// 항목
$_['entry_customer'] = '회원 이름';
$_['entry_email'] = '이메일';
$_['entry_customer_group'] = '회원등급';
$_['entry_type'] = '계정 유형';
$_['entry_date_from'] = '가입 날짜(부터)';
$_['entry_date_to'] = '가입 날짜(까지)';

// 오류
$_['error_permission'] = '경고: 회원 리뷰를 편집할 권한이 없습니다!';