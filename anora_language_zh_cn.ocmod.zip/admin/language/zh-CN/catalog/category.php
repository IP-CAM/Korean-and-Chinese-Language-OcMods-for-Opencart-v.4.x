<?php
// Heading
$_['heading_title']				= '商品分类';

// Text
$_['text_success']			  	= '成功: 商品分类设置已更新！';
$_['text_list']			  		= '商品分类清单';
$_['text_add']			  		= '添加商品分类';
$_['text_edit']			 		= '编辑商品分类';
$_['text_default']				= '默认';
$_['text_keyword']				= '请勿使用空格，使用 - 取代空格，并确定静态网址(SEO URL)是没有重复过的。';

// Column
$_['column_name']				= '分类名称';
$_['column_sort_order']			= '分类排序';
$_['column_action']				= '编辑分类';
	
// Entry
$_['entry_name']				= '分类名称';
$_['entry_description']			= '分类描述';
$_['entry_meta_title'] 			= 'Meta 标签标题';
$_['entry_meta_keyword']		= 'Meta 标签关键字';
$_['entry_meta_description']	= 'Meta 标签描述';
$_['entry_store']				= '适用商店';
$_['entry_keyword']				= '静态网址(SEO URL)';
$_['entry_parent']				= '上层分类';
$_['entry_filter']				= '商品特性';
$_['entry_image']				= '分类图片';
$_['entry_top']					= '导览列显示';
$_['entry_column']				= '列排显示';
$_['entry_sort_order']			= '显示排序';
$_['entry_status']				= '分类状态';
$_['entry_layout']				= '指定模板(Layout)';

// Help
$_['help_parent']				= '(自动搜索)';
$_['help_filter']				= '(自动搜索)';
$_['help_top']					= '在页面上方导览列显示，仅适用顶层分类。';
$_['help_column']				= '在页面上方主分类下的子分类显示时排列的行数。 仅适用最上层分类。';

// Error 
$_['error_warning']				= '警告: 相关字段数据未输入！';
$_['error_permission']			= '警告: 您没有权限更改商品分类！';
$_['error_name']				= '分类名称必须是 1 到 255 个字！';
$_['error_meta_title']			= 'Meta 标题必须是 1 到 255 个字！';
$_['error_parent']				= '您所选择的上层分类不能是此分类的子分类!';
$_['error_keyword']				= '静态网址(SEO URL)必须是 1 到 64 个字!';
$_['error_keyword_exists']		= '静态网址(SEO URL)必须是没有重复的!';
$_['error_keyword_character']   = '静态网址(SEO URL)只能使用 a-z, 0-9, - and _ 等字符!';